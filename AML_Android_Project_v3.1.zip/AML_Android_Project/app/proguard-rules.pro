# JNI: native code looks these up by name.
-keep class com.aml.advancemodelloader.engine.AmlNative { *; }
-keep interface com.aml.advancemodelloader.engine.TokenCallback { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
