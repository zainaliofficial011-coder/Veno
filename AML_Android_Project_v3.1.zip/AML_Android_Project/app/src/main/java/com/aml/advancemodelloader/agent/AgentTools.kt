package com.aml.advancemodelloader.agent

import android.app.ActivityManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.AlarmClock
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import com.aml.advancemodelloader.engine.ApiException
import com.aml.advancemodelloader.engine.ChatBackend
import com.aml.advancemodelloader.engine.GeneratedMedia
import com.aml.advancemodelloader.engine.McpClient
import com.aml.advancemodelloader.engine.McpServer
import com.aml.advancemodelloader.engine.ToolSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** A tool call the model asked for, parsed from native tool calls or the text protocol. */
data class ParsedToolCall(val id: String, val name: String, val arguments: JSONObject, val raw: String)

/** What the UI shows while a tool runs. */
data class ToolRun(
    val name: String,
    val arguments: String,
    val ok: Boolean,
    val result: String,
    val media: List<String> = emptyList(),
)

/**
 * Everything the model may do on the device: web, files, zips, storage, device info, media
 * generation, clipboard, notifications, apps, alarms, torch, plus any tool from connected MCP
 * servers. No runtime storage permission is needed — the workspace is app-private and exports go
 * through MediaStore into Downloads/AML (Android 10+).
 */
class ToolRunner(
    private val context: Context,
    /** Resolved on every call so switching provider takes effect immediately. */
    private val api: () -> ChatBackend,
    private val resultLimit: () -> Int,
    private val imageModel: () -> String,
    private val videoModel: () -> String,
    private val mcpServers: () -> List<McpServer>,
    private val onOpenUrl: (String) -> Unit = {},
    private val onMedia: (String) -> Unit = {},
) {

    val workspace: File get() = File(context.filesDir, "workspace").apply { mkdirs() }
    private val mediaDir: File get() = File(context.filesDir, "media").apply { mkdirs() }

    private var torchOn = false
    private var torchId: String? = null

    // -----------------------------------------------------------------------------------------
    // Tool declarations
    // -----------------------------------------------------------------------------------------

    val specs: List<ToolSpec> = listOf(
        spec(
            "web_search", "Search the live web (DuckDuckGo) and return titles, snippets and links.",
            schema("query" to str("Search query"), "max_results" to int("How many results (1-10)"), required = listOf("query")),
        ),
        spec("fetch_page", "Download a web page and return its readable text.", schema("url" to str("http(s) URL"), required = listOf("url"))),
        spec("http_request", "Call any HTTP API: GET/POST/PUT/DELETE with headers and a JSON body.", schema(
            "url" to str("Absolute URL"),
            "method" to str("GET, POST, PUT or DELETE (default GET)"),
            "headers" to str("JSON object of headers, e.g. {\"Authorization\":\"Bearer x\"}"),
            "body" to str("Request body (JSON string)"),
            required = listOf("url"),
        )),
        spec("open_url", "Open a link in the browser or the matching app.", schema("url" to str("Absolute URL"), required = listOf("url"))),
        spec("open_app", "Open an installed app by name (e.g. WhatsApp, YouTube, Camera).", schema("name" to str("App name"), required = listOf("name"))),
        spec("write_file", "Create or overwrite a text file in the workspace (optionally export to Downloads/AML).", schema(
            "name" to str("File name, e.g. notes.md"), "content" to str("Full content"),
            "export" to bool("Export to Downloads/AML (default true)"), required = listOf("name", "content"),
        )),
        spec("read_file", "Read a file from the workspace or an absolute path.", schema("name" to str("File name or path"), required = listOf("name"))),
        spec("list_files", "List workspace files with sizes.", schema("sub" to str("Optional sub-folder"))),
        spec("delete_file", "Delete a workspace file.", schema("name" to str("File name"), required = listOf("name"))),
        spec("make_zip", "Zip workspace files into one archive (exported too). Omit files to zip everything.", schema(
            "zip_name" to str("Archive name, e.g. project.zip"), "files" to str("Comma separated file names"),
            required = listOf("zip_name"),
        )),
        spec("list_zips", "List the zip archives AML has created.", noArgs()),
        spec("share_file", "Share a workspace file through the Android share sheet.", schema("name" to str("File name"), required = listOf("name"))),
        spec("storage_info", "Free/total storage and the workspace paths.", noArgs()),
        spec("device_info", "Device model, Android version, CPU, RAM, battery-ish info.", noArgs()),
        spec("clipboard_read", "Read the current clipboard text.", noArgs()),
        spec("clipboard_write", "Copy text to the clipboard.", schema("text" to str("Text to copy"), required = listOf("text"))),
        spec("notify", "Post an Android notification with a title and text.", schema(
            "title" to str("Title"), "text" to str("Body"), required = listOf("title", "text"),
        )),
        spec("set_alarm", "Create an alarm in the clock app.", schema(
            "hour" to int("Hour 0-23"), "minute" to int("Minute 0-59"), "label" to str("Alarm label"),
            required = listOf("hour", "minute"),
        )),
        spec("vibrate", "Vibrate the phone briefly (pattern: short, long or double).", schema("pattern" to str("short, long or double"))),
        spec("torch", "Turn the phone torch on or off.", schema("on" to bool("true = on, false = off"), required = listOf("on"))),
        spec("generate_image", "Create an image from a prompt with the configured image model.", schema(
            "prompt" to str("Detailed prompt"), "size" to str("e.g. 1024x1024"),
            required = listOf("prompt"),
        )),
        spec("generate_video", "Create a short video from a prompt with the configured video model.", schema(
            "prompt" to str("Detailed prompt"), required = listOf("prompt"),
        )),
    )

    val mediaTools: Set<String> = setOf("generate_image", "generate_video")

    /** Built-in tools + everything the enabled MCP servers expose. */
    fun tools(): List<ToolSpec> {
        val mcp = mutableListOf<ToolSpec>()
        mcpServers().filter { it.enabled && it.url.isNotBlank() }.forEach { server ->
            runCatching { mcp += McpClient(server).listTools() }
        }
        return specs + mcp
    }

    fun describeForTextProtocol(extra: List<ToolSpec>): String = buildString {
        appendLine("Available tools — call a tool by replying with exactly this block and nothing else:")
        appendLine("<tool_call>{\"name\":\"web_search\",\"arguments\":{\"query\":\"gold rate lahore today\"}}</tool_call>")
        appendLine()
        (specs + extra).forEach { tool ->
            val args = tool.parameters.optJSONObject("properties")?.keys()?.asSequence()?.joinToString(", ").orEmpty()
            val from = tool.server?.let { " [MCP]" } ?: ""
            appendLine("- ${tool.name}($args)$from — ${tool.description}")
        }
        appendLine()
        appendLine("Rules: at most 3 tool calls per reply, never invent results, wait for <tool_result>,")
        appendLine("and when you have everything, answer the user directly with no tool_call block.")
    }

    // -----------------------------------------------------------------------------------------
    // Execution
    // -----------------------------------------------------------------------------------------

    suspend fun run(call: ParsedToolCall): ToolRun = withContext(Dispatchers.IO) {
        val args = call.arguments
        try {
            when (call.name) {
                "web_search" -> ok(call, webSearch(args.optString("query"), args.optInt("max_results", 6)))
                "fetch_page" -> ok(call, fetchPage(args.optString("url")))
                "http_request" -> ok(call, httpRequest(args))
                "open_url" -> {
                    val url = args.optString("url")
                    require(url.startsWith("http")) { "Sirf http(s) URL khul sakta hai." }
                    onOpenUrl(url)
                    ok(call, "Opened $url")
                }
                "open_app" -> ok(call, openApp(args.optString("name")))
                "write_file" -> ok(call, writeFile(args.optString("name"), args.optString("content"), args.optBoolean("export", true)))
                "read_file" -> ok(call, readFile(args.optString("name")))
                "list_files" -> ok(call, listFiles(args.optString("sub")))
                "delete_file" -> ok(call, deleteFile(args.optString("name")))
                "make_zip" -> ok(call, makeZip(args.optString("zip_name"), args.optString("files")))
                "list_zips" -> ok(call, listZips())
                "share_file" -> ok(call, shareFile(args.optString("name")))
                "storage_info" -> ok(call, storageInfo())
                "device_info" -> ok(call, deviceInfo())
                "clipboard_read" -> ok(call, clipboardRead())
                "clipboard_write" -> ok(call, clipboardWrite(args.optString("text")))
                "notify" -> ok(call, notifyUser(args.optString("title"), args.optString("text")))
                "set_alarm" -> ok(call, setAlarm(args.optInt("hour", -1), args.optInt("minute", -1), args.optString("label")))
                "vibrate" -> ok(call, vibrate(args.optString("pattern")))
                "torch" -> ok(call, torch(args.optBoolean("on", true)))
                "generate_image" -> {
                    val prompt = args.optString("prompt")
                    require(prompt.isNotBlank()) { "prompt khali hai" }
                    val media = api().generateImage(imageModel(), prompt, args.optString("size"))
                    media.forEach { onMedia(it.path) }
                    ok(call, "Image ban gayi: ${media.firstOrNull()?.path}", media.map { it.path })
                }
                "generate_video" -> {
                    val prompt = args.optString("prompt")
                    require(prompt.isNotBlank()) { "prompt khali hai" }
                    val media = api().generateVideo(videoModel(), prompt) { }
                    media.forEach { onMedia(it.path) }
                    ok(call, "Video ban gaya: ${media.firstOrNull()?.path}", media.map { it.path })
                }
                else -> ok(call, mcpCall(call.name, args))
            }
        } catch (t: Throwable) {
            fail(call, t.message ?: t.javaClass.simpleName)
        }
    }

    private fun mcpCall(name: String, args: JSONObject): String {
        val spec = tools().firstOrNull { it.name == name && it.server != null }
            ?: return "ERROR: unknown tool '$name'."
        val server = mcpServers().firstOrNull { it.url == spec.server }
            ?: return "ERROR: MCP server for '$name' not configured."
        return McpClient(server).callTool(name, args)
    }

    private fun ok(call: ParsedToolCall, text: String, media: List<String> = emptyList()) =
        ToolRun(call.name, call.arguments.toString(), true, truncate(text), media)

    private fun fail(call: ParsedToolCall, message: String) =
        ToolRun(call.name, call.arguments.toString(), false, truncate("ERROR: $message"))

    private fun truncate(text: String): String {
        val limit = resultLimit().coerceAtLeast(500)
        return if (text.length <= limit) text else text.take(limit) + "\n…[truncated ${text.length - limit} chars]"
    }

    // -----------------------------------------------------------------------------------------
    // Web
    // -----------------------------------------------------------------------------------------

    private fun webSearch(query: String, maxResults: Int): String {
        require(query.isNotBlank()) { "query khali hai" }
        val limit = maxResults.coerceIn(1, 10)
        val encoded = URLEncoder.encode(query, "UTF-8")
        var lastError: String? = null
        for (url in listOf("https://duckduckgo.com/html/?q=$encoded", "https://lite.duckduckgo.com/lite/?q=$encoded")) {
            val html = runCatching { httpGet(url, "text/html") }.getOrElse { t -> lastError = t.message; null } ?: continue
            val results = parseDdg(html, limit)
            if (results.isNotEmpty()) {
                return buildString {
                    appendLine("Search: $query")
                    results.forEachIndexed { index, (title, snippet, link) ->
                        appendLine("${index + 1}. $title")
                        if (snippet.isNotBlank()) appendLine("   $snippet")
                        appendLine("   $link")
                    }
                }.trim()
            }
        }
        return "Koi result nahi mila${lastError?.let { " ($it)" } ?: ""}."
    }

    private fun parseDdg(html: String, limit: Int): List<Triple<String, String, String>> {
        val primary = Regex("<a[^>]*class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL)
        val lite = Regex("<a[^>]*class=\"result-link\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL)
        val snippets = Regex("<a[^>]*class=\"result__snippet\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL)
            .findAll(html).map { it.groupValues[1] }.toList()
        val matches = primary.findAll(html).toList().ifEmpty { lite.findAll(html).toList() }
        return matches.take(limit).mapIndexed { index, match ->
            Triple(
                stripHtml(match.groupValues[2]),
                stripHtml(snippets.getOrElse(index) { "" }),
                decodeRedirect(match.groupValues[1]),
            )
        }
    }

    private fun decodeRedirect(href: String): String {
        val target = Regex("[?&]uddg=([^&]+)").find(href)?.groupValues?.get(1) ?: return href
        return runCatching { java.net.URLDecoder.decode(target, "UTF-8") }.getOrDefault(href)
    }

    private fun fetchPage(url: String): String {
        require(url.startsWith("http")) { "Absolute http(s) URL dein." }
        return "URL: $url\n\n" + stripHtml(httpGet(url, "text/html, application/xhtml+xml"))
    }

    private fun httpRequest(args: JSONObject): String {
        val url = args.optString("url")
        require(url.startsWith("http")) { "Absolute http(s) URL dein." }
        val method = args.optString("method").ifBlank { "GET" }.uppercase(Locale.US)
        val headers = runCatching { JSONObject(args.optString("headers").ifBlank { "{}" }) }.getOrElse { JSONObject() }
        val body = args.optString("body")
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20_000
            readTimeout = 45_000
            setRequestProperty("User-Agent", "AML-Android/3.0")
        }
        headers.keys().forEach { key -> conn.setRequestProperty(key, headers.optString(key)) }
        if (body.isNotBlank() && method != "GET") {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", conn.getRequestProperty("Content-Type") ?: "application/json")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        return try {
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            "HTTP $code\n\n${text.take(8_000)}"
        } finally {
            conn.disconnect()
        }
    }

    private fun httpGet(url: String, accept: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 20_000
            readTimeout = 45_000
            setRequestProperty("Accept", accept)
            setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Mobile Safari/537.36",
            )
        }
        return try {
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw ApiException("HTTP $code")
            text
        } finally {
            conn.disconnect()
        }
    }

    private fun stripHtml(html: String): String {
        var text = html.replace(Regex("(?is)<script.*?</script>"), " ")
            .replace(Regex("(?is)<style.*?</style>"), " ")
            .replace(Regex("(?is)<noscript.*?</noscript>"), " ")
            .replace(Regex("(?is)<head.*?</head>"), " ")
            .replace(Regex("(?is)<br\\s*/?>"), "\n")
            .replace(Regex("(?is)</(p|div|li|h[1-6]|tr)>"), "\n")
            .replace(Regex("(?s)<[^>]+>"), " ")
        listOf("&nbsp;" to " ", "&amp;" to "&", "&quot;" to "\"", "&#39;" to "'", "&lt;" to "<", "&gt;" to ">")
            .forEach { (from, to) -> text = text.replace(from, to) }
        return text.lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
            .replace(Regex("\n{3,}"), "\n\n")
            .take(12_000)
    }

    // -----------------------------------------------------------------------------------------
    // Apps / device
    // -----------------------------------------------------------------------------------------

    private fun openApp(name: String): String {
        require(name.isNotBlank()) { "App ka naam dein." }
        val pm = context.packageManager
        val intents = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val wanted = name.trim().lowercase(Locale.US)
        val match = intents.firstOrNull { it.loadLabel(pm).toString().lowercase(Locale.US).contains(wanted) }
            ?: intents.firstOrNull { it.activityInfo.packageName.lowercase(Locale.US).contains(wanted) }
        requireNotNull(match) { "'$name' naam ka koi installed app nahi mila." }
        val launch = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(match.activityInfo.packageName, match.activityInfo.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return "Opened ${match.loadLabel(pm)} (${match.activityInfo.packageName})."
    }

    private fun clipboardRead(): String {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = clipboard.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
        return if (text.isBlank()) "Clipboard khali hai." else "Clipboard:\n$text"
    }

    private fun clipboardWrite(text: String): String {
        require(text.isNotBlank()) { "Text khali hai." }
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("AML", text))
        return "Copied ${text.length} chars to the clipboard."
    }

    private fun notifyUser(title: String, text: String): String {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL, "AML", NotificationManager.IMPORTANCE_DEFAULT),
            )
        }
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title.ifBlank { "AML" })
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .build()
        return try {
            manager.notify(System.currentTimeMillis().toInt(), notification)
            "Notification bhej di."
        } catch (t: SecurityException) {
            "ERROR: notification permission nahi hai (Settings ▸ AML ▸ Notifications on karein)."
        }
    }

    private fun setAlarm(hour: Int, minute: Int, label: String): String {
        require(hour in 0..23 && minute in 0..59) { "Hour 0-23 aur minute 0-59 hona chahiye." }
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return String.format(Locale.US, "Alarm set for %02d:%02d %s", hour, minute, label)
    }

    private fun vibrate(pattern: String): String {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as android.os.VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        val timings = when (pattern.lowercase(Locale.US)) {
            "long" -> longArrayOf(0, 800)
            "double" -> longArrayOf(0, 150, 120, 400)
            else -> longArrayOf(0, 200)
        }
        vibrator.vibrate(VibrationEffect.createWaveform(timings, -1))
        return "Vibrated ($pattern)."
    }

    private fun torch(on: Boolean): String {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        if (torchId == null) {
            torchId = manager.cameraIdList.firstOrNull { id ->
                runCatching { manager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                    .getOrDefault(false)
            }
        }
        val id = torchId ?: return "ERROR: is device par torch nahi mila."
        manager.setTorchMode(id, on)
        torchOn = on
        return if (on) "Torch on." else "Torch off."
    }

    // -----------------------------------------------------------------------------------------
    // Files
    // -----------------------------------------------------------------------------------------

    private fun writeFile(name: String, content: String, export: Boolean): String {
        require(name.isNotBlank()) { "File name khali hai" }
        val target = resolve(name)
        target.parentFile?.mkdirs()
        target.writeText(content)
        val exported = if (export) exportToDownloads(target, mimeFor(target.name)) else null
        return buildString {
            appendLine("Saved ${target.name} (${target.length()} bytes)")
            appendLine("Workspace: ${target.absolutePath}")
            if (exported != null) appendLine("Exported: $exported")
        }.trim()
    }

    private fun readFile(name: String): String {
        val file = if (name.startsWith("/")) File(name) else resolve(name)
        require(file.exists() && file.isFile) { "${file.name} nahi mili." }
        val head = file.readBytes().take(200_000).toByteArray().toString(Charsets.UTF_8)
        return "File: ${file.absolutePath} (${file.length()} bytes)\n\n$head"
    }

    private fun listFiles(sub: String): String {
        val dir = if (sub.isBlank()) workspace else resolve(sub)
        if (!dir.exists()) return "Workspace khali hai."
        val files = dir.walkTopDown().filter { it.isFile }.take(200)
            .map { "${it.relativeTo(workspace).path} — ${it.length()} bytes" }.toList()
        return if (files.isEmpty()) "Workspace khali hai (${workspace.absolutePath})."
        else "Workspace: ${workspace.absolutePath}\n" + files.joinToString("\n")
    }

    private fun deleteFile(name: String): String {
        val file = resolve(name)
        return if (file.delete()) "Deleted ${file.name}." else "${file.name} delete nahi hui."
    }

    private fun makeZip(zipName: String, filesCsv: String): String {
        val name = zipName.ifBlank { "aml_${System.currentTimeMillis()}.zip" }
            .let { if (it.endsWith(".zip", true)) it else "$it.zip" }
        val target = resolve(name)
        val sources = if (filesCsv.isBlank()) {
            workspace.walkTopDown().filter { it.isFile && it != target }.toList()
        } else {
            filesCsv.split(',').map { it.trim() }.filter { it.isNotEmpty() }
                .map { resolve(it) }.filter { it.exists() && it != target }
        }
        require(sources.isNotEmpty()) { "Zip karne ke liye koi file nahi mili." }
        target.parentFile?.mkdirs()
        ZipOutputStream(target.outputStream().buffered()).use { zos ->
            sources.forEach { file ->
                zos.putNextEntry(ZipEntry(file.relativeTo(workspace).path.ifBlank { file.name }))
                file.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
        val exported = exportToDownloads(target, "application/zip")
        return buildString {
            appendLine("Zip ready: ${target.name} (${target.length()} bytes, ${sources.size} files)")
            appendLine("Workspace: ${target.absolutePath}")
            if (exported != null) appendLine("Exported: $exported")
        }.trim()
    }

    private fun listZips(): String {
        val zips = workspace.walkTopDown().filter { it.isFile && it.extension.equals("zip", true) }.toList()
        return if (zips.isEmpty()) "Abhi koi zip nahi bani."
        else zips.joinToString("\n") { "${it.relativeTo(workspace).path} — ${it.length()} bytes" }
    }

    private fun shareFile(name: String): String {
        val file = resolve(name)
        require(file.exists()) { "${file.name} nahi mili." }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeFor(file.name)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(intent, file.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Share sheet khul gaya (${file.name})."
    }

    private fun storageInfo(): String {
        val stat = StatFs(Environment.getDataDirectory().path)
        return buildString {
            appendLine("Internal: ${gb(stat.availableBytes)} free of ${gb(stat.totalBytes)}")
            appendLine("Workspace: ${workspace.absolutePath}")
            appendLine("Media: ${mediaDir.absolutePath}")
            appendLine("Export: ${if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) "Downloads/AML" else "app files/AML"}")
        }.trim()
    }

    private fun deviceInfo(): String {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return buildString {
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            appendLine("ABI: ${Build.SUPPORTED_ABIS.joinToString()}")
            appendLine("CPU cores: ${Runtime.getRuntime().availableProcessors()}")
            appendLine("RAM: ${gb(mem.availMem)} free of ${gb(mem.totalMem)}")
            appendLine("Volume: ${audio.getStreamVolume(AudioManager.STREAM_MUSIC)}/${audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)}")
            appendLine("Torch: ${if (torchOn) "on" else "off"}")
        }.trim()
    }

    private fun resolve(name: String): File {
        val safe = name.replace('\\', '/').split('/').filter { it.isNotBlank() && it != "." && it != ".." }
        require(safe.isNotEmpty()) { "Invalid file name." }
        return File(workspace, safe.joinToString("/"))
    }

    private fun exportToDownloads(file: File, mime: String): String? = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AML")
            }
            val resolver = context.contentResolver
            val uri: Uri? = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                "Downloads/AML/${file.name}"
            } else null
        } else {
            val dir = File(context.getExternalFilesDir(null), "AML").apply { mkdirs() }
            file.copyTo(File(dir, file.name), overwrite = true)
            File(dir, file.name).absolutePath
        }
    }.getOrNull()

    private fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase(Locale.US)) {
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "mp4" -> "video/mp4"
        "zip" -> "application/zip"
        "pdf" -> "application/pdf"
        "json" -> "application/json"
        else -> "text/plain"
    }

    private fun gb(bytes: Long): String = String.format(Locale.US, "%.2f GB", bytes / 1_073_741_824.0)

    private fun spec(name: String, description: String, parameters: JSONObject) =
        ToolSpec(name, description, parameters)

    private fun noArgs(): JSONObject = JSONObject().put("type", "object").put("properties", JSONObject())

    private fun schema(vararg pairs: Pair<String, JSONObject>, required: List<String> = emptyList()): JSONObject {
        val props = JSONObject()
        pairs.forEach { (name, spec) -> props.put(name, spec) }
        val json = JSONObject().put("type", "object").put("properties", props)
        if (required.isNotEmpty()) json.put("required", JSONArray(required))
        return json
    }

    private fun str(description: String) = JSONObject().put("type", "string").put("description", description)
    private fun int(description: String) = JSONObject().put("type", "integer").put("description", description)
    private fun bool(description: String) = JSONObject().put("type", "boolean").put("description", description)

    private companion object {
        const val CHANNEL = "aml_alerts"
    }
}

/**
 * Text protocol used when a model cannot call tools natively: the model prints one JSON object per
 * call inside `<tool_call>…</tool_call>` and AML answers with `<tool_result>…</tool_result>`.
 */
object ToolCallParser {

    private val blockRegex = Regex("(?s)<tool_call>(.*?)</tool_call>")
    private val fenceRegex = Regex("(?s)```(?:tool_call|json)?\\s*(\\{\\s*\"name\".*?\\})\\s*```")

    fun parse(text: String): List<ParsedToolCall> {
        val out = mutableListOf<ParsedToolCall>()
        val raw = blockRegex.findAll(text).map { it.groupValues[1] } + fenceRegex.findAll(text).map { it.groupValues[1] }
        raw.forEach { candidate -> parseOne(candidate.trim())?.let { out += it } }
        return out
    }

    fun hasOpenCall(text: String): Boolean = text.lastIndexOf("<tool_call>") > text.lastIndexOf("</tool_call>")

    fun strip(text: String): String = text.replace(blockRegex, "").replace(fenceRegex, "").trim()

    private fun parseOne(raw: String): ParsedToolCall? {
        val json = runCatching { JSONObject(raw) }.getOrNull() ?: return null
        val name = json.optString("name").ifBlank { json.optString("tool") }
        if (name.isBlank()) return null
        val args = when (val value = json.opt("arguments") ?: json.opt("args") ?: json.opt("parameters")) {
            is JSONObject -> value
            is String -> runCatching { JSONObject(value) }.getOrElse { JSONObject() }
            else -> JSONObject()
        }
        val id = json.optString("id").takeIf { it.isNotBlank() } ?: "call_${System.nanoTime()}"
        return ParsedToolCall(id, name, args, raw)
    }
}
