package com.aml.advancemodelloader.engine

import android.util.Base64
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Google Gemini (generativelanguage). Uses `generateContent` / `streamGenerateContent`, the
 * `systemInstruction` + `contents` shape, `functionDeclarations` for tools and `thought` parts for
 * reasoning models. Imagen models go through `:predict`; Veo through `:predictLongRunning` + polling.
 */
class GeminiClient(
    private val baseUrl: () -> String,
    private val apiKey: () -> String,
    private val mediaDir: () -> File,
) : ChatBackend {

    override val label = "Gemini"
    override val kind = ProviderKind.GEMINI

    private fun endpoint(path: String): String = Http.joinUrl(baseUrl(), path)

    private fun headers(): Map<String, String> = buildMap {
        val key = apiKey().trim()
        if (key.isNotEmpty()) put("x-goog-api-key", key)
    }

    // -----------------------------------------------------------------------------------------
    // Chat
    // -----------------------------------------------------------------------------------------

    override fun chat(
        model: String,
        system: String,
        turns: List<Turn>,
        tools: List<ToolSpec>,
        params: GenParams,
        stream: Boolean,
    ): Flow<ChatEvent> = flow {
        val body = body(system, turns, tools, params)
        val path = if (stream) {
            "models/$model:streamGenerateContent?alt=sse"
        } else {
            "models/$model:generateContent"
        }
        val conn = Http.send(endpoint(path), "POST", body, "text/event-stream, application/json", headers())
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw Http.errorFrom(code, Http.text(conn.errorStream), "Gemini")
            if (!stream) {
                parseChunk(Http.text(conn.inputStream)).forEach { emit(it) }
                emit(ChatEvent.Done)
                return@flow
            }
            val buffered = mutableListOf<ChatEvent>()
            Http.sse(conn.inputStream, { !currentCoroutineContext().isActive }) { payload ->
                buffered += parseChunk(payload)
            }
            buffered.forEach { emit(it) }
            emit(ChatEvent.Done)
        } finally {
            conn.disconnect()
        }
    }.flowOn(kotlinx.coroutines.Dispatchers.IO)

    private fun body(system: String, turns: List<Turn>, tools: List<ToolSpec>, params: GenParams): JSONObject {
        val json = JSONObject()
        if (system.isNotBlank()) {
            json.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        }

        val contents = JSONArray()
        val fnNameById = mutableMapOf<String, String>()
        turns.forEach { turn -> fnNameById[turn.toolCallId ?: ""] = turn.toolName.orEmpty() }
        turns.forEach { turn ->
            val parts = JSONArray()
            if (turn.text.isNotBlank()) parts.put(JSONObject().put("text", turn.text))
            turn.images.forEach { path -> inlineData(path)?.let { parts.put(it) } }
            turn.toolCalls.forEach { call ->
                parts.put(
                    JSONObject().put(
                        "functionCall",
                        JSONObject().put("name", call.name).put("args", call.arguments),
                    ),
                )
            }
            if (turn.role == "tool") {
                val name = fnNameById[turn.toolCallId] ?: turn.toolName.orEmpty()
                parts.put(
                    JSONObject().put(
                        "functionResponse",
                        JSONObject().put("name", name.ifBlank { "tool" })
                            .put("response", JSONObject().put("result", turn.text)),
                    ),
                )
            }
            if (parts.length() == 0) return@forEach
            val role = if (turn.role == "assistant") "model" else "user"
            contents.put(JSONObject().put("role", role).put("parts", parts))
        }
        json.put("contents", contents)

        val config = JSONObject()
            .put("temperature", params.temperature.toDouble())
            .put("topP", params.topP.toDouble())
            .put("maxOutputTokens", params.maxTokens)
        if (params.topK > 0) config.put("topK", params.topK)
        if (params.reasoning != ReasoningLevel.OFF) {
            config.put(
                "thinkingConfig",
                JSONObject().put("thinkingBudget", when (params.reasoning) {
                    ReasoningLevel.LOW -> 1_024
                    ReasoningLevel.MEDIUM -> 4_096
                    ReasoningLevel.HIGH -> 12_288
                    ReasoningLevel.OFF -> 0
                }),
            )
        }
        json.put("generationConfig", config)

        if (tools.isNotEmpty()) {
            val declarations = JSONArray()
            tools.forEach { tool ->
                declarations.put(
                    JSONObject().put("name", tool.name)
                        .put("description", tool.description)
                        .put("parameters", tool.parameters),
                )
            }
            json.put("tools", JSONArray().put(JSONObject().put("functionDeclarations", declarations)))
        }
        return json
    }

    private fun inlineData(path: String): JSONObject? {
        val file = File(path)
        if (!file.exists() || file.length() == 0L) return null
        val mime = when (file.extension.lowercase()) {
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            else -> "image/jpeg"
        }
        val data = runCatching { Base64.encodeToString(file.readBytes(), Base64.NO_WRAP) }.getOrNull() ?: return null
        return JSONObject().put("inline_data", JSONObject().put("mime_type", mime).put("data", data))
    }

    private fun parseChunk(payload: String): List<ChatEvent> {
        if (payload.isBlank()) return emptyList()
        val json = runCatching { JSONObject(payload) }.getOrNull() ?: return emptyList()
        json.optJSONObject("error")?.let { return listOf(ChatEvent.Failure(it.optString("message"))) }
        val out = mutableListOf<ChatEvent>()
        val calls = mutableListOf<ToolCallRequest>()
        val candidates = json.optJSONArray("candidates") ?: JSONArray()
        Js.arrayOfNullsOrEmpty(candidates).forEach { candidate ->
            val parts = candidate.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
            Js.arrayOfNullsOrEmpty(parts).forEachIndexed { index, part ->
                part.optString("text").takeIf { it.isNotEmpty() }?.let { text ->
                    if (part.optBoolean("thought", false)) out += ChatEvent.Reasoning(text)
                    else out += ChatEvent.Text(text)
                }
                part.optJSONObject("functionCall")?.let { call ->
                    val args = call.optJSONObject("args") ?: JSONObject()
                    calls += ToolCallRequest(
                        id = "gem_${call.optString("name")}_$index",
                        name = call.optString("name"),
                        arguments = args,
                        raw = args.toString(),
                    )
                }
            }
            candidate.optString("finishReason").takeIf { it.isNotBlank() && it != "STOP" }?.let { reason ->
                if (reason == "SAFETY" || reason == "RECITATION") {
                    out += ChatEvent.Failure("Gemini ne reply block kiya ($reason).")
                }
            }
        }
        if (calls.isNotEmpty()) out += ChatEvent.Calls(calls)
        return out
    }

    // -----------------------------------------------------------------------------------------
    // Models
    // -----------------------------------------------------------------------------------------

    override suspend fun listModels(): List<String> {
        val conn = Http.open(endpoint("models?pageSize=200"), "GET", "application/json")
        headers().forEach { (k, v) -> conn.setRequestProperty(k, v) }
        return try {
            val code = conn.responseCode
            val body = Http.text(if (code in 200..299) conn.inputStream else conn.errorStream)
            if (code !in 200..299) throw Http.errorFrom(code, body, "Gemini")
            Js.arrayOfNullsOrEmpty(runCatching { JSONObject(body).optJSONArray("models") }.getOrNull())
                .mapNotNull { it.optString("name").removePrefix("models/").takeIf { id -> id.isNotBlank() } }
                .filter { it.contains("generateContent") || !it.contains("embedding") }
                .sorted()
        } finally {
            conn.disconnect()
        }
    }

    // -----------------------------------------------------------------------------------------
    // Image / video
    // -----------------------------------------------------------------------------------------

    override suspend fun generateImage(model: String, prompt: String, size: String): List<GeneratedMedia> {
        if (model.isBlank()) throw ApiException("Image model id khali hai — Settings ▸ Image model set karein.")
        // Imagen style: instances + parameters.
        runCatching {
            val body = JSONObject()
                .put("instances", JSONArray().put(JSONObject().put("prompt", prompt)))
                .put("parameters", JSONObject().put("sampleCount", 1))
            val conn = Http.send(endpoint("models/$model:predict"), "POST", body, "application/json", headers())
            try {
                val code = conn.responseCode
                val text = Http.text(if (code in 200..299) conn.inputStream else conn.errorStream)
                if (code !in 200..299) throw Http.errorFrom(code, text, "Imagen")
                text
            } finally {
                conn.disconnect()
            }
        }.onSuccess { raw ->
            val out = imagesFromPredict(raw, model, prompt)
            if (out.isNotEmpty()) return out
        }

        // Gemini image models answer through generateContent with inlineData parts.
        val body = body("", listOf(Turn(role = "user", text = prompt)), emptyList(), GenParams(reasoning = ReasoningLevel.OFF))
        body.put("generationConfig", JSONObject(body.optJSONObject("generationConfig")).put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
        val conn = Http.send(endpoint("models/$model:generateContent"), "POST", body, "application/json", headers())
        return try {
            val code = conn.responseCode
            val text = Http.text(if (code in 200..299) conn.inputStream else conn.errorStream)
            if (code !in 200..299) throw Http.errorFrom(code, text, "Gemini image")
            val out = inlineImages(text, model, prompt)
            if (out.isEmpty()) throw ApiException("Gemini ne koi image return nahi ki.")
            out
        } finally {
            conn.disconnect()
        }
    }

    private fun imagesFromPredict(raw: String, model: String, prompt: String): List<GeneratedMedia> {
        val json = runCatching { JSONObject(raw) }.getOrNull() ?: return emptyList()
        val out = mutableListOf<GeneratedMedia>()
        Js.arrayOfNullsOrEmpty(json.optJSONArray("predictions")).forEach { prediction ->
            prediction.optString("bytesBase64Encoded").takeIf { it.isNotBlank() }?.let { b64 ->
                runCatching { ApiClient.saveBase64(mediaDir(), b64, "image", prompt, model) }.getOrNull()?.let { out += it }
            }
        }
        return out
    }

    private fun inlineImages(raw: String, model: String, prompt: String): List<GeneratedMedia> {
        val json = runCatching { JSONObject(raw) }.getOrNull() ?: return emptyList()
        val out = mutableListOf<GeneratedMedia>()
        Js.arrayOfNullsOrEmpty(json.optJSONArray("candidates")).forEach { candidate ->
            Js.arrayOfNullsOrEmpty(candidate.optJSONObject("content")?.optJSONArray("parts")).forEach { part ->
                val data = part.optJSONObject("inlineData")?.optString("data")
                    ?: part.optJSONObject("inline_data")?.optString("data")
                data?.takeIf { it.isNotBlank() }?.let { b64 ->
                    runCatching { ApiClient.saveBase64(mediaDir(), b64, "image", prompt, model) }.getOrNull()?.let { out += it }
                }
            }
        }
        return out
    }

    override suspend fun generateVideo(model: String, prompt: String, onProgress: (String) -> Unit): List<GeneratedMedia> {
        if (model.isBlank()) throw ApiException("Video model id khali hai (misal: veo-3.0-generate-001).")
        val body = JSONObject()
            .put("instances", JSONArray().put(JSONObject().put("prompt", prompt)))
            .put("parameters", JSONObject().put("sampleCount", 1))
        val start = post(endpoint("models/$model:predictLongRunning"), body)
        val operation = runCatching { JSONObject(start).optString("name") }.getOrNull().orEmpty()
        if (operation.isBlank()) throw ApiException("Veo ne operation name nahi diya: ${start.take(200)}")

        onProgress("queued")
        val deadline = System.currentTimeMillis() + 12 * 60_000
        while (System.currentTimeMillis() < deadline) {
            val payload = get(endpoint(operation))
            val json = runCatching { JSONObject(payload) }.getOrNull()
            if (json?.optBoolean("done") == true) {
                val error = json.optJSONObject("error")?.optString("message")
                if (!error.isNullOrBlank()) throw ApiException("Veo error: $error")
                val uris = mutableListOf<String>()
                collectUris(json.optJSONObject("response"), uris)
                if (uris.isEmpty()) throw ApiException("Veo ne video uri nahi di.")
                val out = mutableListOf<GeneratedMedia>()
                uris.forEach { uri ->
                    val url = if (uri.contains("key=")) uri else "$uri&key=${apiKey().trim()}"
                    runCatching { ApiClient.download(mediaDir(), url, "video", prompt, model) }.getOrNull()?.let { out += it }
                }
                if (out.isNotEmpty()) return out
            }
            onProgress("rendering")
            delay(8_000)
        }
        throw ApiException("Video 12 minute mein ready nahi hui.")
    }

    private fun collectUris(node: Any?, out: MutableList<String>) {
        when (node) {
            is JSONObject -> node.keys().forEach { key ->
                val value = node.opt(key)
                when {
                    value is String && value.startsWith("http") || value is String && value.contains("file/download") ->
                        out += value as String
                    else -> collectUris(value, out)
                }
            }
            is JSONArray -> for (i in 0 until node.length()) collectUris(node.opt(i), out)
        }
    }

    private fun post(url: String, body: JSONObject): String {
        val conn = Http.send(url, "POST", body, "application/json", headers())
        return try {
            val code = conn.responseCode
            val text = Http.text(if (code in 200..299) conn.inputStream else conn.errorStream)
            if (code !in 200..299) throw Http.errorFrom(code, text, "Gemini")
            text
        } finally {
            conn.disconnect()
        }
    }

    private fun get(url: String): String {
        val conn = Http.open(url, "GET", "application/json")
        headers().forEach { (k, v) -> conn.setRequestProperty(k, v) }
        return try {
            val code = conn.responseCode
            val text = Http.text(if (code in 200..299) conn.inputStream else conn.errorStream)
            if (code !in 200..299) throw Http.errorFrom(code, text, "Gemini")
            text
        } finally {
            conn.disconnect()
        }
    }
}
