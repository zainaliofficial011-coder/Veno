package com.aml.advancemodelloader.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Who authored a message. Room stores enums by name, so no TypeConverter is needed.
 * `TOOL` is used by the API transcript for tool results; the chat UI never renders it directly.
 */
enum class MessageRole { SYSTEM, USER, ASSISTANT, TOOL }

/** What the message carries. Room stores enums by name as well. */
enum class MessageKind { TEXT, IMAGE, VIDEO, TOOL, FILE }

/** One conversation. Deleting a session cascades to all of its messages. */
@Entity(tableName = "chat_sessions")
data class ChatSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    /** File name of the model that started the chat, or "api:<model-id>" (informational). */
    val modelName: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    /** Running total of tokens across all messages in the session. */
    val totalTokens: Int = 0,
)

/** A single turn inside a session. */
@Entity(
    tableName = "chat_messages",
    foreignKeys = [
        ForeignKey(
            entity = ChatSessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["sessionId", "timestamp"])],
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val sessionId: Long,
    val role: MessageRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    /** Exact count for generated messages, an estimate for user messages. */
    val tokenCount: Int = 0,
    /** Decode speed of this generation. 0 for user messages. */
    val tokensPerSecond: Float = 0f,
    val kind: MessageKind = MessageKind.TEXT,
    /** Semicolon-separated absolute paths (attachments, generated images, videos, tool files). */
    val mediaPath: String? = null,
    /** The model's reasoning trace, when the conversation was in "thinking" mode. */
    val thinking: String? = null,
)

/**
 * Semicolon-separated paths turned into a list. Kept outside the entity on purpose: Room treats
 * every property with a backing field as a column, and a computed property is safer as an extension.
 */
val MessageEntity.mediaPaths: List<String>
    get() = mediaPath?.split(';')?.filter { it.isNotBlank() } ?: emptyList()
