package com.aml.advancemodelloader.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Adapts the on-device llama.cpp engine to the same [ChatBackend] interface the remote providers
 * use, so the ViewModel's agent loop is provider-independent. Local models always talk through the
 * text tool protocol (they cannot do native function calling).
 */
class LocalBackend(
    private val engine: LlmEngine,
    private val template: () -> PromptTemplate,
    private val contextSize: () -> Int,
) : ChatBackend {

    override val label = "Local GGUF"
    override val kind = ProviderKind.LOCAL

    override fun chat(
        model: String,
        system: String,
        turns: List<Turn>,
        tools: List<ToolSpec>,
        params: GenParams,
        stream: Boolean,
    ): Flow<ChatEvent> = callbackFlow {
        val chatTurns = turns.map { turn ->
            ChatTurn(
                role = when (turn.role) {
                    "assistant" -> com.aml.advancemodelloader.data.MessageRole.ASSISTANT
                    else -> com.aml.advancemodelloader.data.MessageRole.USER
                },
                content = turn.text,
            )
        }
        val generation = GenerationConfig(
            systemPrompt = system,
            maxNewTokens = params.maxTokens,
            temperature = params.temperature,
            topP = params.topP,
            topK = params.topK,
        )
        val prompt = PromptBuilder.build(
            template = template(),
            system = system,
            turns = chatTurns,
            promptTokenBudget = contextSize() - params.maxTokens,
        )
        val finished = AtomicBoolean(false)
        launch(Dispatchers.IO) {
            try {
                // Already formatted above, so the raw entry point is used (no double templating).
                engine.generateRaw(prompt, generation).collect { piece -> trySend(ChatEvent.Text(piece)) }
                finished.set(true)
                trySend(ChatEvent.Done)
                close()
            } catch (t: Throwable) {
                finished.set(true)
                trySend(ChatEvent.Failure(t.message ?: "Local generation failed"))
                close()
            }
        }
        awaitClose { if (!finished.get()) engine.requestStop() }
    }.flowOn(Dispatchers.IO)

    override suspend fun listModels(): List<String> = emptyList()

    override suspend fun generateImage(model: String, prompt: String, size: String): List<GeneratedMedia> =
        throw ApiException("Local GGUF model image generate nahi karta — Settings ▸ Backend ko API par switch karein.")

    override suspend fun generateVideo(model: String, prompt: String, onProgress: (String) -> Unit): List<GeneratedMedia> =
        throw ApiException("Local GGUF model video generate nahi karta — API backend use karein.")
}
