package com.aml.advancemodelloader.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.AddComment
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aml.advancemodelloader.data.AppSettings
import com.aml.advancemodelloader.data.BackendKind
import com.aml.advancemodelloader.data.ChatSessionEntity
import com.aml.advancemodelloader.data.MessageEntity
import com.aml.advancemodelloader.data.MessageKind
import com.aml.advancemodelloader.data.MessageRole
import com.aml.advancemodelloader.data.mediaPaths
import com.aml.advancemodelloader.engine.ReasoningLevel
import com.aml.advancemodelloader.engine.McpServer
import com.aml.advancemodelloader.engine.ToolSpec

private const val SECTION_API = "api"
private const val SECTION_SETTINGS = "system"
private const val SECTION_MCP = "mcp"

/**
 * The home screen. On a fresh install no model exists yet, so the centre shows the two ways to get
 * one: pick a local .gguf file, or set up an API. Every agent power is one tap away in the input bar.
 */
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    onOpenSettings: (String) -> Unit,
    onOpenGallery: () -> Unit,
    onOpenModels: () -> Unit,
) {
    val context = LocalContext.current

    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val engineState by viewModel.engineState.collectAsStateWithLifecycle()
    val loadedModel by viewModel.loadedModel.collectAsStateWithLifecycle()
    val picker by viewModel.picker.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val streaming by viewModel.streaming.collectAsStateWithLifecycle()
    val attachments by viewModel.attachments.collectAsStateWithLifecycle()
    val ready by viewModel.chatReady.collectAsStateWithLifecycle()
    val sessions by viewModel.sessions.collectAsStateWithLifecycle()
    val filteredSessions by viewModel.filteredSessions.collectAsStateWithLifecycle()
    val currentSessionId by viewModel.currentSessionId.collectAsStateWithLifecycle()
    val sessionQuery by viewModel.sessionQuery.collectAsStateWithLifecycle()
    val title by viewModel.chatTitle.collectAsStateWithLifecycle()
    val subtitle by viewModel.chatSubtitle.collectAsStateWithLifecycle()
    val busy by viewModel.busy.collectAsStateWithLifecycle()
    val tools by viewModel.tools.collectAsStateWithLifecycle()
    val mcpStatus by viewModel.mcpStatus.collectAsStateWithLifecycle()
    val perf by viewModel.perf.collectAsStateWithLifecycle()

    var input by rememberSaveable { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var startMicAfterGrant by remember { mutableStateOf(false) }
    var showSessions by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }
    var showMcp by remember { mutableStateOf(false) }
    var showPerf by remember { mutableStateOf(false) }
    var mediaPrompt by remember { mutableStateOf<MessageKind?>(null) }
    var editing by remember { mutableStateOf<MessageEntity?>(null) }

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val listState = rememberLazyListState()
    val tts = rememberTts(settings.speechRate, settings.speechLanguage)

    val speech = rememberSpeechController(
        language = settings.speechLanguage,
        onPartial = { partial -> input = partial },
        onFinal = { text ->
            if (text.isNotBlank()) {
                input = ""
                viewModel.sendMessage(text)
            }
        },
        onError = { viewModel.notify(it) },
        onListening = { listening = it },
    )

    val ggufPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.importAndLoad(uri)
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) viewModel.attachImage(uri)
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startMicAfterGrant = true else viewModel.notify("Mic permission ke bina voice input nahi chalega.")
    }

    // Starts listening right after the user grants RECORD_AUDIO.
    LaunchedEffect(startMicAfterGrant) {
        if (startMicAfterGrant) {
            startMicAfterGrant = false
            speech.startListening()
        }
    }

    LaunchedEffect(streaming?.text?.length, messages.size, currentSessionId) {
        val target = messages.size + if (streaming != null) 1 else 0
        if (target > 0) listState.animateScrollToItem(maxOf(0, target - 1))
    }
    LaunchedEffect(showSessions) { if (showSessions) drawerState.open() else drawerState.close() }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet {
                SessionsDrawer(
                    sessions = sessions,
                    filtered = filteredSessions,
                    query = sessionQuery,
                    onQuery = { viewModel.setSessionQuery(it) },
                    currentId = currentSessionId,
                    onNew = { viewModel.newChat(); showSessions = false },
                    onOpen = { viewModel.openSession(it); showSessions = false },
                    onDelete = { viewModel.deleteSession(it) },
                    onDeleteAll = { viewModel.deleteAllSessions() },
                    onGallery = { onOpenGallery(); showSessions = false },
                    onClose = { showSessions = false },
                )
            }
        },
    ) {
        Column(Modifier.fillMaxSize()) {
            ChatTopBar(
                title = title,
                subtitle = subtitle,
                ready = ready,
                generating = engineState is EngineState.GeneratingText,
                onMenu = { showSessions = true },
                onNewChat = { viewModel.newChat() },
                onSettings = { onOpenSettings(SECTION_SETTINGS) },
                onGallery = onOpenGallery,
                onSearch = { showSearch = true },
                onPerf = { showPerf = true },
                onExport = { viewModel.exportChat(share = false) },
                onModels = onOpenModels,
            )

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    messages.isEmpty() && streaming == null && !ready -> FirstRunPanel(
                        models = picker.models,
                        modelLoading = engineState is EngineState.LoadingModel,
                        importProgress = picker.importProgress,
                        onPickLocal = { ggufPicker.launch(arrayOf("*/*")) },
                        onApiSetup = { onOpenSettings(SECTION_API) },
                        onLoadModel = { viewModel.loadModel(it) },
                    )

                    messages.isEmpty() && streaming == null -> WelcomePanel(
                        isApi = settings.backend == BackendKind.API,
                        backendLabel = subtitle,
                        onPick = { viewModel.sendMessage(it) },
                        onPickLocal = { ggufPicker.launch(arrayOf("*/*")) },
                        onApiSetup = { onOpenSettings(SECTION_API) },
                    )

                    else -> MessageList(
                        listState = listState,
                        messages = messages,
                        streaming = streaming,
                        onCopy = { text ->
                            copyToClipboard(context, "AML", text)
                            viewModel.notify("Copy ho gaya ✓")
                        },
                        onShare = { viewModel.shareMessage(it) },
                        onSpeak = { tts.speak(it) },
                        onEdit = { editing = it },
                        onRegenerate = { viewModel.regenerate() },
                    )
                }

                (engineState as? EngineState.Error)?.let { error ->
                    ErrorBanner(
                        message = error.message,
                        onDismiss = { viewModel.dismissError() },
                        modifier = Modifier.align(Alignment.TopCenter),
                    )
                }

                busy?.let { label ->
                    Surface(
                        modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp),
                        shape = RoundedCornerShape(24.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        tonalElevation = 3.dp,
                    ) {
                        Row(
                            Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(label, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }

            Composer(
                input = input,
                onInput = { input = it },
                attachments = attachments,
                settings = settings,
                tools = tools,
                listening = listening,
                generating = engineState is EngineState.GeneratingText,
                chatReady = ready,
                onToggleThinking = { on -> viewModel.updateSettings(settings.copy(thinkingEnabled = on)) },
                onCycleReasoning = { next -> viewModel.updateSettings(settings.copy(reasoning = next)) },
                onToggleAgent = { on -> viewModel.updateSettings(settings.copy(agentEnabled = on)) },
                onPickImage = { imagePicker.launch("image/*") },
                onRemoveAttachment = { viewModel.removeAttachment(it) },
                onMic = {
                    val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                        PackageManager.PERMISSION_GRANTED
                    when {
                        listening -> speech.stopListening()
                        !context.hasSpeechRecognizer -> {
                            runCatching { context.startActivity(speechSettingsIntent()) }
                            viewModel.notify("Speech recognizer nahi mila — system settings khol di hain.")
                        }
                        !granted -> micPermission.launch(Manifest.permission.RECORD_AUDIO)
                        else -> speech.startListening()
                    }
                },
                onSend = {
                    val text = input
                    input = ""
                    viewModel.sendMessage(text)
                },
                onStop = { viewModel.stopGeneration() },
                onImagePrompt = { mediaPrompt = MessageKind.IMAGE },
                onVideoPrompt = { mediaPrompt = MessageKind.VIDEO },
                onTools = { showTools = true },
                onMcp = { showMcp = true },
                onSearch = { showSearch = true },
            )
        }
    }

    if (showSearch) {
        SearchDialog(
            onDismiss = { showSearch = false },
            onFilterChat = { viewModel.setSessionQuery(it) },
            onWebSearch = { query ->
                showSearch = false
                viewModel.sendMessage("Web search karke batao: $query")
            },
        )
    }
    if (showTools) {
        ToolsDialog(tools, onDismiss = { showTools = false }, onRefresh = { viewModel.refreshTools() })
    }
    if (showMcp) {
        McpDialog(
            servers = settings.mcpServers,
            status = mcpStatus,
            onDismiss = { showMcp = false },
            onRefresh = { viewModel.refreshMcp() },
            onToggle = { server, enabled -> viewModel.addMcpServer(server.copy(enabled = enabled)) },
            onManage = { showMcp = false; onOpenSettings(SECTION_MCP) },
        )
    }
    if (showPerf) {
        PerfDialog(perf, modelName = loadedModel?.name, onDismiss = { showPerf = false })
    }
    mediaPrompt?.let { kind ->
        MediaPromptDialog(
            kind = kind,
            onDismiss = { mediaPrompt = null },
            onGenerate = { prompt ->
                mediaPrompt = null
                if (kind == MessageKind.IMAGE) viewModel.generateImage(prompt) else viewModel.generateVideo(prompt)
            },
        )
    }
    editing?.let { message ->
        EditDialog(
            initial = message.content,
            onDismiss = { editing = null },
            onSend = { text ->
                editing = null
                viewModel.editAndResend(message.id, text)
            },
        )
    }
}

// =============================================================================================
// Top bar + drawer
// =============================================================================================

@Composable
private fun ChatTopBar(
    title: String,
    subtitle: String,
    ready: Boolean,
    generating: Boolean,
    onMenu: () -> Unit,
    onNewChat: () -> Unit,
    onSettings: () -> Unit,
    onGallery: () -> Unit,
    onSearch: () -> Unit,
    onPerf: () -> Unit,
    onExport: () -> Unit,
    onModels: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Surface(color = MaterialTheme.colorScheme.surface) {
        Column {
            Row(
                Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onMenu) { Icon(Icons.Filled.Menu, contentDescription = "Chats") }
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Spacer(Modifier.width(6.dp))
                        Box(
                            Modifier.size(8.dp).clip(CircleShape).background(
                                when {
                                    generating -> MaterialTheme.colorScheme.tertiary
                                    ready -> MaterialTheme.colorScheme.primary
                                    else -> MaterialTheme.colorScheme.outline
                                },
                            ),
                        )
                    }
                    Text(
                        text = if (generating) "Generate ho raha hai…" else subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                IconButton(onClick = onNewChat) { Icon(Icons.Outlined.AddComment, contentDescription = "New chat") }
                IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, contentDescription = "Settings") }
                Box {
                    IconButton(onClick = { menu = true }) {
                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "More")
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Search") },
                            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                            onClick = { menu = false; onSearch() },
                        )
                        DropdownMenuItem(
                            text = { Text("Models & providers") },
                            leadingIcon = { Icon(Icons.Filled.Memory, contentDescription = null) },
                            onClick = { menu = false; onModels() },
                        )
                        DropdownMenuItem(
                            text = { Text("Gallery") },
                            leadingIcon = { Icon(Icons.Filled.Image, contentDescription = null) },
                            onClick = { menu = false; onGallery() },
                        )
                        DropdownMenuItem(
                            text = { Text("Stats") },
                            leadingIcon = { Icon(Icons.Outlined.Bolt, contentDescription = null) },
                            onClick = { menu = false; onPerf() },
                        )
                        DropdownMenuItem(
                            text = { Text("Export chat (Markdown)") },
                            leadingIcon = { Icon(Icons.Filled.ContentCopy, contentDescription = null) },
                            onClick = { menu = false; onExport() },
                        )
                    }
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
        }
    }
}

@Composable
private fun SessionsDrawer(
    sessions: List<ChatSessionEntity>,
    filtered: List<ChatSessionEntity>,
    query: String,
    onQuery: (String) -> Unit,
    currentId: Long?,
    onNew: () -> Unit,
    onOpen: (Long) -> Unit,
    onDelete: (Long) -> Unit,
    onDeleteAll: () -> Unit,
    onGallery: () -> Unit,
    onClose: () -> Unit,
) {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Memory, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(8.dp))
            Text("AML", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onGallery) { Text("Gallery") }
        }
        Text(
            "Advance Model Loader",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        Button(onClick = onNew, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.Add, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("New chat")
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = query,
            onValueChange = onQuery,
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            placeholder = { Text("Chat dhoondein") },
            singleLine = true,
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQuery("") }) { Icon(Icons.Filled.Close, contentDescription = "Clear") }
                }
            },
        )
        Spacer(Modifier.height(8.dp))
        HorizontalDivider()
        LazyColumn(Modifier.weight(1f)) {
            items(filtered, key = { it.id }) { session ->
                val selected = session.id == currentId
                Surface(
                    color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { onOpen(session.id) },
                ) {
                    Row(
                        Modifier.padding(start = 10.dp, end = 2.dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(session.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                            Text(
                                "${session.modelName.ifBlank { "—" }} · ${relativeTime(session.updatedAt)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        IconButton(onClick = { onDelete(session.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete", modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (sessions.isNotEmpty()) {
                TextButton(onClick = onDeleteAll) { Text("Sab chats delete karein") }
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("Band karein") }
        }
    }
}

// =============================================================================================
// Empty states
// =============================================================================================

@Composable
private fun FirstRunPanel(
    models: List<ModelFile>,
    modelLoading: Boolean,
    importProgress: Float?,
    onPickLocal: () -> Unit,
    onApiSetup: () -> Unit,
    onLoadModel: (ModelFile) -> Unit,
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(84.dp)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(
                    Icons.Filled.Memory,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(42.dp),
                )
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("AML", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "Advance Model Loader — koi model abhi load nahi hai",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(26.dp))

        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
            shape = RoundedCornerShape(20.dp),
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Memory, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text("Local model (.gguf)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Phone se GGUF file chunein — Qwen, Llama 3, Gemma, Phi. App usse apni storage mein " +
                        "copy karke offline chala dega.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = onPickLocal, enabled = importProgress == null, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.UploadFile, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (importProgress == null) "Local model select karein (.gguf)" else "Copy ho raha hai…")
                }
                importProgress?.let {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth())
                }
                if (modelLoading) {
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Model load ho raha hai…", style = MaterialTheme.typography.labelMedium)
                    }
                }
                if (models.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    HorizontalDivider()
                    Spacer(Modifier.height(6.dp))
                    Text("Downloaded models", style = MaterialTheme.typography.labelMedium)
                    models.take(4).forEach { model ->
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(model.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                                Text(
                                    formatBytes(model.sizeBytes),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            TextButton(onClick = { onLoadModel(model) }) { Text("Load") }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)),
            shape = RoundedCornerShape(20.dp),
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Cloud, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text("API key / API setup", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "OpenAI, Anthropic, Gemini, OpenRouter, Groq, DeepSeek, xAI, Mistral, Ollama, LM Studio — " +
                        "base URL + key + model id. Image aur video models bhi wahin set hote hain.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = onApiSetup, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Settings, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("API key / setup karein")
                }
            }
        }
    }
}

private val SUGGESTIONS = listOf(
    "Aaj Lahore ka gold rate search karo",
    "Ek Python script likho jo CSV file clean kare",
    "Is device ki storage aur RAM batao",
    "Mere notes ka summary banao",
    "Ek motivational shayari likho",
)

@Composable
private fun WelcomePanel(
    isApi: Boolean,
    backendLabel: String,
    onPick: (String) -> Unit,
    onPickLocal: () -> Unit,
    onApiSetup: () -> Unit,
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Filled.Memory, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(52.dp))
        Spacer(Modifier.height(12.dp))
        Text(
            if (isApi) "API ready — kya poochhna hai?" else "Model ready — kya poochhna hai?",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            backendLabel,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(20.dp))
        Column(Modifier.widthIn(max = 520.dp)) {
            SUGGESTIONS.forEach { suggestion ->
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onPick(suggestion) },
                ) {
                    Text(suggestion, Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row {
            TextButton(onClick = onPickLocal) { Text("Model badlein") }
            TextButton(onClick = onApiSetup) { Text("API setup") }
        }
    }
}

@Composable
private fun ErrorBanner(message: String, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth().padding(12.dp),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.errorContainer,
        shadowElevation = 3.dp,
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.onErrorContainer)
            Spacer(Modifier.width(10.dp))
            Text(
                message,
                Modifier.weight(1f),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onErrorContainer,
            )
            IconButton(onClick = onDismiss) {
                Icon(Icons.Filled.Close, contentDescription = "Dismiss", modifier = Modifier.size(18.dp))
            }
        }
    }
}

// =============================================================================================
// Messages
// =============================================================================================

@Composable
private fun MessageList(
    listState: LazyListState,
    messages: List<MessageEntity>,
    streaming: StreamingMessage?,
    onCopy: (String) -> Unit,
    onShare: (String) -> Unit,
    onSpeak: (String) -> Unit,
    onEdit: (MessageEntity) -> Unit,
    onRegenerate: () -> Unit,
) {
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(messages, key = { it.id }) { message ->
            MessageBubble(
                message = message,
                isLast = message.id == messages.lastOrNull()?.id,
                onCopy = { onCopy(message.content) },
                onShare = { onShare(message.content) },
                onSpeak = { onSpeak(message.content) },
                onEdit = { onEdit(message) },
                onRegenerate = onRegenerate,
            )
        }
        streaming?.let { live ->
            item(key = "streaming") { StreamingBubble(live, onSpeak = { onSpeak(live.text) }) }
        }
    }
}

@Composable
private fun MessageBubble(
    message: MessageEntity,
    isLast: Boolean,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onSpeak: () -> Unit,
    onEdit: () -> Unit,
    onRegenerate: () -> Unit,
) {
    val context = LocalContext.current
    val isUser = message.role == MessageRole.USER
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (isUser) Alignment.End else Alignment.Start) {
        Surface(
            color = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (isUser) 18.dp else 6.dp,
                bottomEnd = if (isUser) 6.dp else 18.dp,
            ),
            tonalElevation = if (isUser) 0.dp else 1.dp,
            border = if (isUser) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
            modifier = Modifier.widthIn(max = 620.dp),
        ) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                if (!isUser) {
                    Text(
                        "AML",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                    )
                    Spacer(Modifier.height(4.dp))
                }
                MarkdownText(message.content)
                message.thinking?.takeIf { it.isNotBlank() }?.let { trace ->
                    Spacer(Modifier.height(6.dp))
                    ThinkingBlock(trace, streamingNow = false)
                }
                message.mediaPaths.forEach { path ->
                    Spacer(Modifier.height(8.dp))
                    MediaCard(path = path, onOpen = { openLocalFile(it, context) })
                }
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (message.tokenCount > 0) {
                        Text(
                            buildString {
                                append("${message.tokenCount} tok")
                                if (message.tokensPerSecond > 0f) append(" · %.1f tok/s".format(message.tokensPerSecond))
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    if (isUser) {
                        IconButton(onClick = onEdit, modifier = Modifier.size(30.dp)) {
                            Icon(Icons.Filled.Edit, contentDescription = "Edit", modifier = Modifier.size(16.dp))
                        }
                    } else {
                        IconButton(onClick = onSpeak, modifier = Modifier.size(30.dp)) {
                            Icon(Icons.Filled.VolumeUp, contentDescription = "Speak", modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = onCopy, modifier = Modifier.size(30.dp)) {
                            Icon(Icons.Filled.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = onShare, modifier = Modifier.size(30.dp)) {
                            Icon(Icons.Filled.Send, contentDescription = "Share", modifier = Modifier.size(16.dp))
                        }
                        if (isLast) {
                            IconButton(onClick = onRegenerate, modifier = Modifier.size(30.dp)) {
                                Icon(Icons.Filled.Refresh, contentDescription = "Regenerate", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StreamingBubble(live: StreamingMessage, onSpeak: () -> Unit) {
    val context = LocalContext.current
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(18.dp),
        tonalElevation = 1.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
        modifier = Modifier.widthIn(max = 620.dp),
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text("AML", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            if (live.thinking.isNotBlank()) ThinkingBlock(live.thinking, streamingNow = true)
            live.tools.forEach { tool -> ToolRow(tool) }
            if (live.text.isNotBlank()) {
                MarkdownText(live.text)
            } else if (live.tools.isEmpty()) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                    CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Soch raha hai…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            live.media.forEach { path ->
                Spacer(Modifier.height(8.dp))
                MediaCard(path = path, onOpen = { openLocalFile(it, context) })
            }
            if (live.text.isNotBlank()) {
                TextButton(onClick = onSpeak, contentPadding = PaddingValues(horizontal = 6.dp)) {
                    Icon(Icons.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Sun kar", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun ThinkingBlock(trace: String, streamingNow: Boolean) {
    var expanded by remember(streamingNow) { mutableStateOf(streamingNow) }
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { expanded = !expanded }) {
                Icon(Icons.Filled.Psychology, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(6.dp))
                Text(
                    if (streamingNow) "Soch raha hai…" else "Thinking",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.weight(1f))
                Icon(
                    if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
            }
            AnimatedVisibility(visible = expanded) {
                Text(
                    trace,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
        }
    }
}

@Composable
private fun ToolRow(tool: ToolActivity) {
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            when (tool.status) {
                ToolStatus.RUNNING -> CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp)
                ToolStatus.OK -> Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                ToolStatus.FAILED -> Icon(Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.width(8.dp))
            Column {
                Text(tool.name, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                if (tool.arguments.isNotBlank()) {
                    Text(
                        tool.arguments,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

// =============================================================================================
// Composer (input bar with every shortcut)
// =============================================================================================

@Composable
private fun Composer(
    input: String,
    onInput: (String) -> Unit,
    attachments: List<Attachment>,
    settings: AppSettings,
    tools: List<ToolSpec>,
    listening: Boolean,
    generating: Boolean,
    chatReady: Boolean,
    onToggleThinking: (Boolean) -> Unit,
    onCycleReasoning: (ReasoningLevel) -> Unit,
    onToggleAgent: (Boolean) -> Unit,
    onPickImage: () -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onMic: () -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onImagePrompt: () -> Unit,
    onVideoPrompt: () -> Unit,
    onTools: () -> Unit,
    onMcp: () -> Unit,
    onSearch: () -> Unit,
) {
    Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp) {
        Column(Modifier.fillMaxWidth().imePadding().padding(horizontal = 10.dp, vertical = 8.dp)) {
            if (attachments.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    attachments.forEach { attachment ->
                        Box {
                            AttachmentThumb(attachment.path)
                            IconButton(
                                onClick = { onRemoveAttachment(attachment.path) },
                                modifier = Modifier.size(20.dp).align(Alignment.TopEnd),
                            ) {
                                Icon(Icons.Filled.Close, contentDescription = "Remove", modifier = Modifier.size(12.dp))
                            }
                        }
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AssistChip(
                    onClick = { onToggleThinking(!settings.thinkingEnabled) },
                    label = { Text(if (settings.thinkingEnabled) "Thinking on" else "Thinking") },
                    leadingIcon = { Icon(Icons.Filled.Psychology, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = if (settings.thinkingEnabled) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
                    ),
                )
                if (settings.backend == BackendKind.API) {
                    AssistChip(
                        onClick = {
                            onCycleReasoning(
                                when (settings.reasoning) {
                                    ReasoningLevel.OFF -> ReasoningLevel.MEDIUM
                                    ReasoningLevel.LOW -> ReasoningLevel.MEDIUM
                                    ReasoningLevel.MEDIUM -> ReasoningLevel.HIGH
                                    ReasoningLevel.HIGH -> ReasoningLevel.OFF
                                },
                            )
                        },
                        label = { Text("Reason: ${settings.reasoning.label}") },
                        leadingIcon = { Icon(Icons.Outlined.Tune, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    )
                }
                AssistChip(
                    onClick = { onToggleAgent(!settings.agentEnabled) },
                    label = { Text(if (settings.agentEnabled) "Agent on" else "Agent") },
                    leadingIcon = { Icon(Icons.Outlined.Bolt, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = if (settings.agentEnabled) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
                    ),
                )
                AssistChip(
                    onClick = onSearch,
                    label = { Text("Search") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(16.dp)) },
                )
                AssistChip(
                    onClick = onImagePrompt,
                    label = { Text("Image") },
                    leadingIcon = { Icon(Icons.Filled.Image, contentDescription = null, modifier = Modifier.size(16.dp)) },
                )
                AssistChip(
                    onClick = onVideoPrompt,
                    label = { Text("Video") },
                    leadingIcon = { Icon(Icons.Filled.Movie, contentDescription = null, modifier = Modifier.size(16.dp)) },
                )
                AssistChip(
                    onClick = onMic,
                    label = { Text(if (listening) "Sun raha hoon…" else "Voice") },
                    leadingIcon = { Icon(Icons.Filled.Mic, contentDescription = null, modifier = Modifier.size(16.dp)) },
                )
                AssistChip(
                    onClick = onTools,
                    label = { Text("Tools (${tools.size})") },
                    leadingIcon = { Icon(Icons.Outlined.Extension, contentDescription = null, modifier = Modifier.size(16.dp)) },
                )
                AssistChip(
                    onClick = onMcp,
                    label = { Text(if (settings.mcpServers.isEmpty()) "MCP" else "MCP (${settings.mcpServers.size})") },
                    leadingIcon = { Icon(Icons.Filled.Build, contentDescription = null, modifier = Modifier.size(16.dp)) },
                )
            }

            Spacer(Modifier.height(6.dp))

            Row(verticalAlignment = Alignment.Bottom) {
                IconButton(onClick = onPickImage) {
                    Icon(Icons.Filled.Add, contentDescription = "Attach image", tint = MaterialTheme.colorScheme.primary)
                }
                OutlinedTextField(
                    value = input,
                    onValueChange = onInput,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(if (chatReady) "Kuch bhi poochhein…" else "Pehle model load karein") },
                    shape = RoundedCornerShape(22.dp),
                    maxLines = 5,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { if (chatReady && input.isNotBlank()) onSend() }),
                )
                Spacer(Modifier.width(6.dp))
                IconButton(
                    onClick = onMic,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(if (listening) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    Icon(
                        Icons.Filled.Mic,
                        contentDescription = "Mic",
                        tint = if (listening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.width(6.dp))
                FilledIconButton(
                    onClick = { if (generating) onStop() else onSend() },
                    enabled = generating || (chatReady && input.isNotBlank()),
                    modifier = Modifier.size(46.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (generating) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    ),
                ) {
                    Icon(
                        if (generating) Icons.Filled.Stop else Icons.Filled.ArrowUpward,
                        contentDescription = if (generating) "Stop" else "Send",
                    )
                }
            }
        }
    }
}

@Composable
private fun AttachmentThumb(path: String) {
    val bitmap = remember(path) { runCatching { BitmapFactory.decodeFile(path) }.getOrNull() }
    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)),
        )
    } else {
        Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(10.dp), modifier = Modifier.size(56.dp)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Icon(Icons.Filled.Image, contentDescription = null) }
        }
    }
}

// =============================================================================================
// Dialogs
// =============================================================================================

@Composable
private fun SearchDialog(
    onDismiss: () -> Unit,
    onFilterChat: (String) -> Unit,
    onWebSearch: (String) -> Unit,
) {
    var query by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Search") },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Chat filter ya web search") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Chat filter drawer ki list chhaantta hai; web search agent tool chala kar live jawab dega.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            Button(onClick = { if (query.isNotBlank()) onWebSearch(query) }, enabled = query.isNotBlank()) {
                Text("Web search")
            }
        },
        dismissButton = { TextButton(onClick = { onFilterChat(query); onDismiss() }) { Text("Chat filter") } },
    )
}

@Composable
private fun ToolsDialog(tools: List<ToolSpec>, onDismiss: () -> Unit, onRefresh: () -> Unit) {
    val local = tools.count { it.server == null }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Agent tools (${tools.size})") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "Built-in $local · MCP ${tools.size - local}. Model inhe khud call karta hai.",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                tools.forEach { tool ->
                    Column(Modifier.padding(vertical = 5.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(tool.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            if (tool.server != null) {
                                Spacer(Modifier.width(6.dp))
                                Text("[MCP]", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        Text(
                            tool.description,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onRefresh) { Text("Refresh") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Band karein") } },
    )
}

@Composable
private fun McpDialog(
    servers: List<McpServer>,
    status: Map<String, String>,
    onDismiss: () -> Unit,
    onRefresh: () -> Unit,
    onToggle: (McpServer, Boolean) -> Unit,
    onManage: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("MCP servers") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (servers.isEmpty()) {
                    Text(
                        "Koi MCP server add nahi hai. Settings ▸ MCP mein streamable-HTTP server ka URL daalein " +
                            "(jaise https://mcp.example.com/mcp) — uske tools khud Agent mein aa jayenge.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                } else {
                    servers.forEach { server ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(server.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                Text(
                                    server.url,
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Text(
                                    status[server.url] ?: "—",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                            Switch(checked = server.enabled, onCheckedChange = { onToggle(server, it) })
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onRefresh) { Text("Connect / refresh") } },
        dismissButton = { TextButton(onClick = onManage) { Text("Manage") } },
    )
}

@Composable
private fun PerfDialog(perf: PerfStats, modelName: String?, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Stats") },
        text = {
            Column {
                StatRow("Model", modelName ?: "—")
                StatRow("Speed", if (perf.tokensPerSecond > 0f) "%.1f tok/s".format(perf.tokensPerSecond) else "—")
                StatRow("Last reply", "${perf.lastTokenCount} tokens")
                StatRow("App RAM (PSS)", formatBytes(perf.processRamBytes))
                StatRow("Free RAM", formatBytes(perf.systemAvailBytes))
                StatRow("Total RAM", formatBytes(perf.systemTotalBytes))
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Theek hai") } },
    )
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun MediaPromptDialog(kind: MessageKind, onDismiss: () -> Unit, onGenerate: (String) -> Unit) {
    var prompt by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (kind == MessageKind.VIDEO) "🎬 Video generate karein" else "🖼️ Image generate karein") },
        text = {
            Column {
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    label = { Text("Prompt") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Model id aur size Settings ▸ API se aate hain" +
                        if (kind == MessageKind.VIDEO) " (e.g. veo-3.0-generate-preview, sora-2)."
                        else " (e.g. gpt-image-1, dall-e-3).",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            Button(onClick = { if (prompt.isNotBlank()) onGenerate(prompt) }, enabled = prompt.isNotBlank()) { Text("Generate") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun EditDialog(initial: String, onDismiss: () -> Unit, onSend: (String) -> Unit) {
    var text by rememberSaveable(initial) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Message edit karein") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
            )
        },
        confirmButton = { Button(onClick = { if (text.isNotBlank()) onSend(text) }) { Text("Send") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// =============================================================================================
// Media gallery
// =============================================================================================

@Composable
fun GalleryScreen(viewModel: ChatViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val media by viewModel.media.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { viewModel.refreshMedia() }
    Column(Modifier.fillMaxSize()) {
        Surface(tonalElevation = 1.dp) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                Text("Gallery", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { viewModel.refreshMedia() }) { Icon(Icons.Filled.Refresh, contentDescription = "Refresh") }
            }
        }
        if (media.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Abhi koi image/video nahi bana.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp)) {
                items(media, key = { it.path }) { item ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                                    Text(
                                        "${formatBytes(item.sizeBytes)} · ${relativeTime(item.modified)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                IconButton(onClick = { viewModel.deleteMedia(item) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete")
                                }
                            }
                            MediaCard(path = item.path, onOpen = { openLocalFile(it, context) })
                        }
                    }
                }
            }
        }
    }
}

/** Lets MainActivity drive the same chat-filter field the drawer uses. */
@Composable
fun ChatSearchHost(viewModel: ChatViewModel, visible: Boolean, onDismiss: () -> Unit) {
    if (!visible) return
    SearchDialog(
        onDismiss = onDismiss,
        onFilterChat = { viewModel.setSessionQuery(it) },
        onWebSearch = { query ->
            onDismiss()
            viewModel.sendMessage("Web search karke batao: $query")
        },
    )
}
