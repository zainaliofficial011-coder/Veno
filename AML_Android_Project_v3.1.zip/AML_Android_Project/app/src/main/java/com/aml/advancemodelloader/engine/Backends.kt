package com.aml.advancemodelloader.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

// =============================================================================================
// Shared types for every backend (OpenAI-compatible, Anthropic, Gemini)
// =============================================================================================

enum class ProviderKind { LOCAL, OPENAI, ANTHROPIC, GEMINI }

enum class ReasoningLevel(val label: String) {
    OFF("Off"), LOW("Low"), MEDIUM("Medium"), HIGH("High");

    companion object {
        fun from(name: String): ReasoningLevel =
            entries.firstOrNull { it.name.equals(name, true) } ?: OFF
    }
}

/** A tool the model may call. `server` is set for tools that come from an MCP server. */
data class ToolSpec(
    val name: String,
    val description: String,
    val parameters: JSONObject,
    val server: String? = null,
)

/** A tool call the model asked for (already reassembled from the stream). */
data class ToolCallRequest(
    val id: String,
    val name: String,
    val arguments: JSONObject,
    val raw: String = arguments.toString(),
)

/** One turn of the transcript, in a provider-neutral shape. */
data class Turn(
    val role: String,
    val text: String = "",
    val images: List<String> = emptyList(),
    val toolCalls: List<ToolCallRequest> = emptyList(),
    val toolCallId: String? = null,
    val toolName: String? = null,
)

data class GenParams(
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val topK: Int = 40,
    val maxTokens: Int = 1024,
    val frequencyPenalty: Float = 0f,
    val presencePenalty: Float = 0f,
    val reasoning: ReasoningLevel = ReasoningLevel.OFF,
)

sealed interface ChatEvent {
    data class Text(val chunk: String) : ChatEvent
    data class Reasoning(val chunk: String) : ChatEvent
    data class Calls(val calls: List<ToolCallRequest>) : ChatEvent
    data object Done : ChatEvent
    data class Failure(val message: String) : ChatEvent
}

data class GeneratedMedia(val path: String, val kind: String, val prompt: String, val model: String)

class ApiException(message: String, cause: Throwable? = null) : java.io.IOException(message, cause)

/** Every provider implements this, so the ViewModel never branches on provider specifics. */
interface ChatBackend {
    val label: String
    val kind: ProviderKind

    fun chat(
        model: String,
        system: String,
        turns: List<Turn>,
        tools: List<ToolSpec>,
        params: GenParams,
        stream: Boolean,
    ): Flow<ChatEvent>

    suspend fun listModels(): List<String>

    /** Text-to-image. Empty list when the provider has no image endpoint. */
    suspend fun generateImage(model: String, prompt: String, size: String): List<GeneratedMedia>

    /** Text-to-video (job based when the server needs it). */
    suspend fun generateVideo(model: String, prompt: String, onProgress: (String) -> Unit): List<GeneratedMedia>
}

// =============================================================================================
// Provider presets
// =============================================================================================

data class ProviderPreset(
    val name: String,
    val kind: ProviderKind,
    val baseUrl: String,
    val defaultModel: String,
    val hint: String,
    /** Filled only for providers that ship an image endpoint. */
    val imageModel: String = "",
    /** Filled only for providers that ship a video endpoint. */
    val videoModel: String = "",
) {
    override fun toString(): String = name
}

object Presets {
    val all: List<ProviderPreset> = listOf(
        ProviderPreset("OpenAI", ProviderKind.OPENAI, "https://api.openai.com/v1", "gpt-4o-mini", "platform.openai.com", "gpt-image-1", "sora-2"),
        ProviderPreset("Anthropic (Claude)", ProviderKind.ANTHROPIC, "https://api.anthropic.com", "claude-sonnet-4-5", "console.anthropic.com"),
        ProviderPreset(
            "Google Gemini",
            ProviderKind.GEMINI,
            "https://generativelanguage.googleapis.com/v1beta",
            "gemini-2.5-flash",
            "aistudio.google.com",
            "imagen-4.0-generate-001",
            "veo-3.0-generate-preview",
        ),
        ProviderPreset("OpenRouter", ProviderKind.OPENAI, "https://openrouter.ai/api/v1", "openai/gpt-4o-mini", "openrouter.ai/keys"),
        ProviderPreset("Groq", ProviderKind.OPENAI, "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile", "console.groq.com"),
        ProviderPreset("DeepSeek", ProviderKind.OPENAI, "https://api.deepseek.com/v1", "deepseek-chat", "platform.deepseek.com"),
        ProviderPreset("xAI (Grok)", ProviderKind.OPENAI, "https://api.x.ai/v1", "grok-3-mini", "console.x.ai"),
        ProviderPreset("Mistral", ProviderKind.OPENAI, "https://api.mistral.ai/v1", "mistral-large-latest", "console.mistral.ai"),
        ProviderPreset("Together", ProviderKind.OPENAI, "https://api.together.xyz/v1", "meta-llama/Llama-3.3-70B-Instruct-Turbo", "api.together.xyz"),
        ProviderPreset("Ollama (PC/LAN)", ProviderKind.OPENAI, "http://192.168.1.2:11434/v1", "llama3.1:8b", "koi key nahi"),
        ProviderPreset("LM Studio (LAN)", ProviderKind.OPENAI, "http://192.168.1.2:1234/v1", "local-model", "koi key nahi"),
        ProviderPreset("llama.cpp server", ProviderKind.OPENAI, "http://192.168.1.2:8080/v1", "local-model", "koi key nahi"),
        ProviderPreset("vLLM (LAN)", ProviderKind.OPENAI, "http://192.168.1.2:8000/v1", "local-model", "koi key nahi"),
        ProviderPreset("Custom / OpenAI-compatible", ProviderKind.OPENAI, "", "", "apna endpoint"),
    )

    fun find(name: String): ProviderPreset? = all.firstOrNull { it.name.equals(name, true) }

    fun kindOf(name: String): ProviderKind = find(name)?.kind ?: ProviderKind.OPENAI
}

/** Builds the right backend for a settings snapshot. */
object Backends {
    fun create(
        kind: ProviderKind,
        baseUrl: () -> String,
        apiKey: () -> String,
        mediaDir: () -> File,
        imageModel: () -> String = { "" },
        videoModel: () -> String = { "" },
    ): ChatBackend = when (kind) {
        ProviderKind.ANTHROPIC -> AnthropicClient(baseUrl, apiKey)
        ProviderKind.GEMINI -> GeminiClient(baseUrl, apiKey, mediaDir)
        // LOCAL is built by the ViewModel (it needs the loaded engine); this keeps the compiler happy.
        ProviderKind.OPENAI, ProviderKind.LOCAL ->
            OpenAiClient(mediaDir, baseUrl, apiKey, imageModel, videoModel)
    }
}

// =============================================================================================
// Tiny HTTP + SSE helpers shared by the clients
// =============================================================================================

internal object Http {

    fun open(url: String, method: String, accept: String): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 25_000
        conn.readTimeout = 600_000
        conn.doInput = true
        conn.setRequestProperty("Accept", accept)
        conn.setRequestProperty("User-Agent", "AML-Android/3.0")
        return conn
    }

    fun send(
        url: String,
        method: String,
        body: JSONObject?,
        accept: String,
        headers: Map<String, String> = emptyMap(),
    ): HttpURLConnection {
        val conn = open(url, method, accept)
        headers.forEach { (k, v) -> if (v.isNotBlank()) conn.setRequestProperty(k, v) }
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { out: OutputStream -> out.write(body.toString().toByteArray(Charsets.UTF_8)) }
        }
        return conn
    }

    fun text(stream: InputStream?): String =
        stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

    /** Reads an SSE response and calls [onData] for every `data:` payload. */
    fun sse(input: InputStream, stop: () -> Boolean, onData: (String) -> Unit) {
        val reader = BufferedReader(InputStreamReader(input, Charsets.UTF_8), 16 * 1024)
        while (!stop()) {
            val line = reader.readLine() ?: break
            if (line.isEmpty() || line.startsWith(":")) continue
            if (!line.startsWith("data:")) continue
            val payload = line.removePrefix("data:").trim()
            if (payload.isEmpty() || payload == "[DONE]") continue
            onData(payload)
        }
    }

    fun errorFrom(code: Int, body: String, provider: String): ApiException {
        val message = runCatching {
            val json = JSONObject(body)
            json.optJSONObject("error")?.optString("message")
                ?: json.optJSONArray("error")?.optJSONObject(0)?.optString("message")
                ?: json.optJSONObject("error")?.optString("status")
                ?: json.optString("message")
                ?: json.optString("detail")
        }.getOrNull().orEmpty().ifBlank { body.take(300) }
        val hint = when (code) {
            401, 403 -> " — API key check karein (Settings ▸ API key)."
            404 -> " — endpoint/model id check karein."
            429 -> " — rate limit ya quota."
            else -> ""
        }
        return ApiException("$provider HTTP $code: $message$hint")
    }

    fun joinUrl(base: String, path: String): String {
        val b = base.trim().trimEnd('/')
        val p = path.trimStart('/')
        return if (b.isEmpty()) p else "$b/$p"
    }

    fun streamFlow(block: suspend kotlinx.coroutines.flow.FlowCollector<ChatEvent>.() -> Unit): Flow<ChatEvent> =
        flow { block() }.flowOn(Dispatchers.IO)
}

/** Reassembles streamed tool-call fragments (OpenAI sends name/arguments in pieces). */
internal class CallAssembler {
    private val ids = LinkedHashMap<Int, String>()
    private val names = LinkedHashMap<Int, String>()
    private val args = LinkedHashMap<Int, StringBuilder>()

    fun add(index: Int, id: String?, name: String?, arguments: String?) {
        id?.let { ids[index] = it }
        name?.let { names[index] = (names[index] ?: "") + it }
        arguments?.let { args.getOrPut(index) { StringBuilder() }.append(it) }
    }

    fun isEmpty(): Boolean = names.isEmpty() && args.isEmpty()

    fun build(): List<ToolCallRequest> = names.keys.sorted().mapNotNull { index ->
        val name = names[index]?.trim() ?: return@mapNotNull null
        val raw = args[index]?.toString().orEmpty().ifBlank { "{}" }
        val json = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
        ToolCallRequest(id = ids[index] ?: "call_$index", name = name, arguments = json, raw = raw)
    }

    fun clear() {
        ids.clear(); names.clear(); args.clear()
    }
}

/** Shared JSON helpers. */
internal object Js {
    fun arrayOfNullsOrEmpty(node: JSONArray?): List<JSONObject> =
        if (node == null) emptyList() else (0 until node.length()).mapNotNull { node.optJSONObject(it) }

    fun params(vararg pairs: Pair<String, String>, required: List<String> = emptyList()): JSONObject {
        val props = JSONObject()
        pairs.forEach { (name, description) ->
            props.put(name, JSONObject().put("type", "string").put("description", description))
        }
        val json = JSONObject().put("type", "object").put("properties", props)
        if (required.isNotEmpty()) json.put("required", JSONArray(required))
        return json
    }
}
