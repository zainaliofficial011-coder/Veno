package com.aml.advancemodelloader.engine

import android.util.Base64
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Any OpenAI-compatible server: OpenAI, Groq, OpenRouter, DeepSeek, xAI, Mistral, Together, Ollama,
 * LM Studio, llama.cpp server, vLLM, LocalAI … Also carries the image/video endpoints.
 */
class OpenAiClient(
    private val mediaDir: () -> File,
    private val baseUrl: () -> String,
    private val apiKey: () -> String,
    private val imageModel: () -> String = { "" },
    private val videoModel: () -> String = { "" },
) : ChatBackend {

    override val label = "OpenAI-compatible"
    override val kind = ProviderKind.OPENAI

    fun imageModelId(): String = imageModel()
    fun videoModelId(): String = videoModel()

    private fun headers(): Map<String, String> {
        val key = apiKey().trim()
        val map = mutableMapOf<String, String>()
        if (key.isNotEmpty()) map["Authorization"] = "Bearer $key"
        // OpenRouter likes these; harmless elsewhere.
        map["HTTP-Referer"] = "https://github.com/zainaliofficial011-coder/Veno"
        map["X-Title"] = "AML"
        return map
    }

    fun endpoint(path: String): String = Http.joinUrl(baseUrl(), path)

    // -----------------------------------------------------------------------------------------
    // Chat
    // -----------------------------------------------------------------------------------------

    override fun chat(
        model: String,
        system: String,
        turns: List<Turn>,
        tools: List<ToolSpec>,
        params: GenParams,
        stream: Boolean,
    ): Flow<ChatEvent> = flow {
        val body = chatBody(model, system, turns, tools, params, stream)
        val conn = Http.send(endpoint("chat/completions"), "POST", body, "text/event-stream, application/json", headers())
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw Http.errorFrom(code, Http.text(conn.errorStream), "OpenAI")
            if (!stream) {
                parseWhole(Http.text(conn.inputStream)).forEach { emit(it) }
                emit(ChatEvent.Done)
                return@flow
            }
            val assembler = CallAssembler()
            val buffered = mutableListOf<ChatEvent>()
            Http.sse(conn.inputStream, { !currentCoroutineContext().isActive }) { payload ->
                val json = runCatching { JSONObject(payload) }.getOrNull() ?: return@sse
                json.optJSONObject("error")?.let { buffered += ChatEvent.Failure(it.optString("message")) }
                val choice = json.optJSONArray("choices")?.optJSONObject(0) ?: return@sse
                val delta = choice.optJSONObject("delta") ?: JSONObject()
                delta.optString("content").takeIf { it.isNotEmpty() }?.let { buffered += ChatEvent.Text(it) }
                val reasoning = delta.optString("reasoning_content").ifBlank { delta.optString("reasoning") }
                reasoning.takeIf { it.isNotEmpty() }?.let { buffered += ChatEvent.Reasoning(it) }
                delta.optJSONArray("tool_calls")?.let { arr ->
                    Js.arrayOfNullsOrEmpty(arr).forEach { call ->
                        val fn = call.optJSONObject("function") ?: JSONObject()
                        assembler.add(
                            index = call.optInt("index", 0),
                            id = call.optString("id").takeIf { it.isNotBlank() },
                            name = fn.optString("name").takeIf { it.isNotBlank() },
                            arguments = fn.optString("arguments").takeIf { it.isNotEmpty() },
                        )
                    }
                }
            }
            buffered.forEach { emit(it) }
            if (!assembler.isEmpty()) emit(ChatEvent.Calls(assembler.build()))
            emit(ChatEvent.Done)
        } finally {
            conn.disconnect()
        }
    }.flowOn(kotlinx.coroutines.Dispatchers.IO)

    private fun chatBody(
        model: String,
        system: String,
        turns: List<Turn>,
        tools: List<ToolSpec>,
        params: GenParams,
        stream: Boolean,
    ): JSONObject {
        val json = JSONObject()
        json.put("model", model)
        json.put("stream", stream)
        json.put("temperature", params.temperature.toDouble())
        json.put("top_p", params.topP.toDouble())
        json.put("max_tokens", params.maxTokens)
        if (params.frequencyPenalty != 0f) json.put("frequency_penalty", params.frequencyPenalty.toDouble())
        if (params.presencePenalty != 0f) json.put("presence_penalty", params.presencePenalty.toDouble())
        if (params.reasoning != ReasoningLevel.OFF) {
            json.put("reasoning_effort", params.reasoning.label.lowercase())
        }

        val messages = JSONArray()
        if (system.isNotBlank()) messages.put(JSONObject().put("role", "system").put("content", system))
        for (turn in turns) {
            val obj = JSONObject().put("role", turn.role)
            when {
                turn.images.isNotEmpty() -> {
                    val parts = JSONArray()
                    if (turn.text.isNotBlank()) parts.put(JSONObject().put("type", "text").put("text", turn.text))
                    turn.images.forEach { path ->
                        ApiClient.fileToDataUrl(File(path))?.let { data ->
                            parts.put(
                                JSONObject().put("type", "image_url")
                                    .put("image_url", JSONObject().put("url", data)),
                            )
                        }
                    }
                    obj.put("content", parts)
                }
                else -> obj.put("content", turn.text)
            }
            turn.toolCallId?.let { obj.put("tool_call_id", it) }
            if (turn.toolCalls.isNotEmpty()) {
                val calls = JSONArray()
                turn.toolCalls.forEach { call ->
                    calls.put(
                        JSONObject().put("id", call.id).put("type", "function")
                            .put(
                                "function",
                                JSONObject().put("name", call.name).put("arguments", call.raw),
                            ),
                    )
                }
                obj.put("tool_calls", calls)
                if (turn.text.isBlank()) obj.put("content", JSONObject.NULL)
            }
            messages.put(obj)
        }
        json.put("messages", messages)

        if (tools.isNotEmpty()) {
            val arr = JSONArray()
            tools.forEach { tool ->
                arr.put(
                    JSONObject().put("type", "function").put(
                        "function",
                        JSONObject().put("name", tool.name)
                            .put("description", tool.description)
                            .put("parameters", tool.parameters),
                    ),
                )
            }
            json.put("tools", arr)
            json.put("tool_choice", "auto")
        }
        return json
    }

    private fun parseWhole(body: String): List<ChatEvent> {
        if (body.isBlank()) return emptyList()
        val json = runCatching { JSONObject(body) }.getOrNull() ?: return emptyList()
        json.optJSONObject("error")?.let { return listOf(ChatEvent.Failure(it.optString("message"))) }
        val message = json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message") ?: return emptyList()
        val out = mutableListOf<ChatEvent>()
        message.optString("content").takeIf { it.isNotEmpty() }?.let { out += ChatEvent.Text(it) }
        val reasoning = message.optString("reasoning_content").ifBlank { message.optString("reasoning") }
        reasoning.takeIf { it.isNotEmpty() }?.let { out += ChatEvent.Reasoning(it) }
        message.optJSONArray("tool_calls")?.let { arr ->
            val calls = Js.arrayOfNullsOrEmpty(arr).mapIndexedNotNull { index, call ->
                val fn = call.optJSONObject("function") ?: return@mapIndexedNotNull null
                val raw = fn.optString("arguments").ifBlank { "{}" }
                ToolCallRequest(
                    id = call.optString("id").ifBlank { "call_$index" },
                    name = fn.optString("name"),
                    arguments = runCatching { JSONObject(raw) }.getOrElse { JSONObject() },
                    raw = raw,
                )
            }
            if (calls.isNotEmpty()) out += ChatEvent.Calls(calls)
        }
        return out
    }

    // -----------------------------------------------------------------------------------------
    // Models
    // -----------------------------------------------------------------------------------------

    override suspend fun listModels(): List<String> {
        val conn = Http.open(endpoint("models"), "GET", "application/json")
        headers().forEach { (k, v) -> conn.setRequestProperty(k, v) }
        return try {
            val code = conn.responseCode
            val body = Http.text(if (code in 200..299) conn.inputStream else conn.errorStream)
            if (code !in 200..299) throw Http.errorFrom(code, body, "OpenAI")
            val arr = runCatching { JSONObject(body).optJSONArray("data") }.getOrNull() ?: return emptyList()
            Js.arrayOfNullsOrEmpty(arr).mapNotNull { it.optString("id").takeIf { id -> id.isNotBlank() } }.sorted()
        } finally {
            conn.disconnect()
        }
    }

    // -----------------------------------------------------------------------------------------
    // Image / video generation
    // -----------------------------------------------------------------------------------------

    override suspend fun generateImage(model: String, prompt: String, size: String): List<GeneratedMedia> {
        if (model.isBlank()) throw ApiException("Image model id khali hai — Settings ▸ Image model set karein.")
        val attempt = { withFormat: Boolean ->
            val body = JSONObject().put("model", model).put("prompt", prompt).put("n", 1)
            if (size.isNotBlank()) body.put("size", size)
            if (withFormat) body.put("response_format", "b64_json")
            val conn = Http.send(endpoint("images/generations"), "POST", body, "application/json", headers())
            try {
                val code = conn.responseCode
                val text = Http.text(if (code in 200..299) conn.inputStream else conn.errorStream)
                if (code !in 200..299) throw Http.errorFrom(code, text, "Image")
                text
            } finally {
                conn.disconnect()
            }
        }
        val raw = try {
            attempt(true)
        } catch (e: ApiException) {
            if (e.message?.contains("response_format") == true) attempt(false) else throw e
        }
        val saved = saveImageResponse(raw, model, prompt)
        if (saved.isEmpty()) throw ApiException("Image response mein koi image nahi mili.")
        return saved
    }

    private fun saveImageResponse(raw: String, model: String, prompt: String): List<GeneratedMedia> {
        val json = runCatching { JSONObject(raw) }.getOrNull() ?: return emptyList()
        val out = mutableListOf<GeneratedMedia>()
        val data = json.optJSONArray("data") ?: JSONArray().put(json)
        Js.arrayOfNullsOrEmpty(data).forEach { item ->
            item.optString("b64_json").takeIf { it.isNotBlank() }?.let { b64 ->
                runCatching { ApiClient.saveBase64(mediaDir(), b64, "image", prompt, model) }.getOrNull()?.let { out += it }
            }
            item.optString("url").takeIf { it.startsWith("http") }?.let { url ->
                runCatching { ApiClient.download(mediaDir(), url, "image", prompt, model) }.getOrNull()?.let { out += it }
            }
        }
        return out
    }

    override suspend fun generateVideo(model: String, prompt: String, onProgress: (String) -> Unit): List<GeneratedMedia> {
        if (model.isBlank()) throw ApiException("Video model id khali hai — Settings ▸ Video model set karein.")
        val first = postRaw(endpoint("video/generations"), JSONObject().put("model", model).put("prompt", prompt))
        directAssets(first, model, prompt)?.let { return it }

        val jobId = findString(first, "id", "task_id", "job_id", "request_id")
            ?: throw ApiException("Video API ne job id ya asset nahi diya: ${first.take(200)}")
        val paths = listOf("video/generations/$jobId", "videos/$jobId", "video/generations/$jobId/status")
        var lastStatus = ""
        val deadline = System.currentTimeMillis() + 10 * 60_000
        while (System.currentTimeMillis() < deadline) {
            var payload = ""
            var lastError: Throwable? = null
            for (path in paths) {
                try {
                    payload = getRaw(endpoint(path)); lastError = null; break
                } catch (t: Throwable) {
                    lastError = t
                }
            }
            if (payload.isBlank()) throw (lastError ?: ApiException("Video status check fail hua."))
            directAssets(payload, model, prompt)?.let { return it }
            val status = findString(payload, "status", "state")?.lowercase().orEmpty()
            if (status != lastStatus) {
                lastStatus = status
                onProgress(status.ifBlank { "processing" })
            }
            if (status.contains("fail") || status.contains("error")) {
                throw ApiException("Video generation fail hui: ${findString(payload, "error", "message").orEmpty()}")
            }
            delay(6_000)
        }
        throw ApiException("Video 10 minute mein ready nahi hui (job $jobId).")
    }

    private fun postRaw(url: String, body: JSONObject): String {
        val conn = Http.send(url, "POST", body, "application/json", headers())
        return try {
            val code = conn.responseCode
            val text = Http.text(if (code in 200..299) conn.inputStream else conn.errorStream)
            if (code !in 200..299) throw Http.errorFrom(code, text, "Video")
            text
        } finally {
            conn.disconnect()
        }
    }

    private fun getRaw(url: String): String {
        val conn = Http.open(url, "GET", "application/json")
        headers().forEach { (k, v) -> conn.setRequestProperty(k, v) }
        return try {
            val code = conn.responseCode
            val text = Http.text(if (code in 200..299) conn.inputStream else conn.errorStream)
            if (code !in 200..299) throw Http.errorFrom(code, text, "Video")
            text
        } finally {
            conn.disconnect()
        }
    }

    /** Returns finished media from a payload, or null while the job is still running. */
    private fun directAssets(payload: String, model: String, prompt: String): List<GeneratedMedia>? {
        if (payload.isBlank()) return null
        val json = runCatching { JSONObject(payload) }.getOrNull() ?: return null
        val status = findString(json, "status", "state")?.lowercase().orEmpty()
        if (status.contains("fail") || status.contains("error")) {
            throw ApiException("Generation fail hui: ${findString(json, "error", "message").orEmpty()}")
        }
        val urls = mutableListOf<String>()
        val b64s = mutableListOf<String>()
        collect(json, urls, b64s)
        if (urls.isEmpty() && b64s.isEmpty()) return null
        val out = mutableListOf<GeneratedMedia>()
        urls.forEach { url -> runCatching { ApiClient.download(mediaDir(), url, "video", prompt, model) }.getOrNull()?.let { out += it } }
        b64s.forEach { data -> runCatching { ApiClient.saveBase64(mediaDir(), data, "video", prompt, model) }.getOrNull()?.let { out += it } }
        return out.ifEmpty { null }
    }

    private fun collect(node: Any?, urls: MutableList<String>, b64s: MutableList<String>) {
        when (node) {
            is JSONObject -> node.keys().forEach { key ->
                val value = node.opt(key)
                when {
                    value is String && key.contains("url", true) && value.startsWith("http") -> urls += value
                    value is String && value.startsWith("http") && (value.contains(".mp4") || value.contains(".webm")) -> urls += value
                    value is String && (key.contains("b64", true) || value.length > 512 && !value.startsWith("http")) -> b64s += value
                    else -> collect(value, urls, b64s)
                }
            }
            is JSONArray -> for (i in 0 until node.length()) collect(node.opt(i), urls, b64s)
        }
    }

    private fun findString(node: Any?, vararg keys: String): String? {
        when (node) {
            is JSONObject -> {
                keys.forEach { key ->
                    val value = node.optString(key)
                    if (value.isNotBlank() && !value.equals("null", true)) return value
                }
                node.keys().forEach { key -> findString(node.opt(key), *keys)?.let { return it } }
            }
            is JSONArray -> for (i in 0 until node.length()) findString(node.opt(i), *keys)?.let { return it }
        }
        return null
    }
}

/** Small helpers shared by the OpenAI-compatible client and the tools (kept from v2). */
object ApiClient {

    private const val MAX_EDGE = 1_600

    /** Reads a local image as a `data:` URL. Big files are downscaled so vision requests stay small. */
    fun fileToDataUrl(file: File): String? {
        if (!file.exists() || file.length() == 0L) return null
        val mime = when (file.extension.lowercase()) {
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            else -> "image/jpeg"
        }
        val bytes = runCatching { file.readBytes() }.getOrNull() ?: return null
        return "data:$mime;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    fun saveBase64(dir: File, data: String, kind: String, prompt: String, model: String): GeneratedMedia {
        val clean = data.substringAfter("base64,", data)
        val bytes = Base64.decode(clean, Base64.DEFAULT)
        dir.mkdirs()
        val ext = if (kind == "video") "mp4" else "png"
        val file = File(dir, "aml_${kind}_${System.currentTimeMillis()}.$ext")
        file.writeBytes(bytes)
        return GeneratedMedia(file.absolutePath, kind, prompt, model)
    }

    fun download(dir: File, url: String, kind: String, prompt: String = "", model: String = ""): GeneratedMedia {
        val conn = Http.open(url, "GET", "*/*")
        return try {
            val code = conn.responseCode
            if (code !in 200..299) throw ApiException("Download failed: HTTP $code")
            val ext = url.substringAfterLast('.', "").take(4).let { candidate ->
                if (candidate.length in 2..4 && candidate.all { it.isLetterOrDigit() }) candidate
                else if (kind == "video") "mp4" else "png"
            }
            dir.mkdirs()
            val file = File(dir, "aml_${kind}_${System.currentTimeMillis()}.$ext")
            conn.inputStream.use { input -> file.outputStream().use { input.copyTo(it) } }
            GeneratedMedia(file.absolutePath, kind, prompt, model)
        } finally {
            conn.disconnect()
        }
    }
}
