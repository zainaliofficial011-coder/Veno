package com.aml.advancemodelloader.ui

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File

/** MIME type for a file name; good enough for ACTION_VIEW / ACTION_SEND / MediaStore. */
fun mimeOf(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
    "png" -> "image/png"
    "jpg", "jpeg" -> "image/jpeg"
    "webp" -> "image/webp"
    "gif" -> "image/gif"
    "mp4" -> "video/mp4"
    "webm" -> "video/webm"
    "mkv" -> "video/x-matroska"
    "zip" -> "application/zip"
    "pdf" -> "application/pdf"
    "json" -> "application/json"
    "md", "txt", "csv", "log", "html", "xml", "kt", "java", "py", "js", "sh" -> "text/plain"
    else -> "*/*"
}

/** Hands a file in app storage to another app through a content:// URI. */
fun openLocalFile(path: String, context: Context) {
    val file = File(path)
    if (!file.exists()) return
    val uri: Uri = runCatching {
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }.getOrElse { Uri.fromFile(file) }
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, mimeOf(path))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    runCatching { context.startActivity(intent) }
        .onFailure {
            runCatching {
                context.startActivity(Intent.createChooser(intent, file.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
}

/** Shares any text (a chat export, a reply, a link) through the Android share sheet. */
fun shareText(context: Context, text: String, subject: String = "AML") {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, subject)
        putExtra(Intent.EXTRA_TEXT, text)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    runCatching { context.startActivity(Intent.createChooser(intent, subject).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

/** Opens any http(s) / geo / tel link in the matching app. */
fun openUrl(url: String, context: Context) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(intent) }
}

/** Writes a text file into Downloads/AML (Android 10+) and returns the human readable location. */
fun saveToDownloads(context: Context, displayName: String, mime: String, content: String): String? = runCatching {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AML")
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return@runCatching null
        resolver.openOutputStream(uri)?.use { out -> out.write(content.toByteArray(Charsets.UTF_8)) }
        "Downloads/AML/$displayName"
    } else {
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "AML")
        if (!dir.exists() && !dir.mkdirs()) return@runCatching null
        File(dir, displayName).writeText(content)
        File(dir, displayName).absolutePath
    }
}.getOrNull()
