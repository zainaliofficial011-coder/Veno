package com.aml.advancemodelloader.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aml.advancemodelloader.BuildConfig
import com.aml.advancemodelloader.data.AccentColor
import com.aml.advancemodelloader.data.AppSettings
import com.aml.advancemodelloader.data.BackendKind
import com.aml.advancemodelloader.data.Persona
import com.aml.advancemodelloader.data.ThemeMode
import com.aml.advancemodelloader.engine.McpServer
import com.aml.advancemodelloader.engine.Presets
import com.aml.advancemodelloader.engine.ProviderKind
import com.aml.advancemodelloader.engine.ReasoningLevel
import java.io.File

private val SECTIONS = listOf(
    "local" to "Local",
    "api" to "API",
    "generation" to "Generation",
    "system" to "System",
    "agent" to "Agent",
    "mcp" to "MCP",
    "voice" to "Voice",
    "appearance" to "Look",
    "about" to "About",
)

/** Everything heavy lives here — the chat screen only keeps quick shortcuts. */
@Composable
fun SettingsScreen(
    viewModel: ChatViewModel,
    onBack: () -> Unit,
    initialSection: String = "system",
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val loadedModel by viewModel.loadedModel.collectAsStateWithLifecycle()
    val picker by viewModel.picker.collectAsStateWithLifecycle()
    val apiModels by viewModel.apiModels.collectAsStateWithLifecycle()
    val mcpStatus by viewModel.mcpStatus.collectAsStateWithLifecycle()
    val busy by viewModel.busy.collectAsStateWithLifecycle()

    var section by rememberSaveable { mutableStateOf(initialSection) }
    var showPersonaEditor by remember { mutableStateOf<Persona?>(null) }
    var showModelList by remember { mutableStateOf(false) }

    fun apply(new: AppSettings) = viewModel.updateSettings(new)

    Column(Modifier.fillMaxSize()) {
        Surface(tonalElevation = 1.dp) {
            Column {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                    Text("Settings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    busy?.let {
                        Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                        Spacer(Modifier.width(8.dp))
                    }
                    IconButton(onClick = { viewModel.refreshModels() }) { Icon(Icons.Filled.Refresh, contentDescription = "Refresh models") }
                }
                ScrollableTabRow(selectedTabIndex = SECTIONS.indexOfFirst { it.first == section }.coerceAtLeast(0), edgePadding = 8.dp) {
                    SECTIONS.forEach { (id, label) ->
                        Tab(
                            selected = section == id,
                            onClick = { section = id },
                            text = { Text(label, style = MaterialTheme.typography.labelMedium) },
                        )
                    }
                }
            }
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            when (section) {
                "local" -> LocalSection(settings, loadedModel?.name, picker.models, ::apply, viewModel)
                "api" -> ApiSection(
                    settings = settings,
                    models = apiModels,
                    onApply = ::apply,
                    onTest = { viewModel.testConnection() },
                    onListModels = { showModelList = true },
                    onImportModel = { id -> apply(settings.copy(apiModelId = id)) },
                )
                "generation" -> GenerationSection(settings, ::apply)
                "system" -> SystemSection(settings, ::apply, onEditPersona = { showPersonaEditor = it }, viewModel = viewModel)
                "agent" -> AgentSection(settings, ::apply)
                "mcp" -> McpSection(settings, ::apply, mcpStatus, viewModel)
                "voice" -> VoiceSection(settings, ::apply)
                "appearance" -> AppearanceSection(settings, ::apply)
                "about" -> AboutSection()
            }
            Spacer(Modifier.height(40.dp))
        }
    }

    showPersonaEditor?.let { persona ->
        PersonaDialog(
            persona = persona,
            onDismiss = { showPersonaEditor = null },
            onSave = { edited ->
                viewModel.savePersona(edited)
                showPersonaEditor = null
            },
        )
    }
    if (showModelList) {
        ModelListDialog(
            models = apiModels,
            onDismiss = { showModelList = false },
            onPick = { id ->
                apply(settings.copy(apiModelId = id))
                showModelList = false
            },
        )
    }
}

// =============================================================================================
// Local GGUF
// =============================================================================================

@Composable
private fun LocalSection(
    settings: AppSettings,
    loadedName: String?,
    models: List<ModelFile>,
    onApply: (AppSettings) -> Unit,
    viewModel: ChatViewModel,
) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) viewModel.importModel(uri)
    }

    SectionTitle("Backend")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ChoiceChip("Local GGUF", settings.backend == BackendKind.LOCAL_GGUF) {
            onApply(settings.copy(backend = BackendKind.LOCAL_GGUF))
            viewModel.useLocalBackend()
        }
        ChoiceChip("API", settings.backend == BackendKind.API) {
            onApply(settings.copy(backend = BackendKind.API))
            viewModel.useApiBackend()
        }
    }
    Hint("Local: llama.cpp phone par offline chalta hai. API: internet wala koi bhi provider.")

    SectionTitle("Model file")
    Hint(if (loadedName != null) "Loaded: $loadedName" else "Koi model load nahi hai.")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("GGUF select karein") }
        if (loadedName != null) OutlinedButton(onClick = { viewModel.unloadModel() }) { Text("Unload") }
    }
    if (models.isNotEmpty()) {
        Spacer(Modifier.height(10.dp))
        models.forEach { model ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(model.name, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(formatBytes(model.sizeBytes), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = { viewModel.loadModel(model) }) { Text("Load") }
                IconButton(onClick = { viewModel.deleteModel(model) }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
            }
        }
    }

    SectionTitle("Context window")
    IntSlider("Context (tokens)", settings.contextSize, 1024..32768, 1024, 4096) {
        onApply(settings.copy(contextSize = it))
    }
    IntSlider("Threads", settings.threads, 1..12, 1, Runtime.getRuntime().availableProcessors().coerceAtLeast(2)) {
        onApply(settings.copy(threads = it))
    }
    SwitchRow("Memory-map the file (fast, recommended)", settings.useMmap) { onApply(settings.copy(useMmap = it)) }

    SectionTitle("Prompt template")
    Hint("Auto file name se guess karta hai (Qwen/SmolLM → ChatML, Llama 3 → Llama 3, Gemma → Gemma).")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("auto", "chatml", "llama3", "gemma").forEach { option ->
            ChoiceChip(option, settings.localTemplate == option) { onApply(settings.copy(localTemplate = option)) }
        }
    }
    Hint("Bade model (7B+) ke liye 4-bit quant (Q4_K_M) sabse behtar balance hai.")
}

// =============================================================================================
// API
// =============================================================================================

@Composable
private fun ApiSection(
    settings: AppSettings,
    models: List<String>,
    onApply: (AppSettings) -> Unit,
    onTest: () -> Unit,
    onListModels: () -> Unit,
    onImportModel: (String) -> Unit,
) {
    SectionTitle("Provider preset")
    Column {
        Presets.all.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { preset ->
                    val selected = settings.provider == preset.name
                    Surface(
                        color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.weight(1f).clickable {
                            onApply(
                                settings.copy(
                                    provider = preset.name,
                                    providerKind = preset.kind,
                                    apiBaseUrl = preset.baseUrl,
                                    apiModelId = preset.defaultModel.ifBlank { settings.apiModelId },
                                    imageModelId = preset.imageModel.ifBlank { settings.imageModelId },
                                    videoModelId = preset.videoModel.ifBlank { settings.videoModelId },
                                ),
                            )
                        },
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Text(preset.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                preset.baseUrl,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }

    SectionTitle("Connection")
    TextField("Base URL", settings.apiBaseUrl, "https://api.openai.com/v1") { onApply(settings.copy(apiBaseUrl = it.trim())) }
    SecretField("API key", settings.apiKey) { onApply(settings.copy(apiKey = it.trim())) }
    TextField("Chat model id", settings.apiModelId, "gpt-4o-mini") { onApply(settings.copy(apiModelId = it.trim())) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onTest) { Text("Test / connect") }
        OutlinedButton(onClick = onListModels, enabled = models.isNotEmpty()) { Text("Models (${models.size})") }
    }
    if (models.isNotEmpty()) {
        Hint("Server ke models: ${models.take(6).joinToString(", ")}${if (models.size > 6) " …" else ""}")
        TextButton(onClick = { onImportModel(models.first()) }) { Text("Pehla model use karein") }
    }

    SectionTitle("Media generation")
    TextField("Image model id", settings.imageModelId, "gpt-image-1 / dall-e-3") { onApply(settings.copy(imageModelId = it.trim())) }
    TextField("Video model id", settings.videoModelId, "sora-2 / veo-3.0-generate-preview") { onApply(settings.copy(videoModelId = it.trim())) }
    TextField("Image size", settings.imageSize, "1024x1024") { onApply(settings.copy(imageSize = it.trim())) }
    Hint("Image/video ke liye API backend zaroori hai. Gemini par Imagen/Veo, OpenAI par gpt-image-1/Sora chalti hai.")

    SectionTitle("Streaming + tools")
    SwitchRow("Stream replies (SSE)", settings.streamApi) { onApply(settings.copy(streamApi = it)) }
    SwitchRow("Native tool calling (function calling)", settings.useNativeTools) { onApply(settings.copy(useNativeTools = it)) }
    Hint("Off karne par AML text protocol (<tool_call> blocks) use karta hai — har provider par chalta hai.")
}

// =============================================================================================
// Generation
// =============================================================================================

@Composable
private fun GenerationSection(settings: AppSettings, onApply: (AppSettings) -> Unit) {
    SectionTitle("Sampling")
    FloatSlider("Temperature", settings.temperature, 0f..2f, 0.05f) { onApply(settings.copy(temperature = it)) }
    FloatSlider("Top-p", settings.topP, 0.05f..1f, 0.05f) { onApply(settings.copy(topP = it)) }
    IntSlider("Top-k", settings.topK, 0..100, 1, 40) { onApply(settings.copy(topK = it)) }
    IntSlider("Max new tokens", settings.maxNewTokens, 128..8192, 128, 1024) { onApply(settings.copy(maxNewTokens = it)) }
    FloatSlider("Frequency penalty", settings.frequencyPenalty, -2f..2f, 0.1f) { onApply(settings.copy(frequencyPenalty = it)) }
    FloatSlider("Presence penalty", settings.presencePenalty, -2f..2f, 0.1f) { onApply(settings.copy(presencePenalty = it)) }
    Hint("Temperature 0 = deterministic. Coding ke liye 0.2–0.4, creative writing ke liye 0.8–1.1.")

    SectionTitle("Thinking / reasoning")
    SwitchRow("Thinking mode on", settings.thinkingEnabled) { onApply(settings.copy(thinkingEnabled = it)) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ReasoningLevel.entries.forEach { level ->
            ChoiceChip(level.label, settings.reasoning == level) { onApply(settings.copy(reasoning = level)) }
        }
    }
    Hint(
        "OpenAI: reasoning_effort · Anthropic: thinking budget (1024/4096/8192) · Gemini: thinkingConfig. " +
            "Local model <thinking>…</thinking> block mein sochta hai, jo chat mein alag dikhta hai.",
    )

    SectionTitle("Agent loop")
    IntSlider("Max tool iterations", settings.maxToolIterations, 1..12, 1, 6) { onApply(settings.copy(maxToolIterations = it)) }
    IntSlider("Tool result limit (chars)", settings.toolResultLimit, 1000..20000, 500, 6000) { onApply(settings.copy(toolResultLimit = it)) }
}

// =============================================================================================
// System prompt, personas, memory
// =============================================================================================

@Composable
private fun SystemSection(
    settings: AppSettings,
    onApply: (AppSettings) -> Unit,
    onEditPersona: (Persona) -> Unit,
    viewModel: ChatViewModel,
) {
    SectionTitle("System prompt")
    OutlinedTextField(
        value = settings.systemPrompt,
        onValueChange = { onApply(settings.copy(systemPrompt = it)) },
        modifier = Modifier.fillMaxWidth(),
        minLines = 5,
        shape = RoundedCornerShape(14.dp),
    )
    Hint("Yahi AML ki personality hai. Personas ek tap mein ise badal dete hain.")

    SectionTitle("Personas")
    settings.personas.forEach { persona ->
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(persona.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    persona.prompt,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            TextButton(onClick = { viewModel.applyPersona(persona) }) { Text("Use") }
            IconButton(onClick = { onEditPersona(persona) }) { Icon(Icons.Filled.Check, contentDescription = "Edit") }
            IconButton(onClick = { viewModel.deletePersona(persona.name) }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
        }
    }
    OutlinedButton(onClick = { onEditPersona(Persona("", "")) }) {
        Icon(Icons.Filled.Add, contentDescription = null)
        Spacer(Modifier.width(6.dp))
        Text("Naya persona")
    }

    SectionTitle("Memory")
    OutlinedTextField(
        value = settings.memory,
        onValueChange = { onApply(settings.copy(memory = it)) },
        modifier = Modifier.fillMaxWidth(),
        label = { Text("Yaad rakhne wali baatein") },
        minLines = 3,
        shape = RoundedCornerShape(14.dp),
    )
    Hint("Yahan likhi baatein har chat ke system prompt mein shamil hoti hain (naam, language, preferences).")
}

// =============================================================================================
// Agent
// =============================================================================================

@Composable
private fun AgentSection(settings: AppSettings, onApply: (AppSettings) -> Unit) {
    SectionTitle("Agent")
    SwitchRow("Agent tools on", settings.agentEnabled) { onApply(settings.copy(agentEnabled = it)) }
    Hint(
        "22 built-in tools: web search, page fetch, HTTP request, open URL/app, file write/read/list/delete, zip, " +
            "share, storage + device info, clipboard read/write, notification, alarm, vibrate, torch, image, video.",
    )
    SwitchRow("Auto-speak replies", settings.autoSpeak) { onApply(settings.copy(autoSpeak = it)) }

    SectionTitle("Safety")
    Hint(
        "Tools sirf tab chalte hain jab model unhe call karta hai; callback chat mein dikhte hain. " +
            "Delete/write app workspace + Downloads/AML tak mehdood hai (Android 11+ ke scoped storage ke sath).",
    )
}

// =============================================================================================
// MCP
// =============================================================================================

@Composable
private fun McpSection(
    settings: AppSettings,
    onApply: (AppSettings) -> Unit,
    status: Map<String, String>,
    viewModel: ChatViewModel,
) {
    var name by rememberSaveable { mutableStateOf("") }
    var url by rememberSaveable { mutableStateOf("") }
    var token by rememberSaveable { mutableStateOf("") }

    SectionTitle("MCP servers (streamable HTTP)")
    Hint("Model Context Protocol server ka URL daalein; uske tools Agent mein automatically shamil ho jate hain.")
    TextField("Naam", name, "My MCP") { name = it }
    TextField("URL", url, "https://mcp.example.com/mcp") { url = it }
    SecretField("Bearer token (optional)", token) { token = it }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(
            onClick = {
                if (url.isNotBlank()) {
                    viewModel.addMcpServer(McpServer(name.ifBlank { "MCP" }, url.trim(), token.trim(), true))
                    name = ""; url = ""; token = ""
                }
            },
            enabled = url.isNotBlank(),
        ) { Text("Add server") }
        OutlinedButton(onClick = { viewModel.refreshMcp() }) { Text("Connect / refresh") }
    }

    Spacer(Modifier.height(10.dp))
    settings.mcpServers.forEach { server ->
        Card(
            Modifier.fillMaxWidth().padding(vertical = 4.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(14.dp),
        ) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(server.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        Text(server.url, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            status[server.url] ?: "status: —",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    Switch(checked = server.enabled, onCheckedChange = { enabled ->
                        onApply(settings.copy(mcpServers = settings.mcpServers.map { if (it.url == server.url) it.copy(enabled = enabled) else it }))
                    })
                    IconButton(onClick = { viewModel.removeMcpServer(server.url) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Remove")
                    }
                }
                if (server.token.isNotBlank()) {
                    Text("token: ✓ set", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

// =============================================================================================
// Voice
// =============================================================================================

@Composable
private fun VoiceSection(settings: AppSettings, onApply: (AppSettings) -> Unit) {
    SectionTitle("Speech to text")
    TextField("Recognition language (BCP-47)", settings.speechLanguage, "en-US / ur-PK / hi-IN") {
        onApply(settings.copy(speechLanguage = it.trim()))
    }
    Hint("Mic button isi language mein sunta hai; Roman Urdu ke liye en-IN ya en-US theek rehta hai.")

    SectionTitle("Text to speech")
    SwitchRow("Replies khud parh kar sunein (auto-speak)", settings.autoSpeak) { onApply(settings.copy(autoSpeak = it)) }
    FloatSlider("Speech rate", settings.speechRate, 0.5f..2f, 0.1f) { onApply(settings.copy(speechRate = it)) }
}

// =============================================================================================
// Appearance
// =============================================================================================

@Composable
private fun AppearanceSection(settings: AppSettings, onApply: (AppSettings) -> Unit) {
    SectionTitle("Theme")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ThemeMode.entries.forEach { mode ->
            ChoiceChip(mode.name.lowercase().replaceFirstChar { it.uppercase() }, settings.themeMode == mode) {
                onApply(settings.copy(themeMode = mode))
            }
        }
    }
    SectionTitle("Accent")
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        AccentColor.entries.forEach { accent ->
            Box(
                Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(accent.argb))
                    .clickable { onApply(settings.copy(accent = accent)) },
                contentAlignment = Alignment.Center,
            ) {
                if (settings.accent == accent) Icon(Icons.Filled.Check, contentDescription = accent.label, tint = Color.White)
            }
        }
    }
    SectionTitle("Text size")
    FloatSlider("Font scale", settings.fontScale, 0.85f..1.4f, 0.05f) { onApply(settings.copy(fontScale = it)) }
}

// =============================================================================================
// About
// =============================================================================================

@Composable
private fun AboutSection() {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                Text("AML", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("AML — Advance Model Loader", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Author: macotina", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Version ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(
            "All-in-one AI app: apne phone par GGUF model (llama.cpp, arm64-v8a) offline chalayein, ya OpenAI / " +
                "Anthropic / Gemini / OpenRouter / Groq / DeepSeek / xAI / Mistral / Together / Ollama / LM Studio / " +
                "vLLM jaise kisi bhi OpenAI-compatible endpoint se baat karein. Agent 22 tools ke sath files, web, " +
                "device, clipboard, alarm, torch, image aur video tak pahunchta hai; MCP servers se apne tools jorte hain.",
            style = MaterialTheme.typography.bodySmall,
        )
        Spacer(Modifier.height(14.dp))
        HorizontalDivider()
        Spacer(Modifier.height(14.dp))
        Text("Credits", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        Text(
            "llama.cpp (ggml-org) · Jetpack Compose + Material 3 · Room · Kotlin coroutines · AndroidX Media.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// =============================================================================================
// Small building blocks
// =============================================================================================

@Composable
private fun SectionTitle(text: String) {
    Spacer(Modifier.height(14.dp))
    Text(text, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun Hint(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 4.dp, bottom = 4.dp),
    )
}

@Composable
private fun ChoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, style = MaterialTheme.typography.labelMedium) },
        colors = FilterChipDefaults.filterChipColors(),
    )
}

@Composable
private fun TextField(label: String, value: String, placeholder: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        placeholder = { Text(placeholder) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
    )
}

@Composable
private fun SecretField(label: String, value: String, onChange: (String) -> Unit) {
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        trailingIcon = {
            IconButton(onClick = { visible = !visible }) {
                Icon(if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = "Show/hide")
            }
        },
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun FloatSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    step: Float,
    onChange: (Float) -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        Row {
            Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            Text("%.2f".format(value), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = { raw -> onChange((Math.round(raw / step) * step).coerceIn(range.start, range.endInclusive)) },
            valueRange = range,
        )
    }
}

@Composable
private fun IntSlider(
    label: String,
    value: Int,
    range: IntRange,
    step: Int,
    defaultValue: Int,
    onChange: (Int) -> Unit,
) {
    val values = remember(range, step) { range.step(step).toList().ifEmpty { listOf(range.first) } }
    val index = values.indexOfFirst { it >= value }.takeIf { it >= 0 } ?: (values.size - 1)
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            Text(value.toString(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            TextButton(onClick = { onChange(defaultValue) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("reset") }
        }
        Slider(
            value = index.toFloat(),
            onValueChange = { raw -> values.getOrNull(raw.toInt().coerceIn(0, values.size - 1))?.let(onChange) },
            valueRange = 0f..(values.size - 1).toFloat().coerceAtLeast(1f),
            steps = (values.size - 2).coerceAtLeast(0),
        )
    }
}

@Composable
private fun PersonaDialog(persona: Persona, onDismiss: () -> Unit, onSave: (Persona) -> Unit) {
    var name by rememberSaveable { mutableStateOf(persona.name) }
    var prompt by rememberSaveable { mutableStateOf(persona.prompt) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (persona.name.isBlank()) "Naya persona" else "Persona edit") },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Naam") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = prompt, onValueChange = { prompt = it }, label = { Text("System prompt") }, minLines = 4, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(onClick = { if (name.isNotBlank() && prompt.isNotBlank()) onSave(Persona(name.trim(), prompt.trim())) }, enabled = name.isNotBlank() && prompt.isNotBlank()) {
                Text("Save")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ModelListDialog(models: List<String>, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Server ke models") },
        text = {
            Column {
                OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Filter") }, singleLine = true)
                Spacer(Modifier.height(6.dp))
                Column(Modifier.height(260.dp).verticalScroll(rememberScrollState())) {
                    models.filter { query.isBlank() || it.contains(query, true) }.forEach { id ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onPick(id) }.padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(id, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Band karein") } },
    )
}
