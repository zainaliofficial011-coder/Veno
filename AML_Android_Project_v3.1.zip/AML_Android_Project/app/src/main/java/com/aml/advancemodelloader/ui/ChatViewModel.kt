package com.aml.advancemodelloader.ui

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Debug
import android.os.SystemClock
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.aml.advancemodelloader.agent.ParsedToolCall
import com.aml.advancemodelloader.agent.ToolCallParser
import com.aml.advancemodelloader.agent.ToolRunner
import com.aml.advancemodelloader.data.AppDatabase
import com.aml.advancemodelloader.data.AppSettings
import com.aml.advancemodelloader.data.BackendKind
import com.aml.advancemodelloader.data.ChatDao
import com.aml.advancemodelloader.data.ChatSessionEntity
import com.aml.advancemodelloader.data.MessageEntity
import com.aml.advancemodelloader.data.MessageKind
import com.aml.advancemodelloader.data.MessageRole
import com.aml.advancemodelloader.data.mediaPaths
import com.aml.advancemodelloader.data.Persona
import com.aml.advancemodelloader.data.SettingsStore
import com.aml.advancemodelloader.engine.ApiException
import com.aml.advancemodelloader.engine.Backends
import com.aml.advancemodelloader.engine.ChatBackend
import com.aml.advancemodelloader.engine.ChatEvent
import com.aml.advancemodelloader.engine.GenParams
import com.aml.advancemodelloader.engine.LocalBackend
import com.aml.advancemodelloader.engine.LlmEngine
import com.aml.advancemodelloader.engine.McpClient
import com.aml.advancemodelloader.engine.McpServer
import com.aml.advancemodelloader.engine.ModelConfig
import com.aml.advancemodelloader.engine.ModelOutOfMemoryException
import com.aml.advancemodelloader.engine.NativeLlmEngine
import com.aml.advancemodelloader.engine.PromptTemplate
import com.aml.advancemodelloader.engine.ProviderKind
import com.aml.advancemodelloader.engine.ReasoningLevel
import com.aml.advancemodelloader.engine.ToolCallRequest
import com.aml.advancemodelloader.engine.ToolSpec
import com.aml.advancemodelloader.engine.Turn
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.DataInputStream
import java.io.File
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.roundToInt

// =============================================================================================
// UI state
// =============================================================================================

sealed interface EngineState {
    data object ModelNotLoaded : EngineState
    data class LoadingModel(val modelName: String, val progress: Float? = null) : EngineState
    data object Ready : EngineState
    data object GeneratingText : EngineState
    data class Error(val type: ErrorType, val message: String) : EngineState
}

enum class ErrorType { OOM, LOAD_FAILED, API }

val EngineState.isChatActive: Boolean
    get() = this is EngineState.Ready || this is EngineState.GeneratingText

data class ModelFile(val name: String, val path: String, val sizeBytes: Long)

data class ModelPickerState(
    val models: List<ModelFile> = emptyList(),
    val isScanning: Boolean = false,
    val importProgress: Float? = null,
)

data class Attachment(val path: String, val name: String)

enum class ToolStatus { RUNNING, OK, FAILED }

data class ToolActivity(
    val name: String,
    val arguments: String,
    val status: ToolStatus,
    val result: String = "",
    val media: List<String> = emptyList(),
)

data class StreamingMessage(
    val text: String = "",
    val thinking: String = "",
    val tools: List<ToolActivity> = emptyList(),
    val media: List<String> = emptyList(),
    val persistedId: Long? = null,
)

data class PerfStats(
    val processRamBytes: Long = 0L,
    val systemAvailBytes: Long = 0L,
    val systemTotalBytes: Long = 0L,
    val tokensPerSecond: Float = 0f,
    val lastTokenCount: Int = 0,
)

data class MediaItem(
    val path: String,
    val name: String,
    val kind: String,
    val sizeBytes: Long,
    val modified: Long,
)

sealed interface UiEvent {
    data class Message(val text: String) : UiEvent
    data class OpenUrl(val url: String) : UiEvent
    data class OpenMedia(val path: String) : UiEvent
    data class Speak(val text: String) : UiEvent
    data class Share(val text: String) : UiEvent
}

private data class MemorySnapshot(val processBytes: Long, val availBytes: Long, val totalBytes: Long)

// =============================================================================================
// ViewModel
// =============================================================================================

class ChatViewModel(
    private val app: Application,
    private val dao: ChatDao,
    private val engine: LlmEngine,
    private val store: SettingsStore,
) : ViewModel() {

    // ---- Settings ---------------------------------------------------------------------------

    private val _settings = MutableStateFlow(store.load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    /** Kept outside the settings object so keys never leak into an exported file. */
    @Volatile
    private var apiKeyCache: String = _settings.value.apiKey

    private val toolRunner = ToolRunner(
        context = app,
        api = { backend() },
        resultLimit = { _settings.value.toolResultLimit },
        imageModel = { _settings.value.imageModelId },
        videoModel = { _settings.value.videoModelId },
        mcpServers = { _settings.value.mcpServers },
        onOpenUrl = { emit(UiEvent.OpenUrl(it)) },
        onMedia = { emit(UiEvent.OpenMedia(it)) },
    )

    fun updateSettings(new: AppSettings) {
        apiKeyCache = new.apiKey
        _settings.value = new
        store.save(new)
        refreshTools()
        if (new.backend == BackendKind.API && _loadedModel.value != null) {
            viewModelScope.launch(Dispatchers.IO) {
                generationJob?.let { engine.requestStop(); it.join() }
                runCatching { engine.unload() }
                _loadedModel.value = null
                _engineState.value = EngineState.Ready
            }
        }
    }

    fun applyProvider(name: String, baseUrl: String, model: String, kind: ProviderKind) {
        updateSettings(
            _settings.value.copy(
                provider = name,
                apiBaseUrl = baseUrl,
                apiModelId = model,
                providerKind = kind,
                backend = BackendKind.API,
            ),
        )
    }

    fun applyPersona(persona: Persona) = updateSettings(_settings.value.copy(systemPrompt = persona.prompt))

    fun savePersona(persona: Persona) {
        val list = _settings.value.personas.toMutableList()
        val index = list.indexOfFirst { it.name.equals(persona.name, true) }
        if (index >= 0) list[index] = persona else list.add(persona)
        updateSettings(_settings.value.copy(personas = list))
    }

    fun deletePersona(name: String) =
        updateSettings(_settings.value.copy(personas = _settings.value.personas.filterNot { it.name.equals(name, true) }))

    // ---- Backends ---------------------------------------------------------------------------

    private fun backend(): ChatBackend {
        val s = _settings.value
        return if (s.backend == BackendKind.LOCAL_GGUF) {
            localBackend ?: LocalBackend(engine, { _activeTemplate.value }, { s.contextSize }).also { localBackend = it }
        } else {
            Backends.create(
                kind = s.providerKind,
                baseUrl = { _settings.value.apiBaseUrl },
                apiKey = { apiKeyCache },
                mediaDir = { mediaDir() },
                imageModel = { _settings.value.imageModelId },
                videoModel = { _settings.value.videoModelId },
            )
        }
    }

    private var localBackend: LocalBackend? = null

    // ---- Engine / models --------------------------------------------------------------------

    private val _engineState = MutableStateFlow<EngineState>(EngineState.ModelNotLoaded)
    val engineState: StateFlow<EngineState> = _engineState.asStateFlow()

    private val _loadedModel = MutableStateFlow<ModelFile?>(null)
    val loadedModel: StateFlow<ModelFile?> = _loadedModel.asStateFlow()

    private val _picker = MutableStateFlow(ModelPickerState())
    val picker: StateFlow<ModelPickerState> = _picker.asStateFlow()

    private val _apiModels = MutableStateFlow<List<String>>(emptyList())
    val apiModels: StateFlow<List<String>> = _apiModels.asStateFlow()

    private val _busy = MutableStateFlow<String?>(null)
    val busy: StateFlow<String?> = _busy.asStateFlow()

    private val _mcpStatus = MutableStateFlow<Map<String, String>>(emptyMap())
    val mcpStatus: StateFlow<Map<String, String>> = _mcpStatus.asStateFlow()

    private val _tools = MutableStateFlow<List<ToolSpec>>(emptyList())
    val tools: StateFlow<List<ToolSpec>> = _tools.asStateFlow()

    private val _activeTemplate = MutableStateFlow(PromptTemplate.CHATML)

    val chatTitle: StateFlow<String> = combine(_settings, _loadedModel) { s, model ->
        if (s.backend == BackendKind.API) s.apiModelId.ifBlank { "API" }
        else model?.name ?: "Koi model nahi"
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "AML")

    val chatSubtitle: StateFlow<String> = combine(_settings, _activeTemplate) { s, template ->
        if (s.backend == BackendKind.API) "${s.provider} · ${s.apiBaseUrl}"
        else "Local GGUF · ${template.label}"
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "")

    /** True when the current backend can actually answer. */
    val chatReady: StateFlow<Boolean> = combine(_settings, _engineState) { s, state ->
        if (s.backend == BackendKind.API) s.apiBaseUrl.isNotBlank() && s.apiModelId.isNotBlank()
        else state is EngineState.Ready || state is EngineState.GeneratingText
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    private var generationJob: Job? = null
    private var mediaJob: Job? = null

    fun selectLocalTemplate(template: PromptTemplate) {
        _activeTemplate.value = template
    }

    // ---- Streaming + performance -------------------------------------------------------------

    private val _streaming = MutableStateFlow<StreamingMessage?>(null)
    val streaming: StateFlow<StreamingMessage?> = _streaming.asStateFlow()

    private val _tps = MutableStateFlow(0f)
    private val _lastTokenCount = MutableStateFlow(0)

    val perf: StateFlow<PerfStats> = combine(memoryTicker(), _tps, _lastTokenCount) { mem, tps, count ->
        PerfStats(mem.processBytes, mem.availBytes, mem.totalBytes, tps, count)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PerfStats())

    // ---- Persistence ------------------------------------------------------------------------

    private val _currentSessionId = MutableStateFlow<Long?>(null)
    val currentSessionId: StateFlow<Long?> = _currentSessionId.asStateFlow()

    private val _sessionQuery = MutableStateFlow("")
    val sessionQuery: StateFlow<String> = _sessionQuery.asStateFlow()

    val sessions: StateFlow<List<ChatSessionEntity>> = dao.observeSessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val filteredSessions: StateFlow<List<ChatSessionEntity>> = combine(sessions, _sessionQuery) { list, query ->
        if (query.isBlank()) list else list.filter { it.title.contains(query, true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<MessageEntity>> = _currentSessionId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList<MessageEntity>()) else dao.observeMessages(id) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---- Attachments + media -----------------------------------------------------------------

    private val _attachments = MutableStateFlow<List<Attachment>>(emptyList())
    val attachments: StateFlow<List<Attachment>> = _attachments.asStateFlow()

    private val _media = MutableStateFlow<List<MediaItem>>(emptyList())
    val media: StateFlow<List<MediaItem>> = _media.asStateFlow()

    private val _events = MutableSharedFlow<UiEvent>(extraBufferCapacity = 64, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val events: Flow<UiEvent> = _events.asSharedFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) { _currentSessionId.value = dao.latestSessionId() }
        refreshModels()
        refreshMedia()
        refreshTools()
    }

    /** Built-in + MCP tool catalogue, shown by the "Tools" chip in the input bar. */
    fun refreshTools() {
        viewModelScope.launch(Dispatchers.IO) {
            _tools.value = runCatching { toolRunner.tools() }.getOrDefault(emptyList())
        }
    }

    /** One-off user-facing message (snackbar). */
    fun notify(text: String) = emit(UiEvent.Message(text))

    fun setSessionQuery(query: String) {
        _sessionQuery.value = query
    }

    // =========================================================================================
    // Local models
    // =========================================================================================

    private fun modelDirs(): List<File> = listOfNotNull(
        File(app.filesDir, "models"),
        app.getExternalFilesDir("models"),
    ).onEach { it.mkdirs() }

    private fun mediaDir(): File = File(app.filesDir, "media").apply { mkdirs() }
    private fun attachmentsDir(): File = File(app.filesDir, "attachments").apply { mkdirs() }

    fun refreshModels() {
        viewModelScope.launch(Dispatchers.IO) {
            _picker.update { it.copy(isScanning = true) }
            val found = modelDirs()
                .flatMap { dir -> dir.listFiles { f -> f.isFile && f.extension.equals("gguf", true) }?.toList().orEmpty() }
                .map { ModelFile(it.name, it.absolutePath, it.length()) }
                .sortedBy { it.name.lowercase() }
            _picker.update { it.copy(models = found, isScanning = false) }
        }
    }

    /** Copies a picked .gguf into app storage and loads it right away (the "select model" button). */
    fun importAndLoad(uri: Uri) {
        if (_picker.value.importProgress != null) {
            emit(UiEvent.Message("Pehla model abhi copy ho raha hai…"))
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val copied = importModelFile(uri) ?: return@launch
            loadModel(copied)
        }
    }

    fun importModel(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) { importModelFile(uri) }
    }

    private suspend fun importModelFile(uri: Uri): ModelFile? {
        val (displayName, declaredSize) = queryNameAndSize(uri)
        val name = displayName?.substringAfterLast('/')?.replace(Regex("[^A-Za-z0-9._()\\- ]"), "_")
        if (name == null || !name.endsWith(".gguf", ignoreCase = true)) {
            emit(UiEvent.Message("Ye .gguf file nahi hai. GGUF model file chunein."))
            return null
        }
        val dir = modelDirs().first()
        val target = File(dir, name)
        val partial = File(dir, "$name.part")
        if (declaredSize > 0 && dir.usableSpace < declaredSize + 64L * 1024 * 1024) {
            emit(UiEvent.Message("Storage kam hai — ${formatBytes(declaredSize)} free karein."))
            return null
        }
        _picker.update { it.copy(importProgress = 0f) }
        return try {
            val input = app.contentResolver.openInputStream(uri) ?: error("Selected file khul nahi saki.")
            input.buffered(1 shl 20).use { stream ->
                val magic = ByteArray(4)
                DataInputStream(stream).readFully(magic)
                require(String(magic, Charsets.US_ASCII) == "GGUF") { "File ka header GGUF nahi hai." }
                partial.outputStream().buffered(1 shl 20).use { out ->
                    out.write(magic)
                    val buffer = ByteArray(1 shl 20)
                    var copied = 4L
                    var lastReported = 0f
                    while (true) {
                        val n = stream.read(buffer)
                        if (n < 0) break
                        out.write(buffer, 0, n)
                        copied += n
                        currentCoroutineContext().ensureActive()
                        if (declaredSize > 0) {
                            val p = (copied.toFloat() / declaredSize).coerceIn(0f, 1f)
                            if (p - lastReported >= 0.005f) {
                                lastReported = p
                                _picker.update { it.copy(importProgress = p) }
                            }
                        }
                    }
                }
            }
            check(partial.renameTo(target)) { "File save nahi ho saki." }
            refreshModels()
            ModelFile(target.name, target.absolutePath, target.length())
        } catch (t: Throwable) {
            partial.delete()
            if (t is CancellationException) throw t
            emit(UiEvent.Message("Import failed: ${t.message}"))
            null
        } finally {
            _picker.update { it.copy(importProgress = null) }
        }
    }

    fun deleteModel(model: ModelFile) {
        viewModelScope.launch(Dispatchers.IO) {
            File(model.path).delete()
            refreshModels()
        }
    }

    private fun queryNameAndSize(uri: Uri): Pair<String?, Long> {
        var name: String? = null
        var size = -1L
        app.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIdx >= 0) name = cursor.getString(nameIdx)
                if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) size = cursor.getLong(sizeIdx)
            }
        }
        return name to size
    }

    fun loadModel(model: ModelFile, template: PromptTemplate? = null) {
        val current = _engineState.value
        if (current is EngineState.LoadingModel || current is EngineState.GeneratingText) return
        _engineState.value = EngineState.LoadingModel(model.name)
        _loadedModel.value = null

        viewModelScope.launch(Dispatchers.IO) {
            val s = _settings.value
            val mem = readMemory()
            val reserve = max(MIN_KV_RESERVE_BYTES, (model.sizeBytes * KV_RESERVE_FRACTION).toLong())
            val required = model.sizeBytes + reserve
            if (mem.availBytes in 1 until required) {
                _engineState.value = EngineState.Error(
                    ErrorType.OOM,
                    "${model.name} ko ~${formatBytes(required)} chahiye magar ${formatBytes(mem.availBytes)} free hai. " +
                        "Chhoti ya zyada quantised model (Q4_K_M) try karein.",
                )
                return@launch
            }
            try {
                engine.loadModel(model.path, ModelConfig(s.contextSize, s.threads, s.useMmap))
                _activeTemplate.value = template ?: templateFromSettings(model.name, s)
                _loadedModel.value = model
                _engineState.value = EngineState.Ready
                emit(UiEvent.Message("Model ready: ${model.name}"))
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                val oom = t is ModelOutOfMemoryException || t is OutOfMemoryError
                _engineState.value = EngineState.Error(
                    if (oom) ErrorType.OOM else ErrorType.LOAD_FAILED,
                    if (oom) "Memory khatam ho gayi ${model.name} load karte waqt. Chhota model try karein."
                    else t.message ?: "Model load nahi ho saka.",
                )
            }
        }
    }

    fun unloadModel() {
        if (_engineState.value is EngineState.LoadingModel) return
        viewModelScope.launch(Dispatchers.IO) {
            generationJob?.let { engine.requestStop(); it.join() }
            runCatching { engine.unload() }
            _loadedModel.value = null
            _streaming.value = null
            _engineState.value = EngineState.ModelNotLoaded
        }
    }

    fun dismissError() {
        if (_engineState.value is EngineState.Error) {
            _engineState.value = if (_loadedModel.value != null) EngineState.Ready else EngineState.ModelNotLoaded
        }
    }

    /** Used by the "Use API" button on the empty chat screen. */
    fun useApiBackend() {
        updateSettings(_settings.value.copy(backend = BackendKind.API))
        testConnection()
    }

    fun useLocalBackend() {
        updateSettings(_settings.value.copy(backend = BackendKind.LOCAL_GGUF))
    }

    // =========================================================================================
    // API helpers
    // =========================================================================================

    fun setApiModelId(id: String) = updateSettings(_settings.value.copy(apiModelId = id))

    fun testConnection() {
        viewModelScope.launch(Dispatchers.IO) {
            _busy.value = "Connect ho raha hai…"
            try {
                val models = backend().listModels()
                _apiModels.value = models
                emit(
                    UiEvent.Message(
                        if (models.isEmpty()) "✓ Connected (server ne koi model list nahi kiya)"
                        else "✓ Connected — ${models.size} models",
                    ),
                )
            } catch (t: Throwable) {
                emit(UiEvent.Message("✗ ${t.message ?: "Connection failed"}"))
            } finally {
                _busy.value = null
            }
        }
    }

    // =========================================================================================
    // MCP
    // =========================================================================================

    fun addMcpServer(server: McpServer) {
        val list = _settings.value.mcpServers.filterNot { it.url == server.url } + server
        updateSettings(_settings.value.copy(mcpServers = list))
        refreshMcp()
    }

    fun removeMcpServer(url: String) {
        updateSettings(_settings.value.copy(mcpServers = _settings.value.mcpServers.filterNot { it.url == url }))
        refreshMcp()
    }

    fun refreshMcp() {
        viewModelScope.launch(Dispatchers.IO) {
            val status = mutableMapOf<String, String>()
            _settings.value.mcpServers.forEach { server ->
                status[server.url] = "checking…"
                _mcpStatus.value = status.toMap()
                status[server.url] = try {
                    val tools = McpClient(server).listTools()
                    "✓ ${tools.size} tools"
                } catch (t: Throwable) {
                    "✗ ${t.message?.take(80) ?: "failed"}"
                }
                _mcpStatus.value = status.toMap()
            }
            _mcpStatus.value = status.toMap()
        }
    }

    // =========================================================================================
    // Chat sessions
    // =========================================================================================

    private val isGenerating get() = _engineState.value is EngineState.GeneratingText

    fun newChat() {
        if (!isGenerating) _currentSessionId.value = null
    }

    fun openSession(id: Long) {
        if (!isGenerating) _currentSessionId.value = id
    }

    fun renameSession(id: Long, title: String) {
        viewModelScope.launch(Dispatchers.IO) { dao.renameSession(id, title.take(60)) }
    }

    fun deleteSession(id: Long) {
        if (isGenerating) return
        viewModelScope.launch(Dispatchers.IO) {
            dao.deleteSession(id)
            if (_currentSessionId.value == id) _currentSessionId.value = null
        }
    }

    fun deleteAllSessions() {
        if (isGenerating) return
        viewModelScope.launch(Dispatchers.IO) {
            dao.deleteAllSessions()
            _currentSessionId.value = null
        }
    }

    fun exportChat(share: Boolean = true) {
        viewModelScope.launch(Dispatchers.IO) {
            val list = messages.value
            if (list.isEmpty()) {
                emit(UiEvent.Message("Chat khali hai."))
                return@launch
            }
            val title = sessions.value.firstOrNull { it.id == _currentSessionId.value }?.title ?: "AML chat"
            val markdown = buildString {
                appendLine("# $title")
                appendLine()
                appendLine("_AML · Advance Model Loader · ${chatTitle.value}_")
                appendLine()
                list.forEach { message ->
                    appendLine("## ${message.role.name.lowercase().replaceFirstChar { it.uppercase() }}")
                    appendLine()
                    appendLine(message.content)
                    message.thinking?.let { appendLine("\n> thinking: ${it.take(500)}") }
                    appendLine()
                }
            }
            val name = "aml_chat_${System.currentTimeMillis()}.md"
            val saved = saveToDownloads(app, name, "text/markdown", markdown)
            emit(UiEvent.Message(if (saved != null) "Saved: $saved" else "Export fail hua."))
            if (share) emit(UiEvent.Share(markdown))
        }
    }

    fun shareMessage(text: String) = emit(UiEvent.Share(text))

    // =========================================================================================
    // Attachments / media gallery
    // =========================================================================================

    fun attachImage(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val name = queryNameAndSize(uri).first ?: "image_${System.currentTimeMillis()}.jpg"
                val ext = name.substringAfterLast('.', "jpg").lowercase().take(4)
                val target = File(attachmentsDir(), "img_${System.currentTimeMillis()}.$ext")
                app.contentResolver.openInputStream(uri)?.use { input ->
                    target.outputStream().use { input.copyTo(it) }
                } ?: error("Image khul nahi saki.")
                if (target.length() == 0L) {
                    target.delete()
                    emit(UiEvent.Message("Image read nahi hui."))
                    return@launch
                }
                _attachments.update { it + Attachment(target.absolutePath, name) }
                if (_settings.value.backend == BackendKind.LOCAL_GGUF) {
                    emit(UiEvent.Message("Vision ke liye API backend chahiye — local GGUF text-only hai."))
                }
            } catch (t: Throwable) {
                emit(UiEvent.Message("Attach failed: ${t.message}"))
            }
        }
    }

    fun removeAttachment(path: String) = _attachments.update { list -> list.filterNot { it.path == path } }

    fun clearAttachments() {
        _attachments.value = emptyList()
    }

    fun refreshMedia() {
        viewModelScope.launch(Dispatchers.IO) {
            val dir = mediaDir().apply { mkdirs() }
            _media.value = dir.listFiles { file -> file.isFile }
                ?.sortedByDescending { it.lastModified() }
                ?.map { file ->
                    MediaItem(
                        path = file.absolutePath,
                        name = file.name,
                        kind = if (file.extension.equals("mp4", true) || file.extension.equals("webm", true)) "video" else "image",
                        sizeBytes = file.length(),
                        modified = file.lastModified(),
                    )
                }.orEmpty()
        }
    }

    fun deleteMedia(item: MediaItem) {
        viewModelScope.launch(Dispatchers.IO) {
            File(item.path).delete()
            refreshMedia()
        }
    }

    // =========================================================================================
    // Generation
    // =========================================================================================

    fun sendMessage(text: String) {
        val prompt = text.trim()
        val attachmentsNow = _attachments.value
        if (prompt.isEmpty() && attachmentsNow.isEmpty()) return
        if (!chatReady.value) {
            emit(UiEvent.Message("Pehle model load karein ya API set karein."))
            return
        }
        _engineState.value = EngineState.GeneratingText
        _attachments.value = emptyList()
        generationJob = viewModelScope.launch(Dispatchers.IO) { runTurn(prompt, attachmentsNow, insertUser = true) }
        generationJob?.invokeOnCompletion { runCatching { refreshMedia() } }
    }

    fun regenerate() {
        if (isGenerating) return
        val list = messages.value
        val lastAssistant = list.lastOrNull { it.role == MessageRole.ASSISTANT } ?: run {
            emit(UiEvent.Message("Regenerate ke liye koi reply nahi hai."))
            return
        }
        _engineState.value = EngineState.GeneratingText
        generationJob = viewModelScope.launch(Dispatchers.IO) {
            dao.deleteMessage(lastAssistant.id)
            runTurn("", emptyList(), insertUser = false)
        }
    }

    fun editAndResend(messageId: Long, newText: String) {
        if (isGenerating) return
        val list = messages.value
        val index = list.indexOfFirst { it.id == messageId }
        if (index < 0) return
        _engineState.value = EngineState.GeneratingText
        generationJob = viewModelScope.launch(Dispatchers.IO) {
            list.drop(index).forEach { dao.deleteMessage(it.id) }
            runTurn(newText.trim(), emptyList(), insertUser = true)
        }
    }

    fun stopGeneration() {
        if (!isGenerating) return
        // Local: the native loop stops after the current token. API: the SSE job is cancelled.
        engine.requestStop()
        generationJob?.cancel(CancellationException("user-stop"))
        val partial = _streaming.value
        _streaming.value = null
        _engineState.value = EngineState.Ready
        if (partial == null || (partial.text.isBlank() && partial.media.isEmpty())) {
            emit(UiEvent.Message("Generation rok di."))
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val sessionId = _currentSessionId.value ?: return@launch
            runCatching {
                dao.insertMessageAndTouch(
                    MessageEntity(
                        sessionId = sessionId,
                        role = MessageRole.ASSISTANT,
                        content = partial.text.trim().ifBlank { "_(stopped)_" } + "\n\n_(stopped)_",
                        kind = if (partial.media.isEmpty()) MessageKind.TEXT else MessageKind.IMAGE,
                        mediaPath = partial.media.joinToString(";").ifBlank { null },
                        thinking = partial.thinking.ifBlank { null },
                    ),
                )
            }
            emit(UiEvent.Message("Generation rok di — jo ban chuka tha woh save kar diya."))
        }
    }

    private suspend fun runTurn(prompt: String, attachments: List<Attachment>, insertUser: Boolean) {
        val sessionId = try {
            val id = _currentSessionId.value ?: createSession(prompt.ifBlank { "New chat" })
            if (insertUser) {
                dao.insertMessageAndTouch(
                    MessageEntity(
                        sessionId = id,
                        role = MessageRole.USER,
                        content = prompt.ifBlank { "[image]" },
                        tokenCount = estimateTokens(prompt),
                        kind = if (attachments.isEmpty()) MessageKind.TEXT else MessageKind.IMAGE,
                        mediaPath = attachments.joinToString(";") { it.path }.ifBlank { null },
                    ),
                )
            }
            id
        } catch (t: Throwable) {
            if (t is CancellationException) throw t
            emit(UiEvent.Message("Message save nahi hua: ${t.message}"))
            _engineState.value = EngineState.Ready
            return
        }

        _tps.value = 0f
        _streaming.value = StreamingMessage()
        val history = dao.getMessages(sessionId)
        try {
            agentLoop(sessionId, history)
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            withContext(NonCancellable) { finishTurn(sessionId, "", "", 0, 0L, 0L, emptyList(), t) }
        }
    }

    /** One provider-independent loop: stream → maybe run tools → stream again → save. */
    private suspend fun agentLoop(sessionId: Long, history: List<MessageEntity>) {
        val s = _settings.value
        val api = backend()
        val nativeTools = s.useNativeTools && s.backend == BackendKind.API
        val allTools: List<ToolSpec> = if (s.agentEnabled) apiOrEmptyTools(api) else emptyList()
        val sendTools: List<ToolSpec> = if (nativeTools) allTools else emptyList()

        var turns: List<Turn> = history.map { it.toTurn() }
        var rounds = 0
        val thinkingAll = StringBuilder()
        val mediaAll = mutableListOf<String>()
        val activity = mutableListOf<ToolActivity>()

        while (true) {
            val answer = StringBuilder()
            var calls: List<ToolCallRequest> = emptyList()
            var tokens = 0
            var firstAt = 0L
            var lastAt = 0L
            var lastPublish = 0L

            api.chat(
                model = if (s.backend == BackendKind.API) s.apiModelId else (_loadedModel.value?.name ?: "local"),
                system = systemPrompt(s, allTools, nativeTools),
                turns = turns,
                tools = sendTools,
                params = genParams(s),
                stream = s.streamApi || s.backend == BackendKind.LOCAL_GGUF,
            ).collect { event ->
                when (event) {
                    is ChatEvent.Text -> {
                        val now = SystemClock.elapsedRealtime()
                        if (tokens == 0) firstAt = now
                        lastAt = now
                        tokens++
                        answer.append(event.chunk)
                        if (now - lastPublish >= PUBLISH_INTERVAL_MS) {
                            lastPublish = now
                            publish(activity, mediaAll, thinkingAll, answer.toString(), nativeTools)
                            _tps.value = tokensPerSecond(tokens, firstAt, now)
                        }
                    }
                    is ChatEvent.Reasoning -> {
                        thinkingAll.append(event.chunk)
                        publish(activity, mediaAll, thinkingAll, answer.toString(), nativeTools)
                    }
                    is ChatEvent.Calls -> calls = event.calls
                    is ChatEvent.Failure -> throw ApiException(event.message)
                    ChatEvent.Done -> Unit
                }
            }

            val raw = answer.toString()
            val splitLive = splitThinking(raw)
            if (splitLive.first.length > thinkingAll.length) thinkingAll.replace(0, thinkingAll.length, splitLive.first)

            val textCalls = if (s.agentEnabled && !nativeTools && calls.isEmpty()) ToolCallParser.parse(raw) else emptyList()
            val effective = calls.ifEmpty { textCalls }
            val unfinished = s.agentEnabled && !nativeTools && ToolCallParser.hasOpenCall(raw)
            val visible = if (nativeTools) splitLive.second.trim() else visibleAnswer(splitLive.second, unfinished)

            if (effective.isEmpty() || unfinished || ++rounds > s.maxToolIterations) {
                withContext(NonCancellable) {
                    finishTurn(sessionId, visible, thinkingAll.toString(), tokens, firstAt, lastAt, mediaAll, null)
                }
                return
            }

            publish(activity, mediaAll, thinkingAll, visible, nativeTools)
            val (resultText, media) = executeTools(effective, activity)
            mediaAll += media
            publish(activity, mediaAll, thinkingAll, visible, nativeTools)

            val assistantTurn = Turn(
                role = "assistant",
                text = if (nativeTools) raw.trim() else ToolCallParser.strip(raw).ifBlank { "Let me check that." },
                toolCalls = if (nativeTools) effective else emptyList(),
            )
            turns = if (nativeTools) {
                turns + assistantTurn + effective.map { call ->
                    Turn(
                        role = "tool",
                        text = toolResultFor(call, resultText),
                        toolCallId = call.id,
                        toolName = call.name,
                    )
                }
            } else {
                turns + assistantTurn + Turn(role = "user", text = resultText)
            }
        }
    }

    private fun apiOrEmptyTools(api: ChatBackend): List<ToolSpec> =
        runCatching { toolRunner.tools() }.getOrDefault(emptyList())

    private fun publish(
        activity: List<ToolActivity>,
        media: List<String>,
        thinking: StringBuilder,
        rawAnswer: String,
        nativeTools: Boolean,
    ) {
        val text = if (nativeTools) rawAnswer else ToolCallParser.strip(rawAnswer)
        _streaming.value = StreamingMessage(
            text = text.trim(),
            thinking = thinking.toString().trim(),
            tools = activity.toList(),
            media = media.toList(),
        )
    }

    private suspend fun executeTools(calls: List<ToolCallRequest>, activity: MutableList<ToolActivity>): Pair<String, List<String>> {
        val media = mutableListOf<String>()
        val text = StringBuilder()
        for (call in calls) {
            val index = activity.size
            val parsed = ParsedToolCall(call.id, call.name, call.arguments, call.raw)
            activity += ToolActivity(call.name, compact(call.arguments), ToolStatus.RUNNING)
            _streaming.update { it?.copy(tools = activity.toList()) }
            val run = toolRunner.run(parsed)
            activity[index] = ToolActivity(
                run.name,
                compact(call.arguments),
                if (run.ok) ToolStatus.OK else ToolStatus.FAILED,
                run.result,
                run.media,
            )
            media += run.media
            _streaming.update { it?.copy(tools = activity.toList(), media = media.toList()) }
            text.appendLine("<tool_result name=\"${run.name}\" ok=\"${run.ok}\">")
            text.appendLine(run.result)
            text.appendLine("</tool_result>")
        }
        return text.toString() to media
    }

    private fun toolResultFor(call: ToolCallRequest, allResults: String): String {
        val marker = "<tool_result name=\"${call.name}\""
        val block = allResults.substringAfter(marker, "")
        val body = block.substringAfter('>', block).substringBeforeLast("</tool_result>")
        return body.trim().take(_settings.value.toolResultLimit).ifBlank { "Done." }
    }

    private suspend fun finishTurn(
        sessionId: Long,
        raw: String,
        thinking: String,
        tokens: Int,
        firstTokenAt: Long,
        lastTokenAt: Long,
        media: List<String>,
        failure: Throwable?,
    ) {
        val tps = tokensPerSecond(tokens, firstTokenAt, lastTokenAt)
        _tps.value = tps
        _lastTokenCount.value = tokens

        val finalText = raw.trim()
        val hasVideo = media.any { it.endsWith(".mp4", true) || it.endsWith(".webm", true) }
        val kind = when {
            hasVideo -> MessageKind.VIDEO
            media.isNotEmpty() -> MessageKind.IMAGE
            else -> MessageKind.TEXT
        }
        if (finalText.isNotEmpty() || media.isNotEmpty()) {
            _streaming.value = StreamingMessage(finalText, thinking.trim(), media = media)
            try {
                val id = dao.insertMessageAndTouch(
                    MessageEntity(
                        sessionId = sessionId,
                        role = MessageRole.ASSISTANT,
                        content = finalText,
                        tokenCount = tokens,
                        tokensPerSecond = tps,
                        kind = kind,
                        mediaPath = media.joinToString(";").ifBlank { null },
                        thinking = thinking.trim().ifBlank { null },
                    ),
                )
                _streaming.value = StreamingMessage(finalText, thinking.trim(), media = media, persistedId = id)
                withTimeoutOrNull(1_000) { messages.first { list -> list.any { it.id == id } } }
            } catch (t: Throwable) {
                emit(UiEvent.Message("Reply save nahi hua: ${t.message}"))
            }
        }
        _streaming.value = null

        when {
            failure == null -> {
                _engineState.value = EngineState.Ready
                if (_settings.value.autoSpeak && finalText.isNotBlank()) emit(UiEvent.Speak(finalText))
            }
            failure is ModelOutOfMemoryException || failure is OutOfMemoryError -> {
                runCatching { engine.unload() }
                _loadedModel.value = null
                _engineState.value = EngineState.Error(
                    ErrorType.OOM,
                    "Generate karte waqt memory khatam. Chat save hai — chhota model ya context try karein.",
                )
            }
            failure is ApiException -> _engineState.value = EngineState.Error(ErrorType.API, failure.message ?: "API error")
            else -> {
                emit(UiEvent.Message("Generation failed: ${failure.message ?: "unknown error"}"))
                _engineState.value = EngineState.Ready
            }
        }
    }

    // =========================================================================================
    // Media generation
    // =========================================================================================

    fun generateImage(prompt: String) = generateMedia(MessageKind.IMAGE, prompt)

    fun generateVideo(prompt: String) = generateMedia(MessageKind.VIDEO, prompt)

    private fun generateMedia(kind: MessageKind, prompt: String) {
        val text = prompt.trim()
        if (text.isEmpty()) return
        if (mediaJob?.isActive == true) {
            emit(UiEvent.Message("Ek generation pehle se chal rahi hai…"))
            return
        }
        val s = _settings.value
        if (s.backend != BackendKind.API) {
            emit(UiEvent.Message("Image/video ke liye API backend chahiye (Settings ▸ Backend)."))
            return
        }
        val model = if (kind == MessageKind.VIDEO) s.videoModelId else s.imageModelId
        if (model.isBlank()) {
            emit(UiEvent.Message("${if (kind == MessageKind.VIDEO) "Video" else "Image"} model id Settings ▸ API mein set karein."))
            return
        }
        mediaJob = viewModelScope.launch(Dispatchers.IO) {
            val sessionId = _currentSessionId.value ?: createSession(if (kind == MessageKind.VIDEO) "🎬 $text" else "🖼️ $text")
            dao.insertMessageAndTouch(
                MessageEntity(
                    sessionId = sessionId,
                    role = MessageRole.USER,
                    content = if (kind == MessageKind.VIDEO) "🎬 $text" else "🖼️ $text",
                    tokenCount = estimateTokens(text),
                ),
            )
            _busy.value = if (kind == MessageKind.VIDEO) "Video ban raha hai…" else "Image ban rahi hai…"
            try {
                val api = backend()
                val media = if (kind == MessageKind.VIDEO) {
                    api.generateVideo(model, text) { status -> _busy.value = "Video: $status…" }
                } else {
                    api.generateImage(model, text, s.imageSize)
                }
                dao.insertMessageAndTouch(
                    MessageEntity(
                        sessionId = sessionId,
                        role = MessageRole.ASSISTANT,
                        content = if (kind == MessageKind.VIDEO) "Video ready 🎬\n\n**$text**" else "Image ready 🖼️\n\n**$text**",
                        kind = kind,
                        mediaPath = media.joinToString(";") { it.path },
                    ),
                )
                _currentSessionId.value = sessionId
                emit(UiEvent.Message("Saved: ${media.firstOrNull()?.path ?: "?"}"))
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                dao.insertMessageAndTouch(
                    MessageEntity(
                        sessionId = sessionId,
                        role = MessageRole.ASSISTANT,
                        content = "❌ Generate nahi hua: ${t.message}",
                    ),
                )
                _currentSessionId.value = sessionId
            } finally {
                _busy.value = null
                refreshMedia()
            }
        }
    }

    // =========================================================================================
    // Helpers
    // =========================================================================================

    private fun systemPrompt(s: AppSettings, tools: List<ToolSpec>, nativeTools: Boolean): String = buildString {
        append(s.systemPrompt.trim())
        append("\n\nYou are running inside AML (Advance Model Loader) on Android.")
        append(" Files you write land in the app workspace and are exported to Downloads/AML.")
        if (s.memory.isNotBlank()) {
            append("\n\nThings to remember about the user:\n").append(s.memory.trim())
        }
        if (s.thinkingEnabled) {
            append("\n\nReasoning: think inside one <thinking> … </thinking> block first, then answer.")
        }
        if (s.agentEnabled) {
            if (nativeTools) {
                append("\n\nUse the provided tools when they help; never invent tool output.")
            } else {
                append("\n\n").append(toolRunner.describeForTextProtocol(tools.filter { it.server != null }))
            }
        } else {
            append("\n\nTools are disabled: answer from your own knowledge and say when unsure.")
        }
    }

    private fun genParams(s: AppSettings) = GenParams(
        temperature = s.temperature,
        topP = s.topP,
        topK = s.topK,
        maxTokens = s.maxNewTokens,
        frequencyPenalty = s.frequencyPenalty,
        presencePenalty = s.presencePenalty,
        reasoning = if (s.thinkingEnabled) s.reasoning else ReasoningLevel.OFF,
    )

    private fun MessageEntity.toTurn(): Turn = Turn(
        role = when (role) {
            MessageRole.USER -> "user"
            MessageRole.ASSISTANT -> "assistant"
            MessageRole.SYSTEM -> "system"
            MessageRole.TOOL -> "tool"
        },
        text = content,
        images = if (role == MessageRole.USER) mediaPaths.filter { isImagePath(it) } else emptyList(),
    )

    private suspend fun createSession(firstPrompt: String): Long {
        val title = firstPrompt.lineSequence().first().trim().take(48).ifBlank { "New chat" }
        val s = _settings.value
        val modelName = when (s.backend) {
            BackendKind.API -> "${s.provider}:${s.apiModelId}"
            BackendKind.LOCAL_GGUF -> _loadedModel.value?.name.orEmpty()
        }
        val id = dao.insertSession(ChatSessionEntity(title = title, modelName = modelName))
        _currentSessionId.value = id
        return id
    }

    private fun tokensPerSecond(tokens: Int, firstAt: Long, lastAt: Long): Float {
        if (tokens < 2 || lastAt <= firstAt) return 0f
        return (tokens - 1) * 1000f / (lastAt - firstAt)
    }

    private fun estimateTokens(text: String): Int = max(1, (text.length / 3.8).roundToInt())

    private fun compact(json: org.json.JSONObject): String {
        val text = json.toString()
        return if (text.length <= 160) text else text.take(157) + "…"
    }

    private fun readMemory(): MemorySnapshot {
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val sys = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val proc = Debug.MemoryInfo().also { Debug.getMemoryInfo(it) }
        return MemorySnapshot(proc.totalPss * 1024L, sys.availMem, sys.totalMem)
    }

    private fun memoryTicker(): Flow<MemorySnapshot> = flow {
        while (true) {
            emit(readMemory())
            delay(if (_engineState.value is EngineState.GeneratingText) 500L else 1_500L)
        }
    }.flowOn(Dispatchers.Default)

    private fun emit(event: UiEvent) {
        _events.tryEmit(event)
    }

    override fun onCleared() {
        engine.requestStop()
        thread(name = "aml-unload") { runCatching { engine.unload() } }
    }

    companion object {
        private const val PUBLISH_INTERVAL_MS = 50L
        private const val MIN_KV_RESERVE_BYTES = 256L * 1024 * 1024
        private const val KV_RESERVE_FRACTION = 0.15

        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as Application
                ChatViewModel(
                    app = app,
                    dao = AppDatabase.getInstance(app).chatDao(),
                    engine = NativeLlmEngine(),
                    store = SettingsStore(app),
                )
            }
        }
    }
}

/** Placeholder backend used only until a real one is needed (tools never call generate). */
private object EmptyBackend : ChatBackend {
    override val label = "none"
    override val kind = ProviderKind.LOCAL
    override fun chat(
        model: String,
        system: String,
        turns: List<Turn>,
        tools: List<ToolSpec>,
        params: GenParams,
        stream: Boolean,
    ): Flow<ChatEvent> = flowOf(ChatEvent.Failure("No backend selected"))
    override suspend fun listModels(): List<String> = emptyList()
    override suspend fun generateImage(model: String, prompt: String, size: String) =
        throw ApiException("Backend ready nahi hai.")
    override suspend fun generateVideo(model: String, prompt: String, onProgress: (String) -> Unit) =
        throw ApiException("Backend ready nahi hai.")
}

// =============================================================================================
// Pure helpers shared with the UI
// =============================================================================================

/** Splits a streamed reply into (thinking, answer). */
fun splitThinking(raw: String): Pair<String, String> {
    val open = raw.indexOf(THINK_OPEN)
    if (open < 0) {
        val prefix = raw.trimStart()
        if (prefix.isNotEmpty() && prefix.length < THINK_OPEN.length && THINK_OPEN.startsWith(prefix)) {
            return "" to ""
        }
        return "" to raw
    }
    val close = raw.indexOf(THINK_CLOSE, open + THINK_OPEN.length)
    return if (close < 0) {
        raw.substring(open + THINK_OPEN.length) to raw.substring(0, open)
    } else {
        val thinking = raw.substring(open + THINK_OPEN.length, close)
        (thinking.trim()) to (raw.substring(0, open) + raw.substring(close + THINK_CLOSE.length)).trim()
    }
}

/** Hides a half-written `<tool_call>` block so raw JSON is never shown mid-stream. */
private fun visibleAnswer(text: String, unfinishedCall: Boolean): String {
    val cut = if (unfinishedCall) text.substringBeforeLast("<tool_call>") else text
    return ToolCallParser.strip(cut).trim()
}

private const val THINK_OPEN = "<thinking>"
private const val THINK_CLOSE = "</thinking>"

private fun templateFromSettings(fileName: String, s: AppSettings): PromptTemplate = when (s.localTemplate.lowercase()) {
    "chatml" -> PromptTemplate.CHATML
    "llama3", "llama-3" -> PromptTemplate.LLAMA3
    "gemma" -> PromptTemplate.GEMMA
    else -> PromptTemplate.guess(fileName)
}
