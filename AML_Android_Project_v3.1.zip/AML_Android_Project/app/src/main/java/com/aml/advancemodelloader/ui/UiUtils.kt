package com.aml.advancemodelloader.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.text.format.DateUtils
import java.util.Locale

/** 3_221_225_472 -> "3.00 GB", 734_003_200 -> "700 MB". */
internal fun formatBytes(bytes: Long): String {
    val gb = bytes / 1_073_741_824.0
    return if (gb >= 1.0) {
        String.format(Locale.US, "%.2f GB", gb)
    } else {
        String.format(Locale.US, "%d MB", bytes / 1_048_576L)
    }
}

private val QUANT_REGEX = Regex("(IQ\\d_[A-Z0-9_]+|Q\\d_[A-Z0-9_]+|BF16|F16|F32)", RegexOption.IGNORE_CASE)

/** Pulls a quantisation tag such as "Q4_K_M" out of a GGUF file name, if present. */
internal fun quantLabel(fileName: String): String? =
    QUANT_REGEX.find(fileName)?.value?.uppercase(Locale.US)

internal fun relativeTime(timestamp: Long): String =
    DateUtils.getRelativeTimeSpanString(
        timestamp,
        System.currentTimeMillis(),
        DateUtils.MINUTE_IN_MILLIS,
    ).toString()

internal fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}
