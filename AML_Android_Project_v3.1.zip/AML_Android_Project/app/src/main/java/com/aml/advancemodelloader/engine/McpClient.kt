package com.aml.advancemodelloader.engine

import org.json.JSONArray
import org.json.JSONObject

/** One MCP server the user added. */
data class McpServer(
    val name: String,
    val url: String,
    val token: String = "",
    val enabled: Boolean = true,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("name", name)
        .put("url", url)
        .put("token", token)
        .put("enabled", enabled)

    companion object {
        fun from(json: JSONObject): McpServer = McpServer(
            name = json.optString("name").ifBlank { "MCP" },
            url = json.optString("url"),
            token = json.optString("token"),
            enabled = json.optBoolean("enabled", true),
        )
    }
}

/**
 * Minimal MCP client over the "Streamable HTTP" transport: JSON-RPC 2.0 POSTs to one endpoint, with
 * either `application/json` or an SSE body coming back. Enough to list and call tools of any
 * MCP server (filesystem, git, databases, browser, custom ones).
 */
class McpClient(private val server: McpServer) {

    private var sessionId: String? = null
    private var nextId = 1
    private var initialized = false

    private fun headers(): Map<String, String> = buildMap {
        put("Accept", "application/json, text/event-stream")
        if (server.token.isNotBlank()) put("Authorization", "Bearer ${server.token.trim()}")
        sessionId?.let { put("Mcp-Session-Id", it) }
    }

    /** JSON-RPC request; returns the `result` object. */
    private fun request(method: String, params: JSONObject?): JSONObject {
        val id = nextId++
        val body = JSONObject()
            .put("jsonrpc", "2.0")
            .put("id", id)
            .put("method", method)
        params?.let { body.put("params", it) }

        val conn = Http.send(server.url, "POST", body, "application/json, text/event-stream", headers())
        try {
            val code = conn.responseCode
            val contentType = conn.contentType?.toString().orEmpty()
            if (code !in 200..299) {
                throw ApiException("MCP ${server.name} HTTP $code: ${Http.text(conn.errorStream).take(200)}")
            }
            conn.getHeaderField("Mcp-Session-Id")?.let { sessionId = it }
            if (code == 204 || conn.inputStream == null) return JSONObject()

            val payload = if (contentType.contains("text/event-stream")) {
                var found = ""
                Http.sse(conn.inputStream, { found.isNotEmpty() }) { data ->
                    val json = runCatching { JSONObject(data) }.getOrNull() ?: return@sse
                    if (json.optInt("id", -1) == id) found = data
                }
                found
            } else {
                Http.text(conn.inputStream)
            }
            if (payload.isBlank()) return JSONObject()
            val json = JSONObject(payload)
            json.optJSONObject("error")?.let {
                throw ApiException("MCP ${server.name}: ${it.optString("message")} (${it.optInt("code")})")
            }
            return json.optJSONObject("result") ?: JSONObject()
        } finally {
            conn.disconnect()
        }
    }

    private fun notify(method: String) {
        val body = JSONObject().put("jsonrpc", "2.0").put("method", method)
        runCatching {
            val conn = Http.send(server.url, "POST", body, "application/json, text/event-stream", headers())
            conn.responseCode
            conn.disconnect()
        }
    }

    private fun ensureInitialized() {
        if (initialized) return
        request(
            "initialize",
            JSONObject()
                .put("protocolVersion", "2024-11-05")
                .put("capabilities", JSONObject())
                .put("clientInfo", JSONObject().put("name", "AML").put("version", "3.0")),
        )
        notify("notifications/initialized")
        initialized = true
    }

    /** Lists the server's tools as AML tool specs (server name is kept for routing). */
    fun listTools(): List<ToolSpec> {
        ensureInitialized()
        val result = request("tools/list", JSONObject())
        val tools = result.optJSONArray("tools") ?: JSONArray()
        return (0 until tools.length()).mapNotNull { index ->
            val tool = tools.optJSONObject(index) ?: return@mapNotNull null
            val name = tool.optString("name")
            if (name.isBlank()) return@mapNotNull null
            ToolSpec(
                name = name,
                description = tool.optString("description").ifBlank { "MCP tool from ${server.name}" },
                parameters = tool.optJSONObject("inputSchema")
                    ?: JSONObject().put("type", "object").put("properties", JSONObject()),
                server = server.url,
            )
        }
    }

    /** Calls a tool and flattens its content blocks into text. */
    fun callTool(name: String, arguments: JSONObject): String {
        ensureInitialized()
        val result = request(
            "tools/call",
            JSONObject().put("name", name).put("arguments", arguments),
        )
        val text = StringBuilder()
        val content = result.optJSONArray("content")
        if (content != null) {
            for (index in 0 until content.length()) {
                val block = content.optJSONObject(index) ?: continue
                when (block.optString("type")) {
                    "text" -> text.appendLine(block.optString("text"))
                    "image", "audio" -> text.appendLine("[${block.optString("type")} content omitted]")
                    "resource" -> text.appendLine(block.optJSONObject("resource")?.optString("text").orEmpty())
                    else -> text.appendLine(block.toString())
                }
            }
        }
        if (text.isBlank()) text.append(result.toString())
        return if (result.optBoolean("isError", false)) "ERROR: ${text.toString().trim()}" else text.toString().trim()
    }
}
