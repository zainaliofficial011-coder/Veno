package com.aml.advancemodelloader.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Local chat history for AML (Advance Model Loader).
 *
 * When you change the schema, bump [version] and add a Migration. There is intentionally no
 * fallbackToDestructiveMigration(): it would silently wipe the user's conversations.
 */
@Database(
    entities = [ChatSessionEntity::class, MessageEntity::class],
    version = 2,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun chatDao(): ChatDao

    companion object {
        private const val DB_NAME = "aml_chat.db"

        /** v2 adds message kinds (image / video / tool), attachment paths and reasoning traces. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE chat_messages ADD COLUMN kind TEXT NOT NULL DEFAULT 'TEXT'")
                db.execSQL("ALTER TABLE chat_messages ADD COLUMN mediaPath TEXT")
                db.execSQL("ALTER TABLE chat_messages ADD COLUMN thinking TEXT")
            }
        }

        @Volatile
        private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room
                    .databaseBuilder(context.applicationContext, AppDatabase::class.java, DB_NAME)
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { instance = it }
            }
    }
}
