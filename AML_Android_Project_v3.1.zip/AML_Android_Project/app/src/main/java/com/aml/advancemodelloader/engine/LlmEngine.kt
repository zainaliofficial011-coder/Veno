package com.aml.advancemodelloader.engine

import com.aml.advancemodelloader.data.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

// ---------------------------------------------------------------------------------------------
// Config + value types
// ---------------------------------------------------------------------------------------------

data class ModelConfig(
    val contextSize: Int = 4096,
    /** Half the cores is a good starting point on big.LITTLE SoCs; tune per device. */
    val threads: Int = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 8),
    val useMmap: Boolean = true,
)

data class GenerationConfig(
    val systemPrompt: String = "You are a helpful, concise assistant running fully offline on the user's device.",
    val maxNewTokens: Int = 1024,
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val topK: Int = 40,
)

data class ChatTurn(val role: MessageRole, val content: String)

/** Thrown when the native layer (or the JVM) could not allocate enough memory. */
class ModelOutOfMemoryException(message: String, cause: Throwable? = null) :
    RuntimeException(message, cause)

/** Chat formats for the most common GGUF model families. */
enum class PromptTemplate(val label: String) {
    CHATML("ChatML"),
    LLAMA3("Llama 3"),
    GEMMA("Gemma");

    companion object {
        fun guess(fileName: String): PromptTemplate {
            val n = fileName.lowercase()
            return when {
                "gemma" in n -> GEMMA
                "llama-3" in n || "llama3" in n || "llama_3" in n -> LLAMA3
                else -> CHATML // Qwen, SmolLM, Yi, many fine-tunes
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Engine abstraction (the ViewModel only talks to this, so it can be faked in tests)
// ---------------------------------------------------------------------------------------------

interface LlmEngine {
    val isLoaded: Boolean

    /** Blocking. Call from Dispatchers.IO. Throws on failure ([ModelOutOfMemoryException] for OOM). */
    fun loadModel(path: String, config: ModelConfig)

    /**
     * Cold flow: generation starts on collect and emits one decoded piece (≈ one token) at a time.
     * Cancelling the collector, or calling [requestStop], ends generation.
     */
    fun generate(
        turns: List<ChatTurn>,
        generation: GenerationConfig,
        template: PromptTemplate,
    ): Flow<String>

    /** Same as [generate] but with an already formatted prompt (used by the agent loop). */
    fun generateRaw(prompt: String, generation: GenerationConfig): Flow<String>

    /** Asks the native decoder to stop after the current token. Safe to call from any thread. */
    fun requestStop()

    /** Blocking. Waits for any running generation to finish, then frees the model. */
    fun unload()
}

// ---------------------------------------------------------------------------------------------
// JNI surface. ADAPT THIS to your Phase 1 library: it is the only place that knows the signatures.
//
//   boolean loadModel(String path, int nCtx, int nThreads, boolean useMmap)
//   void    generate(String prompt, int maxNewTokens, float temp, float topP, int topK, TokenCallback cb)
//             -> calls cb.onToken(piece) once per token; must stop when it returns false
//   void    stop()    sets an atomic flag; generate() must reset the flag when it starts
//   void    unload()
//
// Native side requirements:
//   * Throw java.lang.OutOfMemoryError on std::bad_alloc / ggml allocation failure.
//   * Only pass complete UTF-8 to NewStringUTF. Buffer partial multi-byte sequences in C++ until
//     they are complete, otherwise emoji / CJK tokens will crash or turn into garbage.
//   * Tokenize with special-token parsing on and BOS added by the tokenizer, because the templates
//     below do not emit <bos> / <|begin_of_text|> themselves.
// ---------------------------------------------------------------------------------------------

fun interface TokenCallback {
    /** Return false to stop generation. */
    fun onToken(piece: String): Boolean
}

object AmlNative {
    init {
        System.loadLibrary("aml_llm") // TODO: use your Phase 1 library name
    }

    external fun loadModel(path: String, nCtx: Int, nThreads: Int, useMmap: Boolean): Boolean
    external fun generate(
        prompt: String,
        maxNewTokens: Int,
        temperature: Float,
        topP: Float,
        topK: Int,
        callback: TokenCallback,
    )
    external fun stop()
    external fun unload()
}

// ---------------------------------------------------------------------------------------------
// JNI-backed implementation
// ---------------------------------------------------------------------------------------------

class NativeLlmEngine : LlmEngine {

    /** The native context is not thread-safe: load / generate / unload are serialised through this. */
    private val nativeLock = ReentrantLock()

    @Volatile
    private var config = ModelConfig()

    @Volatile
    override var isLoaded: Boolean = false
        private set

    override fun loadModel(path: String, config: ModelConfig) {
        AmlNative.stop()
        nativeLock.withLock {
            if (isLoaded) {
                AmlNative.unload()
                isLoaded = false
            }
            val ok = try {
                AmlNative.loadModel(path, config.contextSize, config.threads, config.useMmap)
            } catch (t: Throwable) {
                throw t.toEngineError()
            }
            check(ok) { "The native backend could not load this file. It may be corrupt or use an unsupported architecture." }
            this.config = config
            isLoaded = true
        }
    }

    override fun generate(
        turns: List<ChatTurn>,
        generation: GenerationConfig,
        template: PromptTemplate,
    ): Flow<String> = generateRaw(
        prompt = PromptBuilder.build(
            template = template,
            system = generation.systemPrompt,
            turns = turns,
            promptTokenBudget = config.contextSize - generation.maxNewTokens,
        ),
        generation = generation,
    )

    override fun generateRaw(prompt: String, generation: GenerationConfig): Flow<String> = callbackFlow {
        check(isLoaded) { "No model is loaded." }

        val finished = AtomicBoolean(false)

        // The JNI call blocks until generation ends, so it gets its own IO coroutine.
        launch(Dispatchers.IO) {
            try {
                nativeLock.withLock {
                    AmlNative.generate(
                        prompt,
                        generation.maxNewTokens,
                        generation.temperature,
                        generation.topP,
                        generation.topK,
                    ) { piece ->
                        // Returning false makes the native loop exit (collector gone or channel closed).
                        trySend(piece).isSuccess && isActive
                    }
                }
                finished.set(true)
                close()
            } catch (t: Throwable) {
                finished.set(true)
                close(t.toEngineError())
            }
        }

        awaitClose { if (!finished.get()) AmlNative.stop() }
    }.buffer(Channel.UNLIMITED) // never drop a token if the UI is momentarily slow

    override fun requestStop() = AmlNative.stop()

    override fun unload() {
        AmlNative.stop()
        nativeLock.withLock {
            if (isLoaded) {
                AmlNative.unload()
                isLoaded = false
            }
        }
    }
}

/** Normalises the many ways native allocation failures surface into one exception type. */
private fun Throwable.toEngineError(): Throwable {
    val msg = message.orEmpty()
    return when {
        this is ModelOutOfMemoryException -> this
        this is OutOfMemoryError -> ModelOutOfMemoryException(msg.ifBlank { "Out of memory" }, this)
        msg.contains("bad_alloc", ignoreCase = true) ||
            msg.contains("out of memory", ignoreCase = true) ||
            msg.contains("failed to allocate", ignoreCase = true) ->
            ModelOutOfMemoryException(msg, this)
        else -> this
    }
}

// ---------------------------------------------------------------------------------------------
// Prompt construction (multi-turn history -> model-specific chat format, trimmed to fit context)
// ---------------------------------------------------------------------------------------------

internal object PromptBuilder {
    private const val CHARS_PER_TOKEN = 3.5

    fun build(
        template: PromptTemplate,
        system: String,
        turns: List<ChatTurn>,
        promptTokenBudget: Int,
    ): String {
        // Keep the newest turns that fit; the oldest ones fall out of the window first.
        val budgetChars = (promptTokenBudget.coerceAtLeast(256) * CHARS_PER_TOKEN).toInt() - system.length
        val kept = ArrayDeque<ChatTurn>()
        var used = 0
        for (turn in turns.asReversed()) {
            val cost = turn.content.length + 24
            if (kept.isNotEmpty() && used + cost > budgetChars) break
            kept.addFirst(turn)
            used += cost
        }
        while (kept.isNotEmpty() && kept.first().role != MessageRole.USER) kept.removeFirst()

        return when (template) {
            PromptTemplate.CHATML -> buildString {
                append("<|im_start|>system\n").append(system).append("<|im_end|>\n")
                kept.forEach {
                    append("<|im_start|>").append(roleName(it.role)).append('\n')
                        .append(it.content).append("<|im_end|>\n")
                }
                append("<|im_start|>assistant\n")
            }

            PromptTemplate.LLAMA3 -> buildString {
                append("<|start_header_id|>system<|end_header_id|>\n\n").append(system).append("<|eot_id|>")
                kept.forEach {
                    append("<|start_header_id|>").append(roleName(it.role))
                        .append("<|end_header_id|>\n\n").append(it.content).append("<|eot_id|>")
                }
                append("<|start_header_id|>assistant<|end_header_id|>\n\n")
            }

            // Gemma has no system role: the system prompt is folded into the first user turn.
            PromptTemplate.GEMMA -> buildString {
                kept.forEachIndexed { index, turn ->
                    val role = if (turn.role == MessageRole.ASSISTANT) "model" else "user"
                    append("<start_of_turn>").append(role).append('\n')
                    if (index == 0 && system.isNotBlank()) append(system).append("\n\n")
                    append(turn.content).append("<end_of_turn>\n")
                }
                append("<start_of_turn>model\n")
            }
        }
    }

    private fun roleName(role: MessageRole) = when (role) {
        MessageRole.SYSTEM -> "system"
        MessageRole.USER -> "user"
        MessageRole.ASSISTANT -> "assistant"
    }
}
