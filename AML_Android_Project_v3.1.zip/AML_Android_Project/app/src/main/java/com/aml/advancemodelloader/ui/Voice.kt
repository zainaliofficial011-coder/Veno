package com.aml.advancemodelloader.ui

import android.content.Context
import android.content.Intent
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import java.util.Locale

/**
 * On-device speech-to-text through the platform recognizer. Returns a controller the composer can
 * drive (mic button) plus the live partial text so the user sees words appear while speaking.
 */
class SpeechController internal constructor(
    private val start: () -> Unit,
    private val stop: () -> Unit,
) {
    fun startListening() = start()
    fun stopListening() = stop()
}

@Composable
fun rememberSpeechController(
    language: String,
    onPartial: (String) -> Unit,
    onFinal: (String) -> Unit,
    onError: (String) -> Unit,
    onListening: (Boolean) -> Unit = {},
): SpeechController {
    val context = LocalContext.current
    val partial by rememberUpdatedState(onPartial)
    val final by rememberUpdatedState(onFinal)
    val error by rememberUpdatedState(onError)
    val listeningState by rememberUpdatedState(onListening)

    val recognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) SpeechRecognizer.createSpeechRecognizer(context) else null
    }
    val intent = remember(language) {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, language.ifBlank { "en-US" })
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
    }

    DisposableEffect(recognizer) {
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) { listeningState(true) }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listeningState(false) }
            override fun onError(errorCode: Int) {
                listeningState(false)
                error(recognizerError(errorCode))
            }
            override fun onResults(results: android.os.Bundle?) {
                listeningState(false)
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isNotBlank()) final(text)
            }
            override fun onPartialResults(partialResults: android.os.Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) partial(text)
            }
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        onDispose { runCatching { recognizer?.destroy() } }
    }

    return remember(recognizer) {
        SpeechController(
            start = {
                if (recognizer == null) error("Is device par speech recognition available nahi hai.")
                else runCatching { recognizer.startListening(intent) }
                    .onFailure { error("Mic start nahi ho saka: ${it.message}") }
            },
            stop = { runCatching { recognizer?.stopListening() } },
        )
    }
}

private fun recognizerError(code: Int): String = when (code) {
    SpeechRecognizer.ERROR_AUDIO -> "Audio error."
    SpeechRecognizer.ERROR_CLIENT -> "Mic client error."
    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mic permission chahiye."
    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network error (offline recognizer?)"
    SpeechRecognizer.ERROR_NO_MATCH -> "Kuch samajh nahi aaya."
    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy hai."
    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Koi awaaz nahi aayi."
    else -> "Speech error ($code)."
}

/** Text-to-speech wrapper: lets assistant messages be read aloud. */
class TtsController internal constructor(
    private val engine: TextToSpeech?,
    private val rate: Float,
) {
    fun speak(text: String) {
        val clean = text.replace(Regex("<[^>]+>"), " ").replace(Regex("[*_`#>]"), "").trim()
        if (clean.isEmpty() || engine == null) return
        engine.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
        engine.speak(clean.take(4_000), TextToSpeech.QUEUE_FLUSH, null, "aml")
    }

    fun stop() {
        runCatching { engine?.stop() }
    }
}

@Composable
fun rememberTts(rate: Float, language: String): TtsController {
    val context = LocalContext.current
    var engine by remember { mutableStateOf<TextToSpeech?>(null) }
    val rateState by rememberUpdatedState(rate)
    val langState by rememberUpdatedState(language)

    DisposableEffect(Unit) {
        var instance: TextToSpeech? = null
        instance = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                runCatching {
                    instance?.language = Locale.forLanguageTag(langState.ifBlank { "en-US" })
                    instance?.setSpeechRate(rateState)
                }
                engine = instance
            }
        }
        onDispose {
            runCatching { instance?.stop() }
            runCatching { instance?.shutdown() }
        }
    }

    return remember(engine) { TtsController(engine, rate) }
}

/** Convenience for opening the system speech settings when the recognizer is missing. */
fun speechSettingsIntent(): Intent = Intent(android.provider.Settings.ACTION_VOICE_INPUT_SETTINGS)
    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

val Context.hasSpeechRecognizer: Boolean
    get() = SpeechRecognizer.isRecognitionAvailable(this)
