package com.aml.advancemodelloader.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {

    // ---- Sessions ---------------------------------------------------------

    @Insert
    suspend fun insertSession(session: ChatSessionEntity): Long

    @Query("SELECT * FROM chat_sessions ORDER BY updatedAt DESC")
    fun observeSessions(): Flow<List<ChatSessionEntity>>

    @Query("SELECT id FROM chat_sessions ORDER BY updatedAt DESC LIMIT 1")
    suspend fun latestSessionId(): Long?

    @Query("UPDATE chat_sessions SET title = :title WHERE id = :sessionId")
    suspend fun renameSession(sessionId: Long, title: String)

    @Query(
        "UPDATE chat_sessions " +
            "SET updatedAt = :timestamp, totalTokens = totalTokens + :addedTokens " +
            "WHERE id = :sessionId",
    )
    suspend fun touchSession(sessionId: Long, timestamp: Long, addedTokens: Int)

    @Query("DELETE FROM chat_sessions WHERE id = :sessionId")
    suspend fun deleteSession(sessionId: Long)

    @Query("DELETE FROM chat_sessions")
    suspend fun deleteAllSessions()

    // ---- Messages ---------------------------------------------------------

    @Insert
    suspend fun insertMessage(message: MessageEntity): Long

    @Query("SELECT * FROM chat_messages WHERE sessionId = :sessionId ORDER BY timestamp ASC, id ASC")
    fun observeMessages(sessionId: Long): Flow<List<MessageEntity>>

    @Query("SELECT * FROM chat_messages WHERE sessionId = :sessionId ORDER BY timestamp ASC, id ASC")
    suspend fun getMessages(sessionId: Long): List<MessageEntity>

    @Query("DELETE FROM chat_messages WHERE id = :messageId")
    suspend fun deleteMessage(messageId: Long)

    /** Inserts the message and bumps the session's `updatedAt` / token total atomically. */
    @Transaction
    suspend fun insertMessageAndTouch(message: MessageEntity): Long {
        val id = insertMessage(message)
        touchSession(message.sessionId, message.timestamp, message.tokenCount)
        return id
    }
}
