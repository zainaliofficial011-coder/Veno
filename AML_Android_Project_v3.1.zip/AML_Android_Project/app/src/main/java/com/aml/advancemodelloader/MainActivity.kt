package com.aml.advancemodelloader

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aml.advancemodelloader.ui.AmlTheme
import com.aml.advancemodelloader.ui.ChatScreen
import com.aml.advancemodelloader.ui.ChatViewModel
import com.aml.advancemodelloader.ui.GalleryScreen
import com.aml.advancemodelloader.ui.ModelSelectorScreen
import com.aml.advancemodelloader.ui.SettingsScreen
import com.aml.advancemodelloader.ui.UiEvent
import com.aml.advancemodelloader.ui.rememberTts
import com.aml.advancemodelloader.ui.openLocalFile
import com.aml.advancemodelloader.ui.openUrl
import com.aml.advancemodelloader.ui.shareText

/** App entry point: chat first, everything else one tap away. */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: ChatViewModel = viewModel(factory = ChatViewModel.Factory)
            val settings by viewModel.settings.collectAsStateWithLifecycle()

            AmlTheme(settings) {
                val context = LocalContext.current
                val snackbarHostState = remember { SnackbarHostState() }
                val tts = rememberTts(settings.speechRate, settings.speechLanguage)
                val currentTts by rememberUpdatedState(tts)

                var route by rememberSaveable { mutableStateOf(Route.CHAT.name) }
                var settingsSection by rememberSaveable { mutableStateOf("system") }

                // Android 13+: the agent's "notify" tool needs this permission.
                val notificationPermission = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission(),
                ) { }
                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                        PackageManager.PERMISSION_GRANTED
                    ) {
                        notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }

                // One place for every one-off event: snackbars, links, media, speech, sharing.
                LaunchedEffect(Unit) {
                    viewModel.events.collect { event ->
                        when (event) {
                            is UiEvent.Message -> snackbarHostState.showSnackbar(event.text, withDismissAction = true)
                            is UiEvent.OpenUrl -> openUrl(event.url, context)
                            is UiEvent.OpenMedia -> openLocalFile(event.path, context)
                            is UiEvent.Speak -> currentTts.speak(event.text)
                            is UiEvent.Share -> shareText(context, event.text)
                        }
                    }
                }

                Scaffold(
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    containerColor = MaterialTheme.colorScheme.background,
                ) { padding ->
                    Box(Modifier.fillMaxSize().padding(padding)) {
                        when (Route.valueOf(route)) {
                            Route.CHAT -> ChatScreen(
                                viewModel = viewModel,
                                onOpenSettings = { section ->
                                    settingsSection = section
                                    route = Route.SETTINGS.name
                                },
                                onOpenGallery = { route = Route.GALLERY.name },
                                onOpenModels = { route = Route.MODELS.name },
                            )
                            Route.SETTINGS -> SettingsScreen(
                                viewModel = viewModel,
                                onBack = { route = Route.CHAT.name },
                                initialSection = settingsSection,
                            )
                            Route.MODELS -> ModelSelectorScreen(
                                viewModel = viewModel,
                                onOpenSettings = { section ->
                                    settingsSection = section
                                    route = Route.SETTINGS.name
                                },
                                onBack = { route = Route.CHAT.name },
                            )
                            Route.GALLERY -> GalleryScreen(viewModel, onBack = { route = Route.CHAT.name })
                        }
                    }
                }

                BackHandler(enabled = route != Route.CHAT.name) { route = Route.CHAT.name }
            }
        }
    }
}

private enum class Route { CHAT, SETTINGS, MODELS, GALLERY }
