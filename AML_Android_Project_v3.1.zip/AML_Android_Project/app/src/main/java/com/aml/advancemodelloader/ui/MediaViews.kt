package com.aml.advancemodelloader.ui

import android.graphics.BitmapFactory
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** True for files the UI should render as a still image. */
fun isImagePath(path: String): Boolean = when (path.substringAfterLast('.', "").lowercase()) {
    "png", "jpg", "jpeg", "webp", "gif", "bmp" -> true
    else -> false
}

fun isVideoPath(path: String): Boolean = when (path.substringAfterLast('.', "").lowercase()) {
    "mp4", "webm", "mkv", "3gp", "mov" -> true
    else -> false
}

fun fileName(path: String): String = path.substringAfterLast('/').ifBlank { path }

/**
 * Decodes a file off the main thread. Big generated PNGs are subsampled, otherwise a 4 MP image
 * would allocate ~16 MB on the UI thread and stutter.
 */
@Composable
fun LocalImage(
    path: String,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    maxDimension: Int = 1_280,
) {
    val bitmap by produceState<ImageBitmap?>(initialValue = null, path, maxDimension) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(path, bounds)
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= maxDimension || bounds.outHeight / (sample * 2) >= maxDimension) {
                    sample *= 2
                }
                val options = BitmapFactory.Options().apply { inSampleSize = sample }
                BitmapFactory.decodeFile(path, options)?.asImageBitmap()
            }.getOrNull()
        }
    }
    val image = bitmap
    if (image == null) {
        Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Image, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    } else {
        Image(
            bitmap = image,
            contentDescription = fileName(path),
            modifier = modifier,
            contentScale = contentScale,
        )
    }
}

/** Inline player for generated videos: tap to play/pause, long press hint via the open button. */
@Composable
fun VideoPlayer(path: String, modifier: Modifier = Modifier) {
    if (!File(path).exists()) {
        Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            Text("Video file missing", style = MaterialTheme.typography.bodySmall)
        }
        return
    }
    AndroidView(
        modifier = modifier,
        factory = { context ->
            VideoView(context).apply {
                setVideoPath(path)
                setMediaController(MediaController(context).also { it.setAnchorView(this) })
                setOnPreparedListener { player ->
                    player.isLooping = true
                }
                setOnCompletionListener { }
            }
        },
    )
}

/**
 * One attachment / generated file inside a message bubble: images and videos render inline, other
 * files get a name chip. Both carry open + delete buttons.
 */
@Composable
fun MediaCard(
    path: String,
    modifier: Modifier = Modifier,
    onOpen: (String) -> Unit,
    onDelete: ((String) -> Unit)? = null,
) {
    val exists = remember(path) { File(path).exists() }
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Column {
            when {
                !exists -> Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.Image, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Missing: ${fileName(path)}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                }

                isVideoPath(path) -> Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
                    VideoPlayer(path, Modifier.fillMaxSize())
                    Surface(
                        modifier = Modifier.padding(8.dp).size(32.dp).clickable { onOpen(path) },
                        shape = RoundedCornerShape(50),
                        color = MaterialTheme.colorScheme.scrim.copy(alpha = 0.45f),
                    ) {
                        Icon(
                            Icons.Filled.PlayArrow,
                            contentDescription = "Open video",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.padding(4.dp),
                        )
                    }
                }

                else -> LocalImage(
                    path = path,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .clickable { onOpen(path) },
                    contentScale = ContentScale.Fit,
                )
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Icon(
                    if (isVideoPath(path)) Icons.Filled.Videocam else Icons.Filled.Image,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    fileName(path),
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { onOpen(path) }) {
                    Icon(Icons.Filled.OpenInNew, contentDescription = "Open", modifier = Modifier.size(18.dp))
                }
                if (onDelete != null) {
                    IconButton(onClick = { onDelete(path) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
