package com.aml.advancemodelloader.engine

import android.util.Base64
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Anthropic Claude (Messages API). Differences from OpenAI are handled here: the system prompt is a
 * top-level field, tools use `input_schema`, results come back as `tool_result` content blocks, and
 * extended thinking streams as `thinking_delta`.
 */
class AnthropicClient(
    private val baseUrl: () -> String,
    private val apiKey: () -> String,
) : ChatBackend {

    override val label = "Anthropic"
    override val kind = ProviderKind.ANTHROPIC

    private fun endpoint(path: String): String = Http.joinUrl(baseUrl(), path)

    private fun headers(): Map<String, String> = buildMap {
        put("x-api-key", apiKey().trim())
        put("anthropic-version", "2023-06-01")
    }

    // -----------------------------------------------------------------------------------------
    // Chat
    // -----------------------------------------------------------------------------------------

    override fun chat(
        model: String,
        system: String,
        turns: List<Turn>,
        tools: List<ToolSpec>,
        params: GenParams,
        stream: Boolean,
    ): Flow<ChatEvent> = flow {
        val thinking = params.reasoning != ReasoningLevel.OFF
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", params.maxTokens)
            .put("stream", stream)
        if (system.isNotBlank()) body.put("system", system)
        if (thinking) {
            // Anthropic requires temperature = 1 while extended thinking is on.
            body.put("thinking", JSONObject().put("type", "enabled").put("budget_tokens", budget(params.reasoning)))
        } else {
            body.put("temperature", params.temperature.toDouble())
            body.put("top_p", params.topP.toDouble())
        }
        body.put("messages", messages(turns))
        if (tools.isNotEmpty()) {
            val arr = JSONArray()
            tools.forEach { tool ->
                arr.put(
                    JSONObject().put("name", tool.name)
                        .put("description", tool.description)
                        .put("input_schema", tool.parameters),
                )
            }
            body.put("tools", arr)
        }

        val conn = Http.send(endpoint("v1/messages"), "POST", body, "text/event-stream, application/json", headers())
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw Http.errorFrom(code, Http.text(conn.errorStream), "Anthropic")
            if (!stream) {
                whole(Http.text(conn.inputStream)).forEach { emit(it) }
                emit(ChatEvent.Done)
                return@flow
            }

            val assembler = CallAssembler()
            val pending = mutableListOf<ChatEvent>()
            var index = 0
            Http.sse(conn.inputStream, { !currentCoroutineContext().isActive }) { payload ->
                val json = runCatching { JSONObject(payload) }.getOrNull() ?: return@sse
                when (json.optString("type")) {
                    "content_block_start" -> {
                        index = json.optInt("index", index)
                        val block = json.optJSONObject("content_block")
                        if (block?.optString("type") == "tool_use") {
                            assembler.add(index, block.optString("id"), block.optString("name"), null)
                        }
                    }
                    "content_block_delta" -> {
                        index = json.optInt("index", index)
                        val delta = json.optJSONObject("delta")
                        if (delta != null) {
                            when (delta.optString("type")) {
                                "text_delta" -> delta.optString("text").takeIf { it.isNotEmpty() }
                                    ?.let { pending += ChatEvent.Text(it) }
                                "thinking_delta" -> delta.optString("thinking").takeIf { it.isNotEmpty() }
                                    ?.let { pending += ChatEvent.Reasoning(it) }
                                "input_json_delta" -> assembler.add(index, null, null, delta.optString("partial_json"))
                            }
                        }
                    }
                    "error" -> pending += ChatEvent.Failure(json.optJSONObject("error")?.optString("message") ?: "Anthropic error")
                }
            }
            pending.forEach { emit(it) }
            if (!assembler.isEmpty()) emit(ChatEvent.Calls(assembler.build()))
            emit(ChatEvent.Done)
        } finally {
            conn.disconnect()
        }
    }.flowOn(kotlinx.coroutines.Dispatchers.IO)

    private fun budget(level: ReasoningLevel): Int = when (level) {
        ReasoningLevel.LOW -> 1_024
        ReasoningLevel.MEDIUM -> 4_096
        ReasoningLevel.HIGH -> 8_192
        ReasoningLevel.OFF -> 0
    }

    /** Builds the Anthropic message array, merging consecutive tool results into one user turn. */
    private fun messages(turns: List<Turn>): JSONArray {
        val out = JSONArray()
        val toolResults = mutableListOf<JSONObject>()

        fun flushTools() {
            if (toolResults.isEmpty()) return
            val content = JSONArray()
            toolResults.forEach { content.put(it) }
            out.put(JSONObject().put("role", "user").put("content", content))
            toolResults.clear()
        }

        turns.forEach { turn ->
            if (turn.role == "tool") {
                val block = JSONObject()
                    .put("type", "tool_result")
                    .put("tool_use_id", turn.toolCallId ?: "")
                    .put("content", turn.text)
                if (turn.text.startsWith("ERROR")) block.put("is_error", true)
                toolResults += block
                return@forEach
            }
            flushTools()

            val content = JSONArray()
            if (turn.text.isNotBlank()) content.put(JSONObject().put("type", "text").put("text", turn.text))
            turn.images.forEach { path -> imageBlock(path)?.let { content.put(it) } }
            turn.toolCalls.forEach { call ->
                content.put(
                    JSONObject().put("type", "tool_use")
                        .put("id", call.id)
                        .put("name", call.name)
                        .put("input", call.arguments),
                )
            }
            if (content.length() == 0) content.put(JSONObject().put("type", "text").put("text", " "))
            val role = if (turn.role == "assistant") "assistant" else "user"
            out.put(JSONObject().put("role", role).put("content", content))
        }
        flushTools()
        return out
    }

    private fun imageBlock(path: String): JSONObject? {
        val file = File(path)
        if (!file.exists() || file.length() == 0L) return null
        val media = when (file.extension.lowercase()) {
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            else -> "image/jpeg"
        }
        val data = runCatching { Base64.encodeToString(file.readBytes(), Base64.NO_WRAP) }.getOrNull() ?: return null
        return JSONObject()
            .put("type", "image")
            .put("source", JSONObject().put("type", "base64").put("media_type", media).put("data", data))
    }

    private fun whole(body: String): List<ChatEvent> {
        if (body.isBlank()) return emptyList()
        val json = runCatching { JSONObject(body) }.getOrNull() ?: return emptyList()
        json.optJSONObject("error")?.let { return listOf(ChatEvent.Failure(it.optString("message"))) }
        val out = mutableListOf<ChatEvent>()
        val calls = mutableListOf<ToolCallRequest>()
        Js.arrayOfNullsOrEmpty(json.optJSONArray("content")).forEach { block ->
            when (block.optString("type")) {
                "text" -> block.optString("text").takeIf { it.isNotEmpty() }?.let { out += ChatEvent.Text(it) }
                "thinking" -> block.optString("thinking").takeIf { it.isNotEmpty() }?.let { out += ChatEvent.Reasoning(it) }
                "tool_use" -> {
                    val input = block.optJSONObject("input") ?: JSONObject()
                    calls += ToolCallRequest(
                        id = block.optString("id"),
                        name = block.optString("name"),
                        arguments = input,
                        raw = input.toString(),
                    )
                }
            }
        }
        if (calls.isNotEmpty()) out += ChatEvent.Calls(calls)
        return out
    }

    // -----------------------------------------------------------------------------------------
    // Models
    // -----------------------------------------------------------------------------------------

    override suspend fun listModels(): List<String> {
        val conn = Http.open(endpoint("v1/models?limit=100"), "GET", "application/json")
        headers().forEach { (k, v) -> conn.setRequestProperty(k, v) }
        return try {
            val code = conn.responseCode
            val body = Http.text(if (code in 200..299) conn.inputStream else conn.errorStream)
            if (code !in 200..299) throw Http.errorFrom(code, body, "Anthropic")
            Js.arrayOfNullsOrEmpty(runCatching { JSONObject(body).optJSONArray("data") }.getOrNull())
                .mapNotNull { it.optString("id").takeIf { id -> id.isNotBlank() } }
                .sorted()
        } finally {
            conn.disconnect()
        }
    }

    override suspend fun generateImage(model: String, prompt: String, size: String): List<GeneratedMedia> =
        throw ApiException("Anthropic ke paas image endpoint nahi hai — image ke liye OpenAI/Gemini provider chunein.")

    override suspend fun generateVideo(model: String, prompt: String, onProgress: (String) -> Unit): List<GeneratedMedia> =
        throw ApiException("Anthropic video generate nahi karta — video ke liye doosra provider chunein.")
}
