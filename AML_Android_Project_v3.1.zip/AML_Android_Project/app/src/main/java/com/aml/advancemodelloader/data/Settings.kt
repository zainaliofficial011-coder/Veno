package com.aml.advancemodelloader.data

import android.content.Context
import com.aml.advancemodelloader.engine.McpServer
import com.aml.advancemodelloader.engine.ProviderKind
import com.aml.advancemodelloader.engine.ReasoningLevel
import org.json.JSONArray
import org.json.JSONObject

/** Where replies come from: a local GGUF model (llama.cpp) or a remote API. */
enum class BackendKind { LOCAL_GGUF, API }

enum class ThemeMode { SYSTEM, LIGHT, DARK }

enum class AccentColor(val label: String, val argb: Long) {
    BLUE("Blue", 0xFF0B57D0),
    TEAL("Teal", 0xFF0E8A82),
    PURPLE("Purple", 0xFF6C4BD8),
    ROSE("Rose", 0xFFC2185B),
    ORANGE("Orange", 0xFFE06C00),
    GREEN("Green", 0xFF2E7D32);

    companion object {
        fun from(name: String): AccentColor = entries.firstOrNull { it.name.equals(name, true) } ?: BLUE
    }
}

/** A saved persona: one tap sets the system prompt. */
data class Persona(val name: String, val prompt: String) {
    fun toJson(): JSONObject = JSONObject().put("name", name).put("prompt", prompt)

    companion object {
        fun from(json: JSONObject): Persona = Persona(json.optString("name"), json.optString("prompt"))
        fun default(): List<Persona> = listOf(
            Persona(
                "Default",
                "You are AML, a helpful offline-first assistant running on the user's own device. " +
                    "Be concise and accurate. Use Markdown for structure and code.",
            ),
            Persona(
                "Coder",
                "You are AML in coding mode. Write complete, runnable code with short explanations, " +
                    "prefer standard libraries and show file names in code blocks.",
            ),
            Persona(
                "Teacher",
                "You are AML in teacher mode. Explain step by step in simple Roman Urdu + English, " +
                    "use everyday examples, and finish with 3 practice questions.",
            ),
            Persona(
                "Researcher",
                "You are AML in research mode. Search the web, cite the links you used, separate facts " +
                    "from guesses, and end with a short summary.",
            ),
            Persona(
                "Writer",
                "You are AML in writing mode. Produce polished, well-structured text with headings, " +
                    "and ask before changing the user's tone or length.",
            ),
        )
    }
}

/** Everything the user can configure, persisted in SharedPreferences. */
data class AppSettings(
    // ---- Backend ----
    val backend: BackendKind = BackendKind.LOCAL_GGUF,
    val provider: String = "OpenAI",
    val providerKind: ProviderKind = ProviderKind.OPENAI,

    // ---- Local (GGUF) ----
    val contextSize: Int = 4096,
    val threads: Int = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 8),
    val useMmap: Boolean = true,
    val localTemplate: String = "auto",

    // ---- Remote API ----
    val apiBaseUrl: String = "https://api.openai.com/v1",
    val apiKey: String = "",
    val apiModelId: String = "gpt-4o-mini",
    val imageModelId: String = "dall-e-3",
    val videoModelId: String = "",
    val imageSize: String = "1024x1024",
    val streamApi: Boolean = true,
    val useNativeTools: Boolean = true,

    // ---- Generation ----
    val systemPrompt: String = Persona.default().first().prompt,
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val topK: Int = 40,
    val maxNewTokens: Int = 1024,
    val frequencyPenalty: Float = 0f,
    val presencePenalty: Float = 0f,
    val reasoning: ReasoningLevel = ReasoningLevel.OFF,

    // ---- Agent + tools ----
    val agentEnabled: Boolean = true,
    val thinkingEnabled: Boolean = true,
    val maxToolIterations: Int = 6,
    val toolResultLimit: Int = 6_000,
    val mcpServers: List<McpServer> = emptyList(),

    // ---- Voice ----
    val autoSpeak: Boolean = false,
    val speechRate: Float = 1.0f,
    val speechLanguage: String = "en-US",

    // ---- Appearance ----
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accent: AccentColor = AccentColor.BLUE,
    val fontScale: Float = 1.0f,

    // ---- Personas + memory ----
    val personas: List<Persona> = Persona.default(),
    val memory: String = "",
) {
    fun api() = ApiSettings(apiBaseUrl, apiKey, apiModelId, providerKind)
}

data class ApiSettings(val baseUrl: String, val key: String, val model: String, val kind: ProviderKind)

class SettingsStore(context: Context) {

    private val prefs = context.getSharedPreferences("aml_settings", Context.MODE_PRIVATE)

    fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            backend = enumOf(prefs.getString(K_BACKEND, null), d.backend),
            provider = prefs.getString(K_PROVIDER, d.provider) ?: d.provider,
            providerKind = runCatching { ProviderKind.valueOf(prefs.getString(K_PROVIDER_KIND, d.providerKind.name)!!) }
                .getOrDefault(d.providerKind),
            contextSize = prefs.getInt(K_CTX, d.contextSize),
            threads = prefs.getInt(K_THREADS, d.threads),
            useMmap = prefs.getBoolean(K_MMAP, d.useMmap),
            localTemplate = prefs.getString(K_TEMPLATE, d.localTemplate) ?: d.localTemplate,
            apiBaseUrl = prefs.getString(K_BASE_URL, d.apiBaseUrl) ?: d.apiBaseUrl,
            apiKey = prefs.getString(K_API_KEY, d.apiKey) ?: d.apiKey,
            apiModelId = prefs.getString(K_MODEL_ID, d.apiModelId) ?: d.apiModelId,
            imageModelId = prefs.getString(K_IMAGE_MODEL, d.imageModelId) ?: d.imageModelId,
            videoModelId = prefs.getString(K_VIDEO_MODEL, d.videoModelId) ?: d.videoModelId,
            imageSize = prefs.getString(K_IMAGE_SIZE, d.imageSize) ?: d.imageSize,
            streamApi = prefs.getBoolean(K_STREAM, d.streamApi),
            useNativeTools = prefs.getBoolean(K_NATIVE_TOOLS, d.useNativeTools),
            systemPrompt = prefs.getString(K_SYSTEM, d.systemPrompt) ?: d.systemPrompt,
            temperature = prefs.getFloat(K_TEMP, d.temperature),
            topP = prefs.getFloat(K_TOPP, d.topP),
            topK = prefs.getInt(K_TOPK, d.topK),
            maxNewTokens = prefs.getInt(K_MAX_TOKENS, d.maxNewTokens),
            frequencyPenalty = prefs.getFloat(K_FREQ, d.frequencyPenalty),
            presencePenalty = prefs.getFloat(K_PRES, d.presencePenalty),
            reasoning = ReasoningLevel.from(prefs.getString(K_REASONING, d.reasoning.name)!!),
            agentEnabled = prefs.getBoolean(K_AGENT, d.agentEnabled),
            thinkingEnabled = prefs.getBoolean(K_THINKING, d.thinkingEnabled),
            maxToolIterations = prefs.getInt(K_MAX_ITER, d.maxToolIterations),
            toolResultLimit = prefs.getInt(K_TOOL_LIMIT, d.toolResultLimit),
            mcpServers = readServers(),
            autoSpeak = prefs.getBoolean(K_AUTO_SPEAK, d.autoSpeak),
            speechRate = prefs.getFloat(K_SPEECH_RATE, d.speechRate),
            speechLanguage = prefs.getString(K_SPEECH_LANG, d.speechLanguage) ?: d.speechLanguage,
            themeMode = enumOf(prefs.getString(K_THEME, null), d.themeMode),
            accent = AccentColor.from(prefs.getString(K_ACCENT, d.accent.name) ?: d.accent.name),
            fontScale = prefs.getFloat(K_FONT_SCALE, d.fontScale),
            personas = readPersonas(d.personas),
            memory = prefs.getString(K_MEMORY, d.memory) ?: d.memory,
        )
    }

    fun save(s: AppSettings) {
        prefs.edit()
            .putString(K_BACKEND, s.backend.name)
            .putString(K_PROVIDER, s.provider)
            .putString(K_PROVIDER_KIND, s.providerKind.name)
            .putInt(K_CTX, s.contextSize)
            .putInt(K_THREADS, s.threads)
            .putBoolean(K_MMAP, s.useMmap)
            .putString(K_TEMPLATE, s.localTemplate)
            .putString(K_BASE_URL, s.apiBaseUrl)
            .putString(K_API_KEY, s.apiKey)
            .putString(K_MODEL_ID, s.apiModelId)
            .putString(K_IMAGE_MODEL, s.imageModelId)
            .putString(K_VIDEO_MODEL, s.videoModelId)
            .putString(K_IMAGE_SIZE, s.imageSize)
            .putBoolean(K_STREAM, s.streamApi)
            .putBoolean(K_NATIVE_TOOLS, s.useNativeTools)
            .putString(K_SYSTEM, s.systemPrompt)
            .putFloat(K_TEMP, s.temperature)
            .putFloat(K_TOPP, s.topP)
            .putInt(K_TOPK, s.topK)
            .putInt(K_MAX_TOKENS, s.maxNewTokens)
            .putFloat(K_FREQ, s.frequencyPenalty)
            .putFloat(K_PRES, s.presencePenalty)
            .putString(K_REASONING, s.reasoning.name)
            .putBoolean(K_AGENT, s.agentEnabled)
            .putBoolean(K_THINKING, s.thinkingEnabled)
            .putInt(K_MAX_ITER, s.maxToolIterations)
            .putInt(K_TOOL_LIMIT, s.toolResultLimit)
            .putString(K_MCP, serversJson(s.mcpServers))
            .putBoolean(K_AUTO_SPEAK, s.autoSpeak)
            .putFloat(K_SPEECH_RATE, s.speechRate)
            .putString(K_SPEECH_LANG, s.speechLanguage)
            .putString(K_THEME, s.themeMode.name)
            .putString(K_ACCENT, s.accent.name)
            .putFloat(K_FONT_SCALE, s.fontScale)
            .putString(K_PERSONAS, personasJson(s.personas))
            .putString(K_MEMORY, s.memory)
            .apply()
    }

    private inline fun <reified T : Enum<T>> enumOf(value: String?, fallback: T): T =
        runCatching { enumValueOf<T>(value!!) }.getOrDefault(fallback)

    private fun serversJson(servers: List<McpServer>): String {
        val arr = JSONArray()
        servers.forEach { arr.put(it.toJson()) }
        return arr.toString()
    }

    private fun readServers(): List<McpServer> = runCatching {
        val arr = JSONArray(prefs.getString(K_MCP, "[]"))
        (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { McpServer.from(it) } }
    }.getOrDefault(emptyList())

    private fun personasJson(personas: List<Persona>): String {
        val arr = JSONArray()
        personas.forEach { arr.put(it.toJson()) }
        return arr.toString()
    }

    private fun readPersonas(fallback: List<Persona>): List<Persona> = runCatching {
        val arr = JSONArray(prefs.getString(K_PERSONAS, "[]"))
        val list = (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { Persona.from(it) } }
        list.ifEmpty { fallback }
    }.getOrDefault(fallback)

    private companion object {
        const val K_BACKEND = "backend"
        const val K_PROVIDER = "provider"
        const val K_PROVIDER_KIND = "provider_kind"
        const val K_CTX = "ctx"
        const val K_THREADS = "threads"
        const val K_MMAP = "mmap"
        const val K_TEMPLATE = "template"
        const val K_BASE_URL = "base_url"
        const val K_API_KEY = "api_key"
        const val K_MODEL_ID = "model_id"
        const val K_IMAGE_MODEL = "image_model"
        const val K_VIDEO_MODEL = "video_model"
        const val K_IMAGE_SIZE = "image_size"
        const val K_STREAM = "stream"
        const val K_NATIVE_TOOLS = "native_tools"
        const val K_SYSTEM = "system"
        const val K_TEMP = "temp"
        const val K_TOPP = "topp"
        const val K_TOPK = "topk"
        const val K_MAX_TOKENS = "max_tokens"
        const val K_FREQ = "freq_penalty"
        const val K_PRES = "pres_penalty"
        const val K_REASONING = "reasoning"
        const val K_AGENT = "agent"
        const val K_THINKING = "thinking"
        const val K_MAX_ITER = "max_iterations"
        const val K_TOOL_LIMIT = "tool_result_limit"
        const val K_MCP = "mcp_servers"
        const val K_AUTO_SPEAK = "auto_speak"
        const val K_SPEECH_RATE = "speech_rate"
        const val K_SPEECH_LANG = "speech_lang"
        const val K_THEME = "theme"
        const val K_ACCENT = "accent"
        const val K_FONT_SCALE = "font_scale"
        const val K_PERSONAS = "personas"
        const val K_MEMORY = "memory"
    }
}
