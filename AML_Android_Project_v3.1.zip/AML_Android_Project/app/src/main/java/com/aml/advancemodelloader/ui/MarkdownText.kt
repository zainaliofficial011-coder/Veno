package com.aml.advancemodelloader.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// =============================================================================================
// Block model + parser. Pure Kotlin, so it is cheap to unit test and tolerant of half-streamed text
// (an unclosed ``` fence simply renders as an open code block until the closing fence arrives).
// =============================================================================================

sealed interface MdBlock {
    data class Heading(val level: Int, val text: String) : MdBlock
    data class Paragraph(val text: String) : MdBlock
    data class Bullet(val indent: Int, val marker: String, val text: String) : MdBlock
    data class Quote(val text: String) : MdBlock
    data class Code(val language: String, val code: String) : MdBlock
    data class Table(val header: List<String>, val rows: List<List<String>>) : MdBlock
    data object Rule : MdBlock
}

private val HEADING = Regex("^(#{1,6})\\s+(.*)$")
private val BULLET = Regex("^(\\s*)([-*+]|\\d+[.)])\\s+(.*)$")
private val RULE = Regex("^\\s{0,3}([-*_])(\\s*\\1){2,}\\s*$")
private val TABLE_SEPARATOR = Regex("^\\|?\\s*:?-{2,}:?\\s*(\\|\\s*:?-{2,}:?\\s*)*\\|?$")
private const val ESCAPABLE = "\\`*_{}[]()#+-.!~>|"

private fun splitRow(line: String): List<String> =
    line.trim().trim('|').split('|').map { it.trim() }

fun parseMarkdown(source: String): List<MdBlock> {
    val blocks = mutableListOf<MdBlock>()
    val lines = source.replace("\r\n", "\n").split('\n')
    val paragraph = mutableListOf<String>()

    fun flushParagraph() {
        if (paragraph.isNotEmpty()) {
            blocks += MdBlock.Paragraph(paragraph.joinToString("\n"))
            paragraph.clear()
        }
    }

    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        val trimmed = line.trim()
        when {
            trimmed.startsWith("```") -> {
                flushParagraph()
                val language = trimmed.removePrefix("```").trim()
                val body = mutableListOf<String>()
                i++
                while (i < lines.size && !lines[i].trim().startsWith("```")) {
                    body += lines[i]
                    i++
                }
                blocks += MdBlock.Code(language, body.joinToString("\n"))
                // i now sits on the closing fence (or past the end while still streaming).
            }

            trimmed.isEmpty() -> flushParagraph()

            RULE.matches(line) -> {
                flushParagraph()
                blocks += MdBlock.Rule
            }

            HEADING.matches(trimmed) -> {
                flushParagraph()
                val m = HEADING.matchEntire(trimmed)!!
                blocks += MdBlock.Heading(m.groupValues[1].length, m.groupValues[2])
            }

            trimmed.startsWith("|") && i + 1 < lines.size && TABLE_SEPARATOR.matches(lines[i + 1].trim()) -> {
                flushParagraph()
                val header = splitRow(trimmed)
                val rows = mutableListOf<List<String>>()
                i += 2
                while (i < lines.size && lines[i].trim().startsWith("|")) {
                    rows += splitRow(lines[i])
                    i++
                }
                blocks += MdBlock.Table(header, rows)
                continue // i already points past the table
            }

            trimmed.startsWith(">") -> {
                flushParagraph()
                val content = trimmed.removePrefix(">").trim()
                val last = blocks.lastOrNull()
                if (last is MdBlock.Quote && i > 0 && lines[i - 1].trim().startsWith(">")) {
                    blocks[blocks.lastIndex] = last.copy(text = last.text + "\n" + content)
                } else {
                    blocks += MdBlock.Quote(content)
                }
            }

            BULLET.matches(line) -> {
                flushParagraph()
                val m = BULLET.matchEntire(line)!!
                val marker = m.groupValues[2].let { if (it.first().isDigit()) it else "•" }
                blocks += MdBlock.Bullet(m.groupValues[1].length / 2, marker, m.groupValues[3])
            }

            else -> paragraph += line
        }
        i++
    }
    flushParagraph()
    return blocks
}

// =============================================================================================
// Inline parser: `code`, **bold**, *italic* / _italic_, ~~strike~~, [text](url), backslash escapes
// =============================================================================================

private data class InlineStyle(
    val codeBackground: Color,
    val codeForeground: Color,
    val link: Color,
)

private fun AnnotatedString.Builder.appendInline(text: String, style: InlineStyle) {
    val plain = StringBuilder()
    fun flush() {
        if (plain.isNotEmpty()) {
            append(plain.toString())
            plain.clear()
        }
    }

    var i = 0
    while (i < text.length) {
        val c = text[i]

        if (c == '\\' && i + 1 < text.length && text[i + 1] in ESCAPABLE) {
            plain.append(text[i + 1])
            i += 2
            continue
        }

        if (c == '`') {
            val end = text.indexOf('`', i + 1)
            if (end > i + 1) {
                flush()
                withStyle(
                    SpanStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp,
                        background = style.codeBackground,
                        color = style.codeForeground,
                    ),
                ) { append(text.substring(i + 1, end)) }
                i = end + 1
                continue
            }
        }

        if (c == '*' && text.startsWith("**", i)) {
            val end = text.indexOf("**", i + 2)
            if (end > i + 2) {
                flush()
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { appendInline(text.substring(i + 2, end), style) }
                i = end + 2
                continue
            }
        }

        if (c == '~' && text.startsWith("~~", i)) {
            val end = text.indexOf("~~", i + 2)
            if (end > i + 2) {
                flush()
                withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) {
                    appendInline(text.substring(i + 2, end), style)
                }
                i = end + 2
                continue
            }
        }

        // Italic. Underscores only count at word boundaries so snake_case_names stay intact.
        if ((c == '*' || c == '_') &&
            i + 1 < text.length &&
            !text[i + 1].isWhitespace() &&
            text[i + 1] != c &&
            (c == '*' || i == 0 || !text[i - 1].isLetterOrDigit())
        ) {
            val end = text.indexOf(c, i + 1)
            if (end > i + 1 &&
                !text[end - 1].isWhitespace() &&
                (c == '*' || end + 1 >= text.length || !text[end + 1].isLetterOrDigit())
            ) {
                flush()
                withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { appendInline(text.substring(i + 1, end), style) }
                i = end + 1
                continue
            }
        }

        if (c == '[') {
            val mid = text.indexOf("](", i + 1)
            val end = if (mid > 0) text.indexOf(')', mid + 2) else -1
            if (mid > i && end > mid) {
                flush()
                val url = text.substring(mid + 2, end).trim()
                withLink(
                    LinkAnnotation.Url(
                        url,
                        TextLinkStyles(SpanStyle(color = style.link, textDecoration = TextDecoration.Underline)),
                    ),
                ) { append(text.substring(i + 1, mid)) }
                i = end + 1
                continue
            }
        }

        plain.append(c)
        i++
    }
    flush()
}

// =============================================================================================
// Composables
// =============================================================================================

/** Renders Markdown in the current text colour. Safe to call with partial, still-streaming text. */
@Composable
fun MarkdownText(markdown: String, modifier: Modifier = Modifier) {
    val scheme = MaterialTheme.colorScheme
    val inline = InlineStyle(
        codeBackground = scheme.surfaceVariant,
        codeForeground = scheme.onSurface,
        link = scheme.primary,
    )
    val blocks = remember(markdown) { parseMarkdown(markdown) }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        blocks.forEach { block ->
            when (block) {
                is MdBlock.Paragraph -> InlineText(block.text, inline)

                is MdBlock.Heading -> InlineText(
                    block.text,
                    inline,
                    fontSize = when (block.level) {
                        1 -> 22.sp
                        2 -> 20.sp
                        3 -> 18.sp
                        else -> 16.sp
                    },
                    fontWeight = FontWeight.Bold,
                )

                is MdBlock.Bullet -> Row(Modifier.padding(start = (block.indent * 16).dp)) {
                    Text(
                        block.marker,
                        fontSize = 16.sp,
                        lineHeight = 24.sp,
                        color = scheme.onSurfaceVariant,
                        modifier = Modifier.width(24.dp),
                    )
                    InlineText(block.text, inline, Modifier.weight(1f))
                }

                is MdBlock.Quote -> Row(Modifier.height(IntrinsicSize.Min)) {
                    Box(
                        Modifier
                            .width(3.dp)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(2.dp))
                            .background(scheme.outline),
                    )
                    Spacer(Modifier.width(10.dp))
                    InlineText(block.text, inline, color = scheme.onSurfaceVariant)
                }

                is MdBlock.Code -> CodeBlock(block.language, block.code)
                is MdBlock.Table -> TableBlock(block, inline)
                MdBlock.Rule -> HorizontalDivider(color = scheme.outline)
            }
        }
    }
}

@Composable
private fun InlineText(
    text: String,
    style: InlineStyle,
    modifier: Modifier = Modifier,
    fontSize: androidx.compose.ui.unit.TextUnit = 16.sp,
    fontWeight: FontWeight? = null,
    color: Color = Color.Unspecified,
) {
    val annotated = remember(text, style) { buildAnnotatedString { appendInline(text, style) } }
    Text(
        text = annotated,
        modifier = modifier,
        fontSize = fontSize,
        lineHeight = fontSize * 1.5f,
        fontWeight = fontWeight,
        color = color,
    )
}

@Composable
private fun CodeBlock(language: String, code: String) {
    val context = LocalContext.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1_500)
            copied = false
        }
    }

    val headerColor = Color(0xFF161B22)
    val bodyColor = Color(0xFF0D1117)
    val muted = Color(0xFF9DA7B3)

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(bodyColor),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(headerColor)
                .padding(start = 12.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(language.ifBlank { "code" }, fontSize = 12.sp, color = muted)
            TextButton(
                onClick = {
                    copyToClipboard(context, "AML code", code)
                    copied = true
                },
                contentPadding = PaddingValues(horizontal = 8.dp),
                colors = ButtonDefaults.textButtonColors(contentColor = muted),
            ) {
                Icon(
                    if (copied) Icons.Default.Check else Icons.Default.ContentCopy,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp),
                )
                Spacer(Modifier.width(6.dp))
                Text(if (copied) "Copied" else "Copy", fontSize = 12.sp)
            }
        }
        Text(
            text = code,
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            lineHeight = 19.sp,
            color = Color(0xFFE6EDF3),
            softWrap = false,
            modifier = Modifier
                .horizontalScroll(rememberScrollState())
                .padding(12.dp),
        )
    }
}

@Composable
private fun TableBlock(table: MdBlock.Table, inline: InlineStyle) {
    val scheme = MaterialTheme.colorScheme
    val columns = table.header.size
    val shape = RoundedCornerShape(8.dp)

    @Composable
    fun TableRow(cells: List<String>, header: Boolean) {
        Row(if (header) Modifier.background(scheme.surfaceVariant) else Modifier) {
            repeat(columns) { col ->
                InlineText(
                    text = cells.getOrElse(col) { "" },
                    style = inline,
                    modifier = Modifier
                        .width(140.dp)
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    fontSize = 14.sp,
                    fontWeight = if (header) FontWeight.SemiBold else null,
                )
            }
        }
    }

    Column(
        Modifier
            .clip(shape)
            .border(1.dp, scheme.outline, shape)
            .horizontalScroll(rememberScrollState()),
    ) {
        TableRow(table.header, header = true)
        table.rows.forEach { row ->
            HorizontalDivider(color = scheme.outline)
            TableRow(row, header = false)
        }
    }
}
