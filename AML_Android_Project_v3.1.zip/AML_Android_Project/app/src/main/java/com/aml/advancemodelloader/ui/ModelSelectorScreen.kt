package com.aml.advancemodelloader.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aml.advancemodelloader.data.BackendKind
import com.aml.advancemodelloader.engine.Presets

private val TABS = listOf("Local", "API", "Image", "Video")

/**
 * Model manager: pick a local GGUF, wire an API provider, or point the image / video generators at a
 * model id. Also reachable from the chat screen when no model is loaded yet.
 */
@Composable
fun ModelSelectorScreen(viewModel: ChatViewModel, onOpenSettings: (String) -> Unit, onBack: () -> Unit) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val picker by viewModel.picker.collectAsStateWithLifecycle()
    val engineState by viewModel.engineState.collectAsStateWithLifecycle()
    val apiModels by viewModel.apiModels.collectAsStateWithLifecycle()
    val busy by viewModel.busy.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableStateOf(0) }
    var modelId by rememberSaveable { mutableStateOf(settings.apiModelId) }
    var baseUrl by rememberSaveable { mutableStateOf(settings.apiBaseUrl) }

    LaunchedEffect(settings.apiModelId, settings.apiBaseUrl) {
        modelId = settings.apiModelId
        baseUrl = settings.apiBaseUrl
    }
    LaunchedEffect(Unit) { viewModel.refreshModels() }

    val ggufPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) viewModel.importAndLoad(uri)
    }

    Column(Modifier.fillMaxSize()) {
        Surface(tonalElevation = 1.dp) {
            Column {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                    Text("Models", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { onOpenSettings("appearance") }) { Icon(Icons.Filled.Settings, contentDescription = "Settings") }
                }
                ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
                    TABS.forEachIndexed { index, label ->
                        Tab(selected = tab == index, onClick = { tab = index }, text = { Text(label) })
                    }
                }
            }
        }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            when (tab) {
                0 -> LocalTab(viewModel, picker, engineState, ggufPicker = { ggufPicker.launch(arrayOf("*/*")) })
                1 -> ApiTab(
                    settings = settings,
                    baseUrl = baseUrl,
                    modelId = modelId,
                    apiModels = apiModels,
                    busy = busy,
                    onBaseUrl = { baseUrl = it },
                    onModelId = { modelId = it },
                    onApply = { viewModel.applyProvider(settings.provider, baseUrl.trim(), modelId.trim(), settings.providerKind) },
                    onPreset = { name ->
                        val preset = Presets.find(name) ?: return@ApiTab
                        baseUrl = preset.baseUrl
                        modelId = preset.defaultModel
                        viewModel.applyProvider(preset.name, preset.baseUrl, preset.defaultModel, preset.kind)
                    },
                    onTest = { viewModel.testConnection() },
                    onModels = { viewModel.testConnection() },
                )
                2 -> MediaTab(
                    title = "Image model",
                    hint = "OpenAI: gpt-image-1 / dall-e-3 · Gemini: imagen-4.0-generate-001 · ComfyUI proxy: apna endpoint",
                    modelId = settings.imageModelId,
                    size = settings.imageSize,
                    onModel = { viewModel.updateSettings(settings.copy(imageModelId = it)) },
                    onSize = { viewModel.updateSettings(settings.copy(imageSize = it)) },
                    onOpenSettings = { onOpenSettings("api") },
                )
                3 -> MediaTab(
                    title = "Video model",
                    hint = "OpenAI: sora-2 · Gemini: veo-3.0-generate-preview. Job polling AML khud karta hai.",
                    modelId = settings.videoModelId,
                    size = "",
                    onModel = { viewModel.updateSettings(settings.copy(videoModelId = it)) },
                    onSize = {},
                    onOpenSettings = { onOpenSettings("api") },
                )
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}

@Composable
private fun LocalTab(
    viewModel: ChatViewModel,
    picker: ModelPickerState,
    engineState: EngineState,
    ggufPicker: () -> Unit,
) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(18.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Memory, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text("Local GGUF", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "Phone par offline chalane ke liye llama.cpp model. File app storage mein copy hoti hai.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = ggufPicker, modifier = Modifier.fillMaxWidth(), enabled = picker.importProgress == null) {
                Icon(Icons.Filled.UploadFile, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (picker.importProgress == null) "GGUF file select karein" else "Copy ho rahi hai…")
            }
            picker.importProgress?.let {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth())
            }
        }
    }

    Spacer(Modifier.height(12.dp))
    Text("Downloaded models (${picker.models.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
    if (picker.models.isEmpty()) {
        Text(
            "Koi .gguf file nahi mili. Chhoti model (1–3B, Q4_K_M) se shuru karein — 3–4 GB RAM kaafi hoti hai.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    } else {
        LazyColumn(Modifier.fillMaxWidth().height(360.dp)) {
            items(picker.models, key = { it.path }) { model ->
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                ) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(model.name, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(formatBytes(model.sizeBytes), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                quantLabel(model.name)?.let {
                                    Spacer(Modifier.width(6.dp))
                                    Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                        TextButton(onClick = { viewModel.loadModel(model) }) { Text("Load") }
                        IconButton(onClick = { viewModel.deleteModel(model) }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                    }
                }
            }
        }
    }

    if (engineState is EngineState.Error) {
        Spacer(Modifier.height(10.dp))
        Text(engineState.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
private fun ApiTab(
    settings: com.aml.advancemodelloader.data.AppSettings,
    baseUrl: String,
    modelId: String,
    apiModels: List<String>,
    busy: String?,
    onBaseUrl: (String) -> Unit,
    onModelId: (String) -> Unit,
    onApply: () -> Unit,
    onPreset: (String) -> Unit,
    onTest: () -> Unit,
    onModels: () -> Unit,
) {
    Text("Provider presets", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(6.dp))
    Presets.all.chunked(2).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { preset ->
                val selected = settings.provider == preset.name
                Surface(
                    color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.weight(1f).clickable { onPreset(preset.name) },
                ) {
                    Column(Modifier.padding(10.dp)) {
                        Text(preset.name, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                        Text(preset.hint, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }

    Spacer(Modifier.height(12.dp))
    HorizontalDivider()
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(
        value = baseUrl,
        onValueChange = onBaseUrl,
        label = { Text("Base URL") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
    )
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(
        value = modelId,
        onValueChange = onModelId,
        label = { Text("Model id") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
    )
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { onApply(); onTest() }) { Text("Save + test") }
        OutlinedButton(onClick = onModels) { Text("Models list") }
    }
    busy?.let {
        Spacer(Modifier.height(8.dp))
        Text(it, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
    }
    if (apiModels.isNotEmpty()) {
        Spacer(Modifier.height(10.dp))
        Text("Server: ${apiModels.take(8).joinToString(", ")}${if (apiModels.size > 8) " …" else ""}", style = MaterialTheme.typography.labelSmall)
    }
    Spacer(Modifier.height(10.dp))
    Text(
        "API key app ki private preferences mein save hoti hai, taki chat screen par kabhi na dikhe.",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun MediaTab(
    title: String,
    hint: String,
    modelId: String,
    size: String,
    onModel: (String) -> Unit,
    onSize: (String) -> Unit,
    onOpenSettings: () -> Unit,
) {
    Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(6.dp))
    Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(10.dp))
    OutlinedTextField(
        value = modelId,
        onValueChange = onModel,
        label = { Text("Model id") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
    )
    if (size.isNotEmpty()) {
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = size,
            onValueChange = onSize,
            label = { Text("Size (e.g. 1024x1024)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
        )
    }
    Spacer(Modifier.height(10.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(6.dp))
        Text(
            "Generate karne ke liye input bar ke Image / Video chip ya agent tools use karein.",
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.weight(1f),
        )
    }
    Spacer(Modifier.height(10.dp))
    OutlinedButton(onClick = onOpenSettings) { Text("API key / provider Settings mein") }
}

private val Icons.Filled.Delete get() = Icons.Filled.ArrowBack
