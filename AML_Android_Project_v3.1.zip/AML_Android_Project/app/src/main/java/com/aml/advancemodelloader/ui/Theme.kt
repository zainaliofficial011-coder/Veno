package com.aml.advancemodelloader.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import com.aml.advancemodelloader.data.AccentColor
import com.aml.advancemodelloader.data.AppSettings
import com.aml.advancemodelloader.data.ThemeMode

private fun lightScheme(accent: Color) = lightColorScheme(
    primary = accent,
    onPrimary = Color.White,
    primaryContainer = accent.copy(alpha = 0.14f).compositeOver(Color.White),
    onPrimaryContainer = accent,
    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF14181D),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF14181D),
    surfaceVariant = Color(0xFFF1F3F6),
    onSurfaceVariant = Color(0xFF5A6069),
    surfaceContainerLow = Color(0xFFF8F9FB),
    surfaceContainer = Color(0xFFF3F5F8),
    surfaceContainerHigh = Color(0xFFEDEFF3),
    surfaceContainerHighest = Color(0xFFE7EAEF),
    outline = Color(0xFFD3D7DE),
    error = Color(0xFFB3261E),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
)

private fun darkScheme(accent: Color) = darkColorScheme(
    primary = accent,
    onPrimary = Color(0xFF00121F),
    primaryContainer = accent.copy(alpha = 0.30f).compositeOver(Color(0xFF1B1D21)),
    onPrimaryContainer = Color.White,
    background = Color(0xFF14171A),
    onBackground = Color(0xFFECEDEF),
    surface = Color(0xFF14171A),
    onSurface = Color(0xFFECEDEF),
    surfaceVariant = Color(0xFF2A2E33),
    onSurfaceVariant = Color(0xFFB3B8BF),
    surfaceContainerLow = Color(0xFF1B1E22),
    surfaceContainer = Color(0xFF1F2226),
    surfaceContainerHigh = Color(0xFF262A2F),
    surfaceContainerHighest = Color(0xFF2D3137),
    outline = Color(0xFF4B5058),
    error = Color(0xFFFF6B6B),
    errorContainer = Color(0xFF4A1E1E),
    onErrorContainer = Color(0xFFFFDAD6),
)

private fun Color.compositeOver(background: Color): Color {
    val alpha = this.alpha
    return Color(
        red = red * alpha + background.red * (1 - alpha),
        green = green * alpha + background.green * (1 - alpha),
        blue = blue * alpha + background.blue * (1 - alpha),
        alpha = 1f,
    )
}

/** Applies theme mode, accent colour and font scale from the user's settings. */
@Composable
fun AmlTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val accent = Color(settings.accent.argb)
    val scheme = remember(dark, settings.accent) {
        if (dark) darkScheme(accent) else lightScheme(accent)
    }
    val density = LocalDensity.current
    val scaled = remember(density, settings.fontScale) {
        Density(density.density, density.fontScale * settings.fontScale.coerceIn(0.8f, 1.6f))
    }
    CompositionLocalProvider(LocalDensity provides scaled) {
        MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
    }
}
