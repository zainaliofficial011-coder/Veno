// AML (Advance Model Loader) - JNI bridge between Kotlin (AmlNative) and llama.cpp.
//
// Contract with LlmEngine.kt:
//   loadModel(path, nCtx, nThreads, useMmap) -> bool   blocking, false on failure
//   generate(prompt, maxNew, temp, topP, topK, cb)     blocking, cb.onToken(piece) once per piece,
//                                                      stops when cb returns false or stop() is called
//   stop()                                             sets an atomic flag (generate() resets it on entry)
//   unload()                                           frees context + model
// Allocation failures are thrown as java.lang.OutOfMemoryError. Only complete, valid text is ever
// handed to Java (partial UTF-8 sequences are buffered; Java strings are built from UTF-16).

#include <jni.h>
#include <android/log.h>

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <exception>
#include <new>
#include <stdexcept>
#include <string>
#include <vector>

#ifdef AML_HAVE_LLAMA
#include "llama.h"
#endif

#define TAG "AML_NATIVE"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::atomic<bool> g_should_stop(false);

// ---------------------------------------------------------------------------------------------
// Helpers: exceptions + UTF-8 <-> UTF-16
// ---------------------------------------------------------------------------------------------
namespace {

void throwJava(JNIEnv* env, const char* cls, const char* msg) {
    if (env->ExceptionCheck()) return;
    jclass c = env->FindClass(cls);
    if (c) {
        env->ThrowNew(c, msg);
        env->DeleteLocalRef(c);
    }
}

void appendUtf8(std::string& out, uint32_t cp) {
    if (cp < 0x80) {
        out.push_back(static_cast<char>(cp));
    } else if (cp < 0x800) {
        out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    } else if (cp < 0x10000) {
        out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    } else {
        out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    }
}

// Java UTF-16 -> standard UTF-8 (GetStringUTFChars would give "modified" UTF-8, which breaks emoji).
std::string jstringToUtf8(JNIEnv* env, jstring s) {
    std::string out;
    if (!s) return out;
    const jsize len = env->GetStringLength(s);
    const jchar* chars = env->GetStringChars(s, nullptr);
    if (!chars) return out;
    out.reserve(static_cast<size_t>(len) + static_cast<size_t>(len) / 2);
    for (jsize i = 0; i < len; ++i) {
        uint32_t cp = chars[i];
        if (cp >= 0xD800 && cp <= 0xDBFF) {
            if (i + 1 < len && chars[i + 1] >= 0xDC00 && chars[i + 1] <= 0xDFFF) {
                cp = 0x10000 + ((cp - 0xD800) << 10) + (chars[i + 1] - 0xDC00);
                ++i;
            } else {
                cp = 0xFFFD;
            }
        } else if (cp >= 0xDC00 && cp <= 0xDFFF) {
            cp = 0xFFFD;
        }
        appendUtf8(out, cp);
    }
    env->ReleaseStringChars(s, chars);
    return out;
}

// Length of the longest prefix that does not end in the middle of a multi-byte sequence.
size_t completeUtf8Prefix(const std::string& s) {
    const size_t n = s.size();
    for (size_t k = 1; k <= 3 && k <= n; ++k) {
        const unsigned char b = static_cast<unsigned char>(s[n - k]);
        if ((b & 0xC0) == 0x80) continue;           // continuation byte, keep looking for the lead
        if (b < 0x80) return n;                      // ASCII: complete
        const size_t need = b >= 0xF0 ? 4 : (b >= 0xE0 ? 3 : 2);
        return need > k ? n - k : n;                 // lead byte with too few followers -> hold back
    }
    return n;
}

// UTF-8 -> UTF-16, replacing anything invalid with U+FFFD so Java never sees malformed text.
std::u16string decodeUtf8(const std::string& s) {
    std::u16string out;
    out.reserve(s.size());
    const size_t n = s.size();
    size_t i = 0;
    while (i < n) {
        const unsigned char c = static_cast<unsigned char>(s[i]);
        if (c < 0x80) {
            out.push_back(c);
            ++i;
            continue;
        }
        uint32_t cp;
        size_t need;
        if (c >= 0xC2 && c <= 0xDF) { cp = c & 0x1F; need = 1; }
        else if (c >= 0xE0 && c <= 0xEF) { cp = c & 0x0F; need = 2; }
        else if (c >= 0xF0 && c <= 0xF4) { cp = c & 0x07; need = 3; }
        else { out.push_back(0xFFFD); ++i; continue; }

        if (i + need >= n) { out.push_back(0xFFFD); ++i; continue; }
        bool ok = true;
        for (size_t k = 1; k <= need; ++k) {
            const unsigned char b = static_cast<unsigned char>(s[i + k]);
            if ((b & 0xC0) != 0x80) { ok = false; break; }
            cp = (cp << 6) | (b & 0x3F);
        }
        if (!ok) { out.push_back(0xFFFD); ++i; continue; }
        const bool bad = (need == 2 && cp < 0x800) || (need == 3 && cp < 0x10000) ||
                         cp > 0x10FFFF || (cp >= 0xD800 && cp <= 0xDFFF);
        if (bad) { out.push_back(0xFFFD); i += need + 1; continue; }
        if (cp >= 0x10000) {
            cp -= 0x10000;
            out.push_back(static_cast<char16_t>(0xD800 + (cp >> 10)));
            out.push_back(static_cast<char16_t>(0xDC00 + (cp & 0x3FF)));
        } else {
            out.push_back(static_cast<char16_t>(cp));
        }
        i += need + 1;
    }
    return out;
}

// Sends the complete part of `pending` to Java. Returns false when generation should end
// (callback returned false, or it threw).
bool emitPending(JNIEnv* env, jobject cb, jmethodID onToken, std::string& pending, bool flush) {
    const size_t n = flush ? pending.size() : completeUtf8Prefix(pending);
    if (n == 0) return true;
    const std::u16string text = decodeUtf8(pending.substr(0, n));
    pending.erase(0, n);
    jstring js = env->NewString(reinterpret_cast<const jchar*>(text.data()),
                                static_cast<jsize>(text.size()));
    if (!js) return false;  // OutOfMemoryError already pending
    const jboolean keepGoing = env->CallBooleanMethod(cb, onToken, js);
    env->DeleteLocalRef(js);  // thousands of tokens per call: don't overflow the local ref table
    if (env->ExceptionCheck()) return false;
    return keepGoing == JNI_TRUE;
}

}  // namespace

#ifdef AML_HAVE_LLAMA
// ---------------------------------------------------------------------------------------------
// Real implementation (llama.cpp)
// ---------------------------------------------------------------------------------------------
namespace {

llama_model* g_model = nullptr;
llama_context* g_ctx = nullptr;
bool g_backend_ready = false;

void freeModel() {
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}

void llamaLog(ggml_log_level level, const char* text, void* /*user*/) {
    if (level == GGML_LOG_LEVEL_ERROR) __android_log_write(ANDROID_LOG_ERROR, TAG, text);
    else if (level == GGML_LOG_LEVEL_WARN) __android_log_write(ANDROID_LOG_WARN, TAG, text);
    else if (level == GGML_LOG_LEVEL_INFO) __android_log_write(ANDROID_LOG_INFO, TAG, text);
}

struct SamplerGuard {
    llama_sampler* s = nullptr;
    ~SamplerGuard() { if (s) llama_sampler_free(s); }
};

// llama.cpp replaced `llama_model_params::use_mmap` (bool) with
// `llama_model_params::load_mode` (enum llama_load_mode) around b10110, July 2026.
// Both shapes are supported here so this file compiles against an older pinned tag and against
// master. The overload that mentions a field is dropped by SFINAE when that field does not exist,
// so no version macro or #if is needed.
enum { AML_LOAD_MODE_NONE = 0, AML_LOAD_MODE_MMAP = 1 };  // mirrors llama_load_mode

template <typename P>
auto applyLoadMode(P& p, bool useMmap, int) -> decltype(static_cast<void>(p.load_mode), void()) {
    using ModeT = decltype(p.load_mode);
    p.load_mode = static_cast<ModeT>(useMmap ? AML_LOAD_MODE_MMAP : AML_LOAD_MODE_NONE);
}

template <typename P>
auto applyLoadMode(P& p, bool useMmap, long) -> decltype(static_cast<void>(p.use_mmap), void()) {
    p.use_mmap = useMmap;
}

inline void setMmapMode(llama_model_params& p, bool useMmap) { applyLoadMode(p, useMmap, 0); }

}  // namespace

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_aml_advancemodelloader_engine_AmlNative_loadModel(
    JNIEnv* env, jobject /*obj*/,
    jstring path, jint nCtx, jint nThreads, jboolean useMmap) {
    try {
        freeModel();
        if (!g_backend_ready) {
            llama_log_set(llamaLog, nullptr);
            llama_backend_init();
            g_backend_ready = true;
        }

        const std::string modelPath = jstringToUtf8(env, path);
        LOGI("Loading model: %s (ctx=%d, threads=%d, mmap=%d)",
             modelPath.c_str(), nCtx, nThreads, useMmap ? 1 : 0);

        llama_model_params mp = llama_model_default_params();
        setMmapMode(mp, useMmap == JNI_TRUE);   // use_mmap on old pins, load_mode on new ones
        mp.n_gpu_layers = 0;  // CPU only on Android

        g_model = llama_model_load_from_file(modelPath.c_str(), mp);
        if (!g_model) {
            LOGE("llama_model_load_from_file failed");
            return JNI_FALSE;  // corrupt file / unsupported architecture
        }

        llama_context_params cp = llama_context_default_params();
        cp.n_ctx = static_cast<uint32_t>(nCtx);
        cp.n_batch = static_cast<uint32_t>(std::min<jint>(nCtx, 512));
        cp.n_ubatch = cp.n_batch;
        cp.n_threads = nThreads;
        cp.n_threads_batch = nThreads;
        cp.no_perf = true;

        g_ctx = llama_init_from_model(g_model, cp);
        if (!g_ctx) {
            LOGE("llama_init_from_model failed");
            freeModel();
            throwJava(env, "java/lang/OutOfMemoryError",
                      "Failed to allocate llama context (not enough memory for this context size)");
            return JNI_FALSE;
        }
        return JNI_TRUE;
    } catch (const std::bad_alloc&) {
        freeModel();
        throwJava(env, "java/lang/OutOfMemoryError", "bad_alloc while loading the model");
    } catch (const std::exception& e) {
        freeModel();
        throwJava(env, "java/lang/RuntimeException", e.what());
    } catch (...) {
        freeModel();
        throwJava(env, "java/lang/RuntimeException", "Unknown native error while loading the model");
    }
    return JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_aml_advancemodelloader_engine_AmlNative_generate(
    JNIEnv* env, jobject /*obj*/,
    jstring prompt, jint maxNewTokens, jfloat temp, jfloat topP, jint topK, jobject callback) {

    g_should_stop.store(false);

    if (!g_model || !g_ctx) {
        throwJava(env, "java/lang/IllegalStateException", "No model is loaded.");
        return;
    }
    jclass cbClass = env->GetObjectClass(callback);
    jmethodID onToken = env->GetMethodID(cbClass, "onToken", "(Ljava/lang/String;)Z");
    env->DeleteLocalRef(cbClass);
    if (!onToken) return;  // NoSuchMethodError already pending

    SamplerGuard guard;
    try {
        const llama_vocab* vocab = llama_model_get_vocab(g_model);
        const std::string text = jstringToUtf8(env, prompt);

        // Tokenize: add BOS where the model wants it, and parse <|im_start|>-style special tokens.
        const int32_t needed = -llama_tokenize(vocab, text.c_str(), static_cast<int32_t>(text.size()),
                                               nullptr, 0, /*add_special=*/true, /*parse_special=*/true);
        if (needed <= 0) throw std::runtime_error("Empty or untokenizable prompt");
        std::vector<llama_token> tokens(static_cast<size_t>(needed));
        const int32_t got = llama_tokenize(vocab, text.c_str(), static_cast<int32_t>(text.size()),
                                           tokens.data(), needed, true, true);
        if (got < 0) throw std::runtime_error("Tokenization failed");
        tokens.resize(static_cast<size_t>(got));

        const int nCtx = static_cast<int>(llama_n_ctx(g_ctx));
        const int nPrompt = static_cast<int>(tokens.size());
        if (nPrompt >= nCtx) {
            throw std::runtime_error("The prompt is longer than the context window");
        }

        // Kotlin resends the whole history every turn, so start from an empty KV cache.
        llama_memory_clear(llama_get_memory(g_ctx), true);

        // Sampler chain: top-k -> top-p -> temperature -> random pick (or plain greedy at temp <= 0).
        llama_sampler_chain_params sp = llama_sampler_chain_default_params();
        sp.no_perf = true;
        guard.s = llama_sampler_chain_init(sp);
        if (temp <= 0.0f) {
            llama_sampler_chain_add(guard.s, llama_sampler_init_greedy());
        } else {
            if (topK > 0) llama_sampler_chain_add(guard.s, llama_sampler_init_top_k(topK));
            if (topP > 0.0f && topP < 1.0f) llama_sampler_chain_add(guard.s, llama_sampler_init_top_p(topP, 1));
            llama_sampler_chain_add(guard.s, llama_sampler_init_temp(temp));
            llama_sampler_chain_add(guard.s, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
        }

        // Prompt processing in n_batch-sized chunks (checks the stop flag between chunks).
        const int nBatch = static_cast<int>(llama_n_batch(g_ctx));
        for (int i = 0; i < nPrompt; i += nBatch) {
            if (g_should_stop.load()) return;
            const int count = std::min(nBatch, nPrompt - i);
            const int rc = llama_decode(g_ctx, llama_batch_get_one(tokens.data() + i, count));
            if (rc != 0) throw std::runtime_error("llama_decode failed while processing the prompt");
        }

        // Token loop.
        std::string pending;   // raw bytes not yet handed to Java
        std::string piece(256, '\0');
        int nPast = nPrompt;

        for (int i = 0; i < maxNewTokens && !g_should_stop.load(); ++i) {
            llama_token tok = llama_sampler_sample(guard.s, g_ctx, -1);
            if (llama_vocab_is_eog(vocab, tok)) break;

            int len = llama_token_to_piece(vocab, tok, &piece[0], static_cast<int32_t>(piece.size()), 0, false);
            if (len < 0) {
                piece.resize(static_cast<size_t>(-len));
                len = llama_token_to_piece(vocab, tok, &piece[0], static_cast<int32_t>(piece.size()), 0, false);
            }
            if (len > 0) pending.append(piece.data(), static_cast<size_t>(len));

            if (!emitPending(env, callback, onToken, pending, /*flush=*/false)) break;

            if (nPast >= nCtx) break;  // context window is full
            const int rc = llama_decode(g_ctx, llama_batch_get_one(&tok, 1));
            if (rc > 0) break;         // no KV slot / aborted: end the reply gracefully
            if (rc < 0) throw std::runtime_error("llama_decode failed");
            ++nPast;
        }

        if (!env->ExceptionCheck()) emitPending(env, callback, onToken, pending, /*flush=*/true);
    } catch (const std::bad_alloc&) {
        throwJava(env, "java/lang/OutOfMemoryError", "bad_alloc during generation");
    } catch (const std::exception& e) {
        throwJava(env, "java/lang/RuntimeException", e.what());
    } catch (...) {
        throwJava(env, "java/lang/RuntimeException", "Unknown native error during generation");
    }
}

JNIEXPORT void JNICALL
Java_com_aml_advancemodelloader_engine_AmlNative_stop(JNIEnv* /*env*/, jobject /*obj*/) {
    g_should_stop.store(true);
}

JNIEXPORT void JNICALL
Java_com_aml_advancemodelloader_engine_AmlNative_unload(JNIEnv* /*env*/, jobject /*obj*/) {
    g_should_stop.store(true);
    freeModel();
}

}  // extern "C"

#else
// ---------------------------------------------------------------------------------------------
// Fallback when llama.cpp is not present: the app builds, but loading a model reports failure.
// ---------------------------------------------------------------------------------------------
extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_aml_advancemodelloader_engine_AmlNative_loadModel(
    JNIEnv*, jobject, jstring, jint, jint, jboolean) {
    LOGE("Built without llama.cpp. Clone it into app/src/main/cpp/llama.cpp and rebuild.");
    return JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_aml_advancemodelloader_engine_AmlNative_generate(
    JNIEnv*, jobject, jstring, jint, jfloat, jfloat, jint, jobject) {}

JNIEXPORT void JNICALL
Java_com_aml_advancemodelloader_engine_AmlNative_stop(JNIEnv*, jobject) {
    g_should_stop.store(true);
}

JNIEXPORT void JNICALL
Java_com_aml_advancemodelloader_engine_AmlNative_unload(JNIEnv*, jobject) {
    g_should_stop.store(true);
}

}  // extern "C"
#endif
